import sys
import openai
import os
from langchain_core.prompts import PromptTemplate
from langchain.agents import AgentExecutor, create_react_agent
from langchain_openai import ChatOpenAI

import re
import json

from src.config import OPENAI_API_KEY
from tools import *

os.environ["OPENAI_API_KEY"] = OPENAI_API_KEY


def extract_and_save_final_answer(text, output_file, name):
    root_cause_match = re.search(r"\*?Root Cause:?\*?\s*(.+?)(?=\n\*?Suggestion|\Z)", text, re.DOTALL)
    suggestions_matches = re.finditer(r"Suggestion (\d+): (.*?)(?=\nSuggestion|\Z)", text, re.DOTALL)

    if not root_cause_match:
        raise ValueError("Root Cause not found in the text")

    root_cause = root_cause_match.group(1).strip()
    suggestions = []

    for match in suggestions_matches:
        suggestion_number = match.group(1)
        suggestion_text = match.group(2).strip()

        lines = suggestion_text.split('\n', 1)
        title = lines[0].strip()
        details = lines[1].strip() if len(lines) > 1 else ""

        suggestions.append("Suggestion " + suggestion_number + ". " + title + " " + details + "\n")
    if os.path.exists(output_file):
        with open(output_file, 'r', encoding='utf-8') as f:
            all_analyses = json.load(f)
    else:
        all_analyses = {}

    if name in all_analyses:
        all_analyses[name][root_cause] = suggestions
    else:
        all_analyses[name] = {
            root_cause: suggestions
        }

    # 保存为 JSON 文件
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(all_analyses, f, ensure_ascii=False, indent=2)

    return all_analyses


def api_gpt_response(prompt, n):
    response = openai.chat.completions.create(
        messages=[{"role": "user", "content": prompt}],
        model="gpt-4o-2024-05-13",
        n=n,
        temperature=1)
    return response

def extract_function(paragraph, function_id):
    lines = paragraph.split('\n')
    index = 0
    start = -1
    lines_content = []

    while index < len(lines):
        if function_id.strip() in lines[index] and (
                'Function' in lines[index] or
                'function' in lines[index]
        ):
            start = index
            break
        index += 1
    if start == -1:
        return ""

    index_of_java = start
    while index_of_java < len(lines):
        if '```java' in lines[index_of_java]:
            start = index_of_java + 1
            break
        index_of_java += 1
    if index_of_java == len(lines):
        index_of_java = start
        while index_of_java < len(lines):
            if '```' in lines[index_of_java]:
                start = index_of_java + 1
                break
            index_of_java += 1
    index = start - 1

    while 0 <= index < len(lines):
        line = lines[index].strip()
        if len(line) == 0:
            break
        if line[0] == "@" and not line.startswith("@@") and not line.endswith("*/"):
            lines_content.append(lines[index])
            index -= 1
            continue
        break

    lines_content.reverse()

    bracket_cnt = 0
    bracket_flag = False

    if start >= len(lines):
        return ''

    first_line = lines[start]
    if not (first_line.endswith(';') and first_line.count('{') == 0):
        for i in range(start, len(lines)):
            line = lines[i]
            lines_content.append(line)
            bracket_cnt += line.count('{')
            if bracket_cnt:
                bracket_flag = True
            bracket_cnt -= line.count('}')
            if bracket_cnt == 0 and bracket_flag:
                break

    return '\n'.join(lines_content)

def extract_patch(bug_data, raw_patch_result):
    extracted_patch_result = {}
    for bug_name in raw_patch_result.keys():
        extracted_patch_result[bug_name] = {'patches': []}
        for raw_patch in raw_patch_result[bug_name]['patches']:
            if raw_patch.startswith(':'):
                raw_patch = raw_patch[1:]
            elif raw_patch.startswith('@@ Response:'):
                raw_patch = raw_patch[12:]
            extracted_patch = {}
            for function_id in range(1, len(bug_data['functions']) + 1):
                extracted_patch[str(function_id)] = extract_function(raw_patch, str(function_id))
                if extracted_patch[str(function_id)] is None:
                    extracted_patch[str(function_id)] = ''
            extracted_patch_result[bug_name]['patches'].append(extracted_patch)
    return extracted_patch_result


tools = [open_proj_tool, trace_method_usage_tool, find_method_in_file_tool, analyze_method_details_tool, analyze_method_control_flow_tool,
         find_class_loc_tool, identify_class_tool, get_imports_tool, close_proj_tool, example_patch_search_tool]


prompt_solution_template = PromptTemplate.from_template("""
You are an expert Java programmer and code analyzer. Your task is to analyze a given set of Java code snippets which lead to a bug (multi-function bug), identify the root cause of a bug, and provide repair suggestions.

## Available Tools

You have access to the following Joern-based tools and one Example Patch Search tool:
{tools}
{tool_names}

for each tool call:
  "tool": "Tool to be called from tools, if applicable. Set to 'None' if no tool is needed.",
  "parameters": "The input parameter(s) used by the tools. Only the parameter value(s) (e.g. getIndexOf), (e.g. getLegendItems, AbstractCategoryItemRenderer.java). Set to 'None' if there are no parameters.". DO NOT try to modify any parameter format(e.g., open("Chart-1_buggy") rather than open("Chart_1_buggy\"\n") etc.). 

- IMPORTANT: Do not modify tool parameters in any way. Use them exactly as provided in the input context. DO NOT Add any quota marks to the parameter because the tool call will process it.

## Analysis Process

1. Open the CPG for the buggy code (always required as first stage)
2. Analyze the buggy code, focusing on the area marked with /* bug is here */, which means this line of code may should do some adding, deleteing or modifying to fix the bug.
3. Use tools to gather necessary information of each buggy function about( DO NOT Add any quota marks and newline symbols to the input parameter because the tool call will process it.):
   - Variable definitions and usages
   - Function calls and definitions
   - Control flow
   - Similar patterns in the codebase
   - Import statements and library usage
4. Synthesize gathered information
5. Close the project (always required after gather enough information and before output the Summary Answer)
6. Output the Summary Answer.
7. Concatenate the complete multi snippets of Buggy function code(plain text) root cause, use them as the input parameter of calling example_patch_search_tool. It will return a fix pattern contain buggy code, fix code and root cause.
8. Observe the fix pattern of similar bug from example_patch_search_tool output as reference, learn and update the root cause and suggestions as the Final Answer.



## Guidelines
- Start with opening the CPG and close the project properly
- Focus on the buggy function and lines(before or at) marked with /* bug is here */
- Avoid unnecessary tool calls if information can be inferred from context
- Ensure your analysis covers context, potential causes, and fix suggestions
- Gather repair contexts as much as you need to draw the root cause.
- Give specific correct repair suggestions for each function
- Call example_patch_search_tool if you think the joern analyze information is not enough to provide the Final Answer.

## Input Context

- Buggy ID(proj_name): {buggy_id}
- Buggy File Path List: {buggy_file_path_list}
- Buggy Function List: {buggy_code_list}
- Trigger Test: {trigger_src}
- Error Message: {err_msg}

To help you better use example_patch_search_tool call, make sure the parameter is the full buggy code concatenate with the root cause, here is an Example:
Action Input:"input_string":  <Buggy code>, Root Cause: <content>"

## Output Format

Use the following format for your analysis:

Thought: [Your reasoning about the next step]
Action: [Tool name]
Action Input: "value1", "value2"
Observation: [Tool output]
... (Repeat Thought/Action/Action Input/Observation as needed)
Thought: I now have enough information to provide the Summary Answer
Action: [Call example_patch_search_tool]
Action Input: "buggy_code1, buggy_code2(...), root_cause"
Observation: [Tool output]
Thought: I now have learnt the fix pattern, and I can update and output the Final Answer

Final Answer(IMPORTANT: Strictly follow the output format below and DO NOT add '#', '*' or other signs before each Root Cause & Suggestion title): 
Root Cause: [Detailed explanation of the bug's root cause]

Suggestion 1: [Suggestion title]
[Detailed description of the first repair suggestion, give step by step and sufficient suggestion to help generate correct patches.  Only provide how to generate correct patch suggestions, not involve test process. Note that each suggestion should be independent]

Suggestion 2: [Suggestion title]
[Detailed description of the second repair suggestion, give step by step and sufficient suggestion to help generate correct patches.  Only provide how to generate correct patch suggestions, not involve test process. Note that each suggestion should be independent]

[Add more suggestions as needed, give as much as it can help to generate correct patches. Specify which Root Cause or Suggestion is for which Function Code ID(Use format like: As for Function 1:). DO Not miss up with Function ID and answer index. Please make sure your Final Answer follows the format above exactly, without adding any extra marks or symbols]

## Begin Your Analysis

Start by opening the CPG and analyzing the buggy code. Focus on the area marked with /* bug is here */ and use the available tools to gather necessary information.
Exit the chain when you already output the Final Answer.
Thought: {agent_scratchpad}
""")



tool_descriptions = "\n".join(
    f"{i + 1}. {tool.description}\n"
    for i, tool in enumerate(tools)
)
tool_names = "\n".join(
    f"{i + 1}. {tool.name}\n"
    for i, tool in enumerate(tools)
)


class Logger(object):
    def __init__(self, filename='default.log', stream=sys.stdout):
        self.terminal = stream
        self.log = open(filename, 'a')

    def write(self, message):
        self.terminal.write(message)
        self.log.write(message)

    def flush(self):
        pass

sys.stdout = Logger('./log/mf.log', sys.stdout)


# Multi Function Num: 91
bug_list =['Chart-14','Chart-15', 'Chart-16', 'Chart-18', 'Chart-19', 'Chart-2', 'Chart-21', 'Chart-22', 'Chart-25', 'Closure-100', 'Closure-103', 'Closure-106', 'Closure-110','Closure-3','Closure-34', 'Closure-37', 'Closure-41', 'Closure-45', 'Closure-47', 'Closure-49', 'Closure-54','Closure-6', 'Closure-60', 'Closure-64', 'Closure-68', 'Closure-72','Closure-75','Closure-76', 'Closure-79', 'Closure-80','Closure-85', 'Closure-89', 'Closure-9', 'Closure-90', 'Lang-15', 'Lang-20', 'Lang-30', 'Lang-34', 'Lang-35', 'Lang-36', 'Lang-41', 'Lang-46','Lang-47', 'Lang-50', 'Lang-60', 'Lang-62', 'Lang-63','Lang-7', 'Math-1', 'Math-100', 'Math-14', 'Math-18', 'Math-22', 'Math-29', 'Math-35', 'Math-36', 'Math-37', 'Math-4', 'Math-46', 'Math-49', 'Math-54', 'Math-6', 'Math-62', 'Math-65', 'Math-66', 'Math-67', 'Math-68', 'Math-71', 'Math-76', 'Math-77', 'Math-81', 'Math-83', 'Math-92', 'Math-93', 'Math-98', 'Math-99', 'Mockito-11', 'Mockito-16', 'Mockito-30', 'Mockito-35', 'Mockito-4', 'Mockito-6', 'Time-1', 'Time-12', 'Time-13', 'Time-2', 'Time-3', 'Time-6','Time-26', 'Lang-64', 'Math-47']

with open("../../D4J_dataset/defects4j-mf.json", 'r') as f:
    data = json.load(f)
for name in bug_list:
    i = 1
    while i < 4:
        print(f"Generating Solution for: {name}, Round: {i}")
        i += 1

        trigger_test_list = list(data[name]['trigger_test'].keys())
        trigger_src_list = []
        err_msg_list = []
        for trigger_test in trigger_test_list:
            trigger_src_list.append(data[name]['trigger_test'][trigger_test]['src'])
            err_msg_list.append(data[name]['trigger_test'][trigger_test]['clean_error_msg'])
        # trigger_src_list = slim_joern_token(str(trigger_src_list))
        # err_msg_list = slim_joern_token(str(err_msg_list))


        function_id = 1
        function_list = []
        path_list = []
        for function in data[name]['functions']:
            comment = function['comment']
            buggy_function = function['buggy_fl']
            path = function['path']
            path_list.append(f'\nPath of Function {function_id}: {path}\n')
            function_list.append(f'\nFunction ID: {function_id}\n{path}\n{comment}{buggy_function}')
            function_id += 1

        prompt_solution = prompt_solution_template.partial(
            buggy_id=name + "_buggy",
            buggy_file_path_list=str(path_list),
            buggy_code_list=str(function_list),
            trigger_src=str(trigger_src_list),
            err_msg=str(err_msg_list)
        )
        llm = ChatOpenAI(model_name="gpt-4o")

        agent = create_react_agent(llm, tools, prompt_solution)
        try:
            agent_executor = AgentExecutor(agent=agent, tools=tools, verbose=True,
                                           handle_parsing_errors="Check your output and make sure it conforms, use the Action/Action Input syntax. Output the Final Answer always should always required as last step. Exit after output the Final Answer.", )
            result = agent_executor.invoke({})
            extract_and_save_final_answer(result['output'], "../../output/mf_solutions/" + name + ".json", name)
        except ValueError as e:
            response = str(e)
            if not response.startswith("Could not parse LLM output: `"):
                raise e
            response = response.removeprefix("Could not parse LLM output: `").removesuffix("`")

    patches = {}
    output_patches_file = "../../output/mf_patches/" + name + ".json"
    with open("../../output/mf_solutions/" + name + ".json") as f2:
        solutions = json.load(f2)
    bug_data = data[name]
    curr_patch = {}
    curr_patch['prompt'] = []
    curr_patch['patches'] = []
    trigger_test_list = list(bug_data['trigger_test'].keys())
    trigger_src_list = []
    err_msg_list = []
    for trigger_test in trigger_test_list:
        trigger_src_list.append(bug_data['trigger_test'][trigger_test]['src'])
        err_msg_list.append(bug_data['trigger_test'][trigger_test]['clean_error_msg'])
    # trigger_src_list = slim_joern_token(str(trigger_src_list))
    # err_msg_list = slim_joern_token(str(err_msg_list))

    context = ["buggy_id: " + name + "_buggy", "\ntrigger_src: " + str(trigger_src_list),
               "\nerr_msg: " + str(err_msg_list)]
    fun_num = len(bug_data['functions'])
    function_code = []
    for function_id in range(fun_num):
        function_code.append('Function ID: ' + str(function_id + 1))
        function_code.append(bug_data['functions'][function_id]['buggy_fl'])
        function_code.append('\n')

    for root_cause in solutions[name].keys():
        for suggestion in solutions[name][root_cause]:
            prompt = []
            prompt.append(
                'You expert Java programmer in generating patches for a given set of buggy snippets. This bug consists of multiple interdependent buggy functions, meaning that fix should be achieved by simultaneously modifying these functions. You should look deeply through all the bug information and combine the root cause and repair suggestions to generate correct patches.\n')
            prompt.append('Root Cause' + root_cause)
            prompt.append("\nSuggestion" + suggestion)
            prompt.append("\nContext Information" + str(context))
            prompt.append(
                "\nBuggy Code (Function, Analyze the buggy code, focusing on the area marked with /* bug is here */, which means this line of code may should do some adding, deleteing or modifying to fix the bug.):" + str(
                    function_code))
            prompt.append(
                "\nPovide fixed function for each buggy functions. Your output should be strictly in the format \'Function ID: {ID}\\nFixed function code:\\n```java\n{fixed function code}\n```\' without any other content'")

            suggest_patch = []
            try:
                response = api_gpt_response(str(prompt), 5)
                print("***********response***********")

                for choice in response.choices:
                    print("-----------")
                    generated_text = choice.message.content.strip()
                    print(generated_text)
                    prompt_end_idx = generated_text.find(str(prompt).strip()) + len(str(prompt).strip())
                    fixed_result = generated_text[
                                   prompt_end_idx:].strip() if prompt_end_idx != -1 else generated_text
                    suggest_patch.append(generated_text)
            except openai.OpenAIError as e:
                print(f'OpenAI API error: {e}')
                break
            curr_patch['patches'].extend(suggest_patch)
        print(len(curr_patch['patches']))
    patches[name] = curr_patch
    patches = extract_patch(bug_data, patches)
    print(len(patches))
    with open(output_patches_file, 'w') as f:
        json.dump(patches, f, indent=2)