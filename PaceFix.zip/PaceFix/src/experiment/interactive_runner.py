"""Interactive launcher and compact report writer for the formal PaceFix pipeline."""

from __future__ import annotations

import argparse
import difflib
import hashlib
import json
import os
import shutil
import sys
from pathlib import Path
from typing import Any, Mapping, Sequence

from src.experiment.functional_progress import analyze_validator_results
from src.experiment.dataset_profiles import dataset_choices, get_dataset_profile
from src.experiment.pacefix_runner import build_real_runner_hooks, run_three_rounds
from src.experiment.pacefix_validator import ValInfo, clean_tmp_folder
from src.experiment.service_manager import ensure_formal_services

REPO_ROOT = Path(__file__).resolve().parents[2]
DATASET_FILE = REPO_ROOT / "D4J_dataset" / "defects4j-v12-sf-255.json"
DEFAULT_OUTPUT_ROOT = REPO_ROOT / "experiment_output" / "Defects4J"
VALIDATION_DIRNAME = ".validator_results"
CHECKPOINT_NAME = ".checkpoint.json"
_TEMPORARY_NAMES = {
    VALIDATION_DIRNAME, "validator_results", "candidate_diffs", "sf_patches",
    "sf_solutions", "log", ".log", ".sf_solutions", "runner_result.json",
}


def _load_dataset(dataset_file: Path = DATASET_FILE) -> Mapping[str, Any]:
    payload = json.loads(dataset_file.read_text(encoding="utf-8"))
    if not isinstance(payload, Mapping):
        raise RuntimeError("dataset_invalid")
    return payload


def validate_bug_id(bug_id: str, dataset_file: Path = DATASET_FILE) -> str:
    bug_id = bug_id.strip()
    if not bug_id:
        raise ValueError("bug_id_empty")
    if bug_id not in _load_dataset(dataset_file):
        raise ValueError(f"bug_id_not_found:{bug_id}")
    return bug_id


def _bug_output_dir(output_root: Path, bug_id: str) -> Path:
    """The sole durable result directory for one Bug."""
    return output_root / bug_id


def _initial_state(bug_id: str, run_dir: Path, dataset_file: Path = DATASET_FILE) -> tuple[str, list[str], list[Mapping[str, Any]], str]:
    """Use the existing validator to establish P0/F0; this never calls the API."""
    validation_tmp = Path("/tmp/llm4apr_validation")
    os.chdir(REPO_ROOT)
    clean_tmp_folder(str(validation_tmp))
    (validation_tmp / "config.json").write_text(json.dumps({
        "input_path": "unused",
        "output_path": str(run_dir / VALIDATION_DIRNAME / "initial_state"),
        "dataset_path": str(dataset_file), "log_mode": False,
    }), encoding="utf-8")
    info = ValInfo((bug_id, {"patches": [], "round_id": 1}))
    if not info.check_init_success():
        raise RuntimeError(
            f"initial_state_unavailable:{bug_id}:compile={info.current_compile_status}:"
            f"suite={info.current_suite_status}:failed={len(info.failed_test_cases)}"
        )
    code = _load_dataset(dataset_file)[bug_id].get("buggy_fl")
    if not isinstance(code, str) or not code.strip():
        raise RuntimeError(f"initial_buggy_fl_unavailable:{bug_id}")
    state_hash = hashlib.sha256(code.encode("utf-8")).hexdigest()
    if info.current_state_sha256 != state_hash:
        raise RuntimeError("initial_state_hash_mismatch")
    return code, list(info.failed_test_cases), list(info.current_test_context), state_hash


def _read_validator_records(run_dir: Path, bug_id: str, round_id: int) -> list[Mapping[str, Any]]:
    result_file = run_dir / VALIDATION_DIRNAME / f"round_{round_id}" / f"{bug_id}-validated.jsonl"
    if not result_file.is_file():
        return []
    try:
        payload = json.loads(result_file.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []
    return [item for item in payload if isinstance(item, Mapping)] if isinstance(payload, list) else []


def _text(value: Any, default: str = "-") -> str:
    if value is None or value == "":
        return default
    return str(value).replace("|", "\\|").replace("\n", " ")


def _indices(indices: Sequence[Any]) -> str:
    return ",".join(map(str, indices)) if indices else "-"


def _pcsf_label(entry: Mapping[str, Any]) -> str:
    status = str(entry.get("pcsf_status", "not_run"))
    if status == "available" and entry.get("pcsf_result", {}).get("signals"):
        return "triggered"
    return "no_signal" if status in {"available", "no_signal"} else "skipped"


def _dataflow_by_candidate(entry: Mapping[str, Any]) -> dict[int, str]:
    result: dict[int, str] = {}
    for item in entry.get("dataflow_candidates", []):
        if isinstance(item, Mapping) and isinstance(item.get("candidate_index"), int):
            result[item["candidate_index"]] = "unknown" if item.get("score") is None else _text(item["score"])
    return result


def _control_by_candidate(entry: Mapping[str, Any]) -> dict[int, str]:
    result: dict[int, str] = {}
    for item in entry.get("control_candidates", []):
        if isinstance(item, Mapping) and isinstance(item.get("candidate_index"), int):
            result[item["candidate_index"]] = f"risk={item['risk']}" if item.get("risk") in {0, 1} else _text(item.get("status"), "unknown")
    return result


def _write_candidate_diffs(round_dir: Path, current_code: str, records: Sequence[Mapping[str, Any]]) -> None:
    """Save compact diffs only; no Defects4J/Joern/project copy is made."""
    diff_dir = round_dir / "candidate_diffs"
    diff_dir.mkdir(parents=True, exist_ok=True)
    for record in records:
        index, patch = record.get("candidate_index"), record.get("patch_code")
        if not isinstance(index, int) or not isinstance(patch, str):
            continue
        text = "\n".join(difflib.unified_diff(
            current_code.splitlines(), patch.splitlines(), fromfile="P_t",
            tofile=f"candidate_{index}", lineterm="",
        ))
        if len(text) > 12_000:
            text = text[:12_000] + "\n... diff truncated for compact output ..."
        (diff_dir / f"candidate_{index}.diff").write_text(text + ("\n" if text else ""), encoding="utf-8")


def _checkpoint_path(run_dir: Path) -> Path:
    return run_dir / CHECKPOINT_NAME


def _is_resumable_run(run_dir: Path, bug_id: str) -> bool:
    """Accept an existing directory only for an explicit unfinished resume."""
    checkpoint = _checkpoint_path(run_dir)
    # A partial failure summary does not complete a run; checkpoint is authoritative.
    if not checkpoint.is_file():
        return False
    try:
        payload = json.loads(checkpoint.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return False
    return payload.get("bug_id") == bug_id and payload.get("status") == "running"


def _write_checkpoint(run_dir: Path, bug_id: str) -> None:
    _checkpoint_path(run_dir).write_text(
        json.dumps({"bug_id": bug_id, "status": "running"}, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )


def _remove_path(path: Path) -> None:
    if path.is_dir() and not path.is_symlink():
        shutil.rmtree(path)
    elif path.exists() or path.is_symlink():
        path.unlink()


def finalize_run_output(run_dir: Path) -> None:
    """Clean only after a normally returned terminal experiment result."""
    for name in _TEMPORARY_NAMES:
        _remove_path(run_dir / name)
    for round_dir in run_dir.glob("round_[1-3]"):
        if round_dir.is_dir():
            for name in _TEMPORARY_NAMES - {VALIDATION_DIRNAME, "validator_results", "runner_result.json"}:
                _remove_path(round_dir / name)
    _remove_path(_checkpoint_path(run_dir))


def write_summary(run_dir: Path, result: Mapping[str, Any], initial_code: str | None = None) -> Path:
    bug_id = str(result["bug_id"])
    rounds = [entry for entry in result.get("rounds", []) if isinstance(entry, Mapping)]
    status = str(result.get("status") or ("SUCCESS" if result.get("termination") == "all_tests_pass" else "FAILED"))
    final = next((entry.get("selected_candidate_index") for entry in reversed(rounds) if entry.get("selected_candidate_index") is not None), "-")
    lines = [f"# PaceFix experiment: {bug_id}", "", f"- Status: {status}",
             f"- Termination reason: {_text(result.get('termination'))}",
             f"- Initial failed tests: {len(rounds[0].get('current_failed_tests', [])) if rounds else '-'}",
             f"- Rounds: {len(rounds)}", f"- Final candidate: {final}",
             f"- Remaining failed tests: {len(result.get('final_failed_tests', []))}", "",
             "| Round | generated | acceptable | max-progress | Dataflow | Control | selected P* | PCSF | next_failed_tests |",
             "|---|---:|---:|---|---|---|---|---|---:|"]
    for entry in rounds:
        lines.append(
            f"| {int(entry['round_id'])} | {entry.get('generated_count', 0)} | {len(entry.get('acceptable_indices', []))} | "
            f"{_indices(entry.get('max_progress_indices', []))} | {_text(entry.get('dataflow_status'))} "
            f"({_indices(entry.get('dataflow_remaining_indices', []))}) | {_text(entry.get('control_status'))} "
            f"({_indices(entry.get('control_remaining_indices', []))}) | {_text(entry.get('selected_candidate_index'))} | "
            f"{_pcsf_label(entry)} | {_indices(entry.get('next_failed_tests', []))} |"
        )
    summary = run_dir / "summary.md"
    summary.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return summary


def _partial_failure_result(run_dir: Path, bug_id: str, exc: Exception) -> dict[str, Any]:
    """Create a truthful, resumable report using only durable round traces."""
    rounds: list[Mapping[str, Any]] = []
    for trace_file in sorted(run_dir.glob("round_[1-3]/runner_trace.json")):
        try:
            trace = json.loads(trace_file.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if isinstance(trace, Mapping) and trace.get("bug_id") == bug_id:
            rounds.append(trace)
    failed = list(rounds[-1].get("current_failed_tests", [])) if rounds else []
    return {
        "bug_id": bug_id,
        "status": "FAILED",
        "termination": f"execution_error:{type(exc).__name__}",
        "rounds": rounds,
        "final_failed_tests": failed,
    }


def run_experiment(
    bug_id: str, output_root: Path = DEFAULT_OUTPUT_ROOT, run_dir: Path | None = None,
    *, ensure_services: bool = True, dataset_path: Path = DATASET_FILE,
) -> tuple[Path, Mapping[str, Any]]:
    dataset_path = Path(dataset_path).resolve()
    bug_id = validate_bug_id(bug_id, dataset_path)
    chosen = run_dir.resolve() if run_dir else _bug_output_dir(output_root.resolve(), bug_id)
    if chosen.exists() and any(chosen.iterdir()):
        if run_dir is None:
            raise RuntimeError(f"existing_bug_result_requires_explicit_cleanup:{chosen}")
        if not _is_resumable_run(chosen, bug_id):
            raise RuntimeError(f"bug_directory_not_resumable:{chosen}")
    chosen.mkdir(parents=True, exist_ok=True)
    if ensure_services:
        ensure_formal_services()
    _write_checkpoint(chosen, bug_id)
    code, failed_tests, context, state_hash = _initial_state(bug_id, chosen, dataset_path)
    hooks = build_real_runner_hooks(
        dataset_path=str(dataset_path), validation_output_dir=str(chosen / VALIDATION_DIRNAME),
    )
    try:
        result = run_three_rounds(
            bug_id, str(chosen), code, failed_tests, context, hooks,
            initial_state_sha256=state_hash,
        )
    except Exception as exc:
        # Keep checkpoint/artifacts for a safe resume, but never let batch mode
        # advance without a durable report of the interrupted Bug.
        write_summary(chosen, _partial_failure_result(chosen, bug_id, exc), code)
        raise RuntimeError(f"experiment_execution_error:{type(exc).__name__}:{exc}") from exc
    write_summary(chosen, result, code)
    finalize_run_output(chosen)
    return chosen, result


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Run the formal PaceFix three-round experiment.")
    parser.add_argument("--bug", help="Defects4J bug id, for example Chart-20")
    parser.add_argument("--dataset", choices=dataset_choices(), default="v1.2")
    parser.add_argument("--output-root", type=Path)
    parser.add_argument("--run-dir", type=Path, help="Explicit unfinished Bug directory for checkpoint resume")
    parser.add_argument("--report-only", type=Path, metavar="RUN_DIR", help="Regenerate summary from runner_result.json without API/validation")
    args = parser.parse_args(sys.argv[1:] if argv is None else argv)
    if args.report_only:
        result_file = args.report_only / "runner_result.json"
        if not result_file.is_file():
            print(f"ERROR: runner_result_missing:{result_file}", file=sys.stderr)
            return 2
        result = json.loads(result_file.read_text(encoding="utf-8"))
        if isinstance(result, Mapping) and isinstance(result.get("result"), Mapping):
            result = result["result"]
        print(write_summary(args.report_only, result))
        return 0
    profile = get_dataset_profile(args.dataset)
    output_root = args.output_root or profile.output_root
    bug_id = args.bug
    if bug_id is None:
        try:
            bug_id = input("Bug ID (for example Chart-20; press Enter to exit): ").strip()
        except EOFError:
            return 0
        if not bug_id:
            return 0
    try:
        run_dir, result = run_experiment(
            bug_id, output_root, args.run_dir, dataset_path=profile.dataset_path,
        )
    except (ValueError, RuntimeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    print(f"Result: {run_dir / 'summary.md'}")
    print(f"Termination: {result['termination']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
