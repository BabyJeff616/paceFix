# Functional Progress filtering for validator result records.
#
# This module is intentionally limited to the Progress stage. It consumes the
# facts recorded by pacefix_validator and does not select among tied candidates.

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Mapping, Sequence


FT_BLOCKING_STATUSES = {"TIMEOUT", "ERROR"}
FULL_SUITE_BLOCKING_STATUSES = {"TIMEOUT", "ERROR"}


def _require_mapping(value: Any, field_name: str, candidate_index: Any) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise ValueError(
            f"candidate {candidate_index}: {field_name} must be an object"
        )
    return value


def _require_list(value: Any, field_name: str, candidate_index: Any) -> list[str]:
    if not isinstance(value, list):
        raise ValueError(
            f"candidate {candidate_index}: {field_name} must be a list"
        )
    return value


def _shared_field(
    candidates: Sequence[Mapping[str, Any]], field_name: str
) -> Any:
    first = candidates[0].get(field_name)
    for candidate in candidates[1:]:
        if candidate.get(field_name) != first:
            raise ValueError(
                f"validator input contains multiple {field_name} values"
            )
    return first


def summarize_candidate(
    candidate: Mapping[str, Any], current_failed_tests: Sequence[str]
) -> dict[str, Any]:
    # Reject incomplete validator records rather than interpreting them as
    # successful execution. Every test in F_t must have a recorded result.
    candidate_index = candidate.get("candidate_index")
    ft_results = _require_mapping(
        candidate.get("ft_test_results"), "ft_test_results", candidate_index
    )
    full_suite_failures = _require_list(
        candidate.get("full_suite_failing_tests"),
        "full_suite_failing_tests",
        candidate_index,
    )

    repaired: list[str] = []
    remaining: list[str] = []
    ft_has_blocking_status = False
    compile_status = candidate.get("compile_status")
    # Compile-failed candidates have no F_t execution facts. They are
    # unconditionally unacceptable, so retain F_t without requiring tests the
    # validator could not have run.
    if compile_status != "PASS":
        remaining = list(current_failed_tests)
    else:
        for test_name in current_failed_tests:
            if test_name not in ft_results:
                raise ValueError(
                    f"candidate {candidate_index}: missing F_t result for {test_name}"
                )
            test_result = _require_mapping(
                ft_results[test_name], f"ft_test_results[{test_name!r}]", candidate_index
            )
            status = test_result.get("status")
            if status == "PASS":
                repaired.append(test_name)
            else:
                remaining.append(test_name)
            if status in FT_BLOCKING_STATUSES:
                ft_has_blocking_status = True

    current_failure_set = set(current_failed_tests)
    new_regressions = [
        test_name
        for test_name in full_suite_failures
        if test_name not in current_failure_set
    ]

    full_suite_ran = candidate.get("full_suite_ran") is True
    full_suite_status = candidate.get("full_suite_status")
    full_suite_completed = full_suite_status in {"PASS", "FAIL"}
    full_suite_blocked = full_suite_status in FULL_SUITE_BLOCKING_STATUSES

    acceptable = (
        compile_status == "PASS"
        and len(repaired) >= 1
        and not ft_has_blocking_status
        and full_suite_ran
        and full_suite_completed
        and not full_suite_blocked
        and not new_regressions
    )

    return {
        "candidate_index": candidate_index,
        "repaired_failing_tests": repaired,
        "remaining_failing_tests": remaining,
        "new_regression_tests": new_regressions,
        "acceptable": acceptable,
        "progress": len(repaired),
    }


def analyze_validator_results(records: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    # Apply acceptable-candidate filtering and maximum Progress layering.
    if not records:
        raise ValueError("validator input must contain at least one candidate")
    if not all(isinstance(record, Mapping) for record in records):
        raise ValueError("validator input must be a JSON array of objects")

    bug_id = _shared_field(records, "bug_id")
    round_id = _shared_field(records, "round_id")
    current_failed_tests = _shared_field(records, "current_failed_tests")
    current_failed_tests = _require_list(
        current_failed_tests, "current_failed_tests", "input"
    )

    candidates = [
        summarize_candidate(candidate, current_failed_tests)
        for candidate in records
    ]
    acceptable_candidates = [
        candidate for candidate in candidates if candidate["acceptable"]
    ]

    if not acceptable_candidates:
        return {
            "bug_id": bug_id,
            "round_id": round_id,
            "current_failed_tests": current_failed_tests,
            "candidates": candidates,
            "max_progress": 0,
            "max_progress_candidate_indices": [],
            "decision": "no_acceptable_candidate",
            "selected_candidate": None,
            "max_progress_candidates": [],
        }

    max_progress = max(candidate["progress"] for candidate in acceptable_candidates)
    max_progress_candidates = [
        candidate
        for candidate in acceptable_candidates
        if candidate["progress"] == max_progress
    ]
    candidate_indices = [
        candidate["candidate_index"] for candidate in max_progress_candidates
    ]

    if len(max_progress_candidates) == 1:
        decision = "unique_max_progress"
        selected_candidate = max_progress_candidates[0]
    else:
        decision = "ambiguous_max_progress"
        selected_candidate = None

    return {
        "bug_id": bug_id,
        "round_id": round_id,
        "current_failed_tests": current_failed_tests,
        "candidates": candidates,
        "max_progress": max_progress,
        "max_progress_candidate_indices": candidate_indices,
        "decision": decision,
        "selected_candidate": selected_candidate,
        "max_progress_candidates": max_progress_candidates,
    }


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Compute Functional Progress from validator JSON results."
    )
    parser.add_argument(
        "--input", required=True, help="Validator JSON array input file."
    )
    parser.add_argument(
        "--output", required=True, help="Progress JSON output file."
    )
    args = parser.parse_args()

    with open(args.input, "r", encoding="utf-8") as input_file:
        records = json.load(input_file)
    result = analyze_validator_results(records)

    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", encoding="utf-8") as output_file:
        json.dump(result, output_file, indent=2)
        output_file.write("\n")


if __name__ == "__main__":
    main()
