"""Readiness management for local services required by formal experiments."""
from __future__ import annotations

import json
import os
import socket
import subprocess
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, TextIO
from urllib.request import urlopen

from cpgqls_client import CPGQLSClient

REPO_ROOT = Path(__file__).resolve().parents[2]
RAG_PORT = 5000
JOERN_PORT = 8081
JOERN = "/home/reinfix/tools/joern-v4.0.6/joern-cli/joern"
JAVA21 = "/usr/lib/jvm/java-21-openjdk-amd64"

@dataclass(frozen=True)
class ServiceSpec:
    name: str
    health: Callable[[], bool]
    running: Callable[[], bool]
    start: Callable[[], subprocess.Popen | None]
    stop: Callable[[], None]

def _port_open(port: int) -> bool:
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=2):
            return True
    except OSError:
        return False

def _rag_ready() -> bool:
    if not _port_open(RAG_PORT):
        return False
    try:
        with urlopen("http://127.0.0.1:5000/health", timeout=3) as response:
            return response.status == 200 and json.loads(response.read().decode("utf-8")).get("ready") is True
    except Exception:
        return False

def _joern_ready() -> bool:
    if not _port_open(JOERN_PORT):
        return False
    try:
        return isinstance(CPGQLSClient("localhost:8081").execute("workspace"), dict)
    except Exception:
        return False

def _matching_processes(marker: str) -> list[int]:
    result = subprocess.run(["ps", "-eo", "pid=,args="], text=True, capture_output=True, check=False)
    return [int(fields[0]) for line in result.stdout.splitlines() if marker in line
            for fields in [line.strip().split(maxsplit=1)] if fields and fields[0].isdigit()]

def _stop_matching(marker: str) -> None:
    for pid in _matching_processes(marker):
        subprocess.run(["kill", "-TERM", str(pid)], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    deadline = time.monotonic() + 10
    while _matching_processes(marker) and time.monotonic() < deadline:
        time.sleep(0.2)
    for pid in _matching_processes(marker):
        subprocess.run(["kill", "-KILL", str(pid)], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

def _start_rag() -> subprocess.Popen:
    return subprocess.Popen([sys.executable, "-m", "src.rag_search_server"], cwd=REPO_ROOT,
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, text=True, start_new_session=True)

def _start_joern() -> subprocess.Popen:
    env = dict(os.environ, JAVA_HOME=JAVA21, PATH=JAVA21 + "/bin:" + os.environ.get("PATH", ""))
    # A full Closure CPG can otherwise grow until the JVM stops answering
    # CPGQLS requests. Keep a bounded heap so a failed import is recoverable.
    return subprocess.Popen([JOERN, "-J-Xms512m", "-J-Xmx4g", "--server", "--server-host", "127.0.0.1", "--server-port", str(JOERN_PORT)],
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, text=True, env=env, start_new_session=True)

RAG_SERVICE = ServiceSpec("RAG", _rag_ready, lambda: _port_open(RAG_PORT), _start_rag, lambda: _stop_matching("src.rag_search_server"))
JOERN_SERVICE = ServiceSpec("Joern", _joern_ready, lambda: _port_open(JOERN_PORT), _start_joern, lambda: _stop_matching("joern --server"))

def ensure_service(service: ServiceSpec, *, poll_seconds: float = 5, timeout_seconds: float = 300,
                   stream: TextIO | None = None) -> None:
    """Ensure a service is queryable; one restart is permitted after failure."""
    out = stream or sys.stdout
    if service.health():
        print("Already running", file=out, flush=True)
        return
    for attempt in range(2):
        process = None
        if attempt:
            print("Restarting", file=out, flush=True)
            service.stop()
            process = service.start()
        elif not service.running():
            print("Starting...", file=out, flush=True)
            process = service.start()
        began = time.monotonic()
        while time.monotonic() - began < timeout_seconds:
            if service.health():
                print("Ready", file=out, flush=True)
                return
            if (process is not None and process.poll() is not None) or (process is None and not service.running()):
                break
            print(f"Waiting... {int(time.monotonic() - began)}s", file=out, flush=True)
            time.sleep(poll_seconds)
    service.stop()
    print("Failed", file=out, flush=True)
    raise RuntimeError(f"required_service_unavailable:{service.name}")

def ensure_formal_services() -> None:
    for service in (RAG_SERVICE, JOERN_SERVICE):
        ensure_service(service)


def restart_joern_service() -> None:
    """Recover a live-but-unusable Joern server once after a CPGQLS failure."""
    print("Restarting", flush=True)
    JOERN_SERVICE.stop()
    # The shell launcher can exit while its Java ReplBridge remains alive.
    _stop_matching("io.joern.joerncli.console.ReplBridge")
    deadline = time.monotonic() + 15
    while _port_open(JOERN_PORT) and time.monotonic() < deadline:
        time.sleep(0.2)
    if _port_open(JOERN_PORT):
        raise RuntimeError("joern_port_remained_open_after_restart")
    ensure_service(JOERN_SERVICE)
