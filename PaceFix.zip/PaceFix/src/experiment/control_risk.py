from __future__ import annotations
import argparse, hashlib, json, os, re, signal, subprocess, tempfile, xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any, Mapping, Sequence

from src.experiment.dataflow_evidence import get_cached_pt_coverage
from src.experiment.pacefix_validator import defects4j_environment

GUMTREE = "/home/reinfix/tools/gumtree/bin/gumtree"
DEFECTS4J = "/home/reinfix/defects4j-2.0.0/framework/bin/defects4j"
JOERN = "/home/reinfix/tools/joern-v4.0.6/joern-cli/joern"
JOERN_PARSE = "/home/reinfix/tools/joern-v4.0.6/joern-cli/joern-parse"
JAVA21 = "/usr/lib/jvm/java-21-openjdk-amd64"
CONTROL_NODE_TYPES = {"IfStatement", "SwitchStatement", "ForStatement", "EnhancedForStatement", "WhileStatement", "DoStatement", "ConditionalExpression", "ReturnStatement", "BreakStatement", "ContinueStatement", "ThrowStatement"}
CONTROL_STRUCTURE_ANCHOR_TYPES = {"IfStatement", "SwitchStatement", "ForStatement", "EnhancedForStatement", "WhileStatement", "DoStatement", "ConditionalExpression"}

def run_command(command: Sequence[str], timeout: int, env: Mapping[str, str] | None = None) -> tuple[str, str, str]:
    """Run one external tool with bounded output and kill its whole process group.

    Defects4J and Joern both start child JVMs. Killing only their launcher leaves
    children holding pipes/the temporary checkout open after a timeout.
    """
    process = None
    try:
        process = subprocess.Popen(
            command, text=True, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, env=env, start_new_session=True,
        )
        stdout, stderr = process.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        if process is not None:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            stdout, stderr = process.communicate()
        else:
            stdout, stderr = "", ""
        return "TIMEOUT", stdout, (stderr + "\nTIMEOUT").strip()
    except OSError as exc:
        return "ERROR", "", str(exc)
    return ("PASS", stdout, stderr) if process.returncode == 0 else ("ERROR", stdout, stderr)

def _java21_command(command: Sequence[str]) -> list[str]:
    path = f"{JAVA21}/bin:" + os.environ.get("PATH", "")
    return ["env", f"JAVA_HOME={JAVA21}", f"PATH={path}", *command]

def gumtree_json(pt_code: str, candidate_code: str, timeout: int = 60) -> dict[str, Any]:
    with tempfile.TemporaryDirectory(prefix="pacefix_control_gumtree_") as directory:
        pt_path, candidate_path = Path(directory) / "Pt.java", Path(directory) / "Candidate.java"
        pt_path.write_text(pt_code, encoding="utf-8")
        candidate_path.write_text(candidate_code, encoding="utf-8")
        status, stdout, stderr = run_command(_java21_command([GUMTREE, "textdiff", "-g", "java-jdt", "-f", "JSON", str(pt_path), str(candidate_path)]), timeout)
    if status != "PASS":
        raise RuntimeError(f"GumTree {status}: {stderr.strip()}")
    payload = stdout.strip()
    if not payload:
        try:
            json.loads(stderr)
        except json.JSONDecodeError as exc:
            raise ValueError(f"GumTree JSON stdout empty: {stderr.strip()}") from exc
        payload = stderr
    result = json.loads(payload)
    if not isinstance(result, dict) or not isinstance(result.get("actions"), list) or not isinstance(result.get("matches"), list):
        raise ValueError("unexpected GumTree JSON")
    return result

MATCH_RANGE = re.compile(r"^(?P<type>.+?) \[(?P<start>\d+),(?P<length>\d+)\]$")


def _line_offset(code: str, line_number: int) -> int:
    if line_number < 1:
        raise ValueError("invalid line number")
    offsets = [0]
    for index, char in enumerate(code):
        if char == "\n":
            offsets.append(index + 1)
    if line_number > len(offsets):
        raise ValueError("defect line outside P0 function")
    return offsets[line_number - 1]


def _match_node(description: str) -> dict[str, Any] | None:
    match = MATCH_RANGE.match(description)
    if not match:
        return None
    start, end = int(match["start"]), int(match["length"])
    return {"node_type": match["type"], "start_offset": start,
            "end_offset": end, "length": end - start}


def map_p0_defect_anchor(p0_code: str, current_state_code: str) -> dict[str, Any]:
    """Map the smallest P0 code AST node containing the bug-marker line to P_t."""
    marker = "/* bug is here */"
    if p0_code.count(marker) != 1:
        return {"status": "unavailable", "reason": "p0_bug_marker_not_unique"}
    marker_position = p0_code.index(marker)
    bug_line = p0_code[:marker_position].count("\n") + 1
    prefix = "class AnchorWrapper {\n"
    suffix = "\n}\n"
    try:
        matches = gumtree_json(prefix + p0_code + suffix, prefix + current_state_code + suffix)["matches"]
    except Exception as exc:
        return {"status": "unavailable", "reason": "gumtree_mapping_failed", "detail": str(exc)}
    candidates = []
    for item in matches:
        src, dest = _match_node(str(item.get("src", ""))), _match_node(str(item.get("dest", "")))
        if src is None or dest is None or src["node_type"] in {"CompilationUnit", "Block"}:
            continue
        if src["start_offset"] <= marker_position + len(prefix) < src["end_offset"]:
            src = dict(src, start_offset=src["start_offset"] - len(prefix), end_offset=src["end_offset"] - len(prefix))
            dest = dict(dest, start_offset=dest["start_offset"] - len(prefix), end_offset=dest["end_offset"] - len(prefix))
            candidates.append((src["length"], src, dest))
    if not candidates:
        return {"status": "unavailable", "reason": "p0_anchor_missing_from_matches"}
    smallest = min(length for length, _, _ in candidates)
    choices = [(src, dest) for length, src, dest in candidates if length == smallest]
    if len(choices) != 1:
        return {"status": "unavailable", "reason": "p0_anchor_mapping_not_unique"}
    source, destination = choices[0]
    if destination["start_offset"] < 0 or destination["end_offset"] > len(current_state_code):
        return {"status": "unavailable", "reason": "mapped_anchor_outside_current_function"}
    return {"status": "PASS", "p0_bug_line": bug_line,
            "p0_anchor": source, "current_anchor": destination}


def _apply_function(work_dir, bug, code):
    target = work_dir / bug["loc"]
    try:
        text = target.read_text(encoding="utf-8")
        encoding = "utf-8"
    except UnicodeDecodeError:
        text = target.read_text(encoding="ISO-8859-1")
        encoding = "ISO-8859-1"
    lines = text.splitlines(keepends=True)
    start, end = int(bug["start"]), int(bug["end"])
    replacement = code.strip() + "\n"
    lines[start - 1:end] = [replacement]
    target.write_text("".join(lines), encoding=encoding)
    return start, start + replacement.count("\n") - 1

def collect_current_state_coverage(bug_id, dataset, current_state_code, failed_tests, timeout=300):
    if bug_id not in dataset or not failed_tests:
        return {"status": "unavailable", "reason": "missing_bug_or_failed_tests", "tests": {}}
    start = int(dataset[bug_id]["start"])
    end = start + current_state_code.strip().count("\n")
    state_hash = hashlib.sha256(current_state_code.encode("utf-8")).hexdigest()
    cached = {test: get_cached_pt_coverage(bug_id, state_hash, str(test), start, end) for test in failed_tests}
    if all(item is not None for item in cached.values()):
        return {"status": "PASS", "function_start": start, "function_end": end,
                "tests": {str(test): cached[test] for test in failed_tests}, "source": "dataflow_pt_coverage_cache"}
    project, version = bug_id.split("-", 1)
    results = {}
    with tempfile.TemporaryDirectory(prefix="pacefix_control_coverage_") as directory:
        work_dir = Path(directory) / bug_id
        status, _, err = run_command([DEFECTS4J, "checkout", "-p", project, "-v", version + "b", "-w", str(work_dir)], timeout, defects4j_environment())
        if status != "PASS":
            return {"status": "unavailable", "reason": "checkout_" + status.lower(), "detail": err.strip(), "tests": results}
        try:
            start, end = _apply_function(work_dir, dataset[bug_id], current_state_code)
        except Exception as exc:
            return {"status": "unavailable", "reason": "current_state_apply_failed", "detail": str(exc), "tests": results}
        for test_name in failed_tests:
            xml_path = work_dir / "coverage.xml"
            if xml_path.exists(): xml_path.unlink()
            status, _, err = run_command([DEFECTS4J, "coverage", "-w", str(work_dir), "-t", test_name], timeout, defects4j_environment())
            if status != "PASS" or not xml_path.is_file():
                reason = "coverage_" + status.lower() if status != "PASS" else "coverage_xml_missing"
                results[test_name] = {"status": "unavailable", "reason": reason, "detail": err.strip()}
                return {"status": "unavailable", "reason": reason, "function_start": start, "function_end": end, "tests": results}
            try:
                root = ET.parse(xml_path).getroot()
                executed = sorted({int(line.attrib["number"]) for line in root.findall(".//line") if start <= int(line.attrib.get("number", -1)) <= end and int(line.attrib.get("hits", "0")) > 0})
            except (ET.ParseError, ValueError) as exc:
                results[test_name] = {"status": "unavailable", "reason": "coverage_xml_parse_failed", "detail": str(exc)}
                return {"status": "unavailable", "reason": "coverage_xml_parse_failed", "function_start": start, "function_end": end, "tests": results}
            results[test_name] = {"status": "PASS", "executed_lines": executed}
    return {"status": "PASS", "function_start": start, "function_end": end, "tests": results}


def _offset_line_number(code: str, offset: int) -> int:
    if offset < 0 or offset > len(code):
        raise ValueError("offset outside function")
    return code[:offset].count("\n") + 1


def _joern_current_operations(current_state_code: str, timeout: int = 120) -> dict[str, Any]:
    """Query the supported operation nodes from one wrapped target function."""
    prefix = "class ControlWrapper {\n"
    suffix = "\n}\n"
    script = r"""import io.shiftleft.semanticcpg.language._
import io.shiftleft.codepropertygraph.generated.nodes._
import ujson._

@main def main(cpgFile: String, outFile: String): Unit = {
  importCpg(cpgFile)
  def sourceLines(node: AstNode): List[Int] = node.ast.lineNumber.l.distinct.sorted
  def row(kind: String, node: AstNode, methodFullName: String = ""): Obj = {
    val lines = sourceLines(node)
    Obj(
      "kind" -> kind,
      "label" -> node.label,
      "name" -> (node match { case call: Call => call.name; case _ => "" }),
      "code" -> node.code,
      "lineNumber" -> node.lineNumber.getOrElse(-1),
      "columnNumber" -> node.columnNumber.getOrElse(-1),
      "id" -> node.id,
      "methodFullName" -> methodFullName,
      "astLines" -> Arr.from(lines)
    )
  }
  val operations = cpg.method.ast.l.flatMap {
    case call: Call if call.name == "<operator>.throw" => List(row("throw", call, call.methodFullName))
    case call: Call if call.name == "<operator>.assignment" && (call.argument(1) match { case lhs: Call => lhs.name == "<operator>.fieldAccess"; case _ => false }) =>
      List(row("field_assignment", call, call.methodFullName))
    case call: Call if !call.name.startsWith("<operator>.") && call.name != "<init>" =>
      List(row("call", call, call.methodFullName))
    case node if node.label == "RETURN" => List(row("return", node))
    case _ => Nil
  }
  ujson.write(Arr.from(operations), indent = 2) #> outFile
}
"""
    with tempfile.TemporaryDirectory(prefix="pacefix_control_joern_") as directory:
        directory_path = Path(directory)
        source_path = directory_path / "ControlWrapper.java"
        cpg_path = directory_path / "cpg.bin"
        script_path = directory_path / "query.sc"
        output_path = directory_path / "operations.json"
        source_path.write_text(prefix + current_state_code + suffix, encoding="utf-8")
        script_path.write_text(script, encoding="utf-8")
        status, _, err = run_command(_java21_command([JOERN_PARSE, str(directory_path), "--output", str(cpg_path)]), timeout)
        if status != "PASS":
            return {"status": "unavailable", "reason": "joern_parse_" + status.lower(), "detail": err.strip()}
        status, _, err = run_command(_java21_command([JOERN, "--script", str(script_path), "--param", f"cpgFile={cpg_path}", "--param", f"outFile={output_path}", "--nocolors"]), timeout)
        if status != "PASS" or not output_path.is_file():
            reason = "joern_query_" + status.lower() if status != "PASS" else "joern_output_missing"
            return {"status": "unavailable", "reason": reason, "detail": err.strip()}
        try:
            operations = json.loads(output_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            return {"status": "unavailable", "reason": "joern_output_parse_failed", "detail": str(exc)}
    if not isinstance(operations, list):
        return {"status": "unavailable", "reason": "joern_output_not_array"}
    normalized = []
    prefix_lines = prefix.count("\n")
    for item in operations:
        if not isinstance(item, dict) or not isinstance(item.get("astLines"), list):
            return {"status": "unavailable", "reason": "joern_operation_malformed"}
        lines = sorted({int(line) - prefix_lines for line in item["astLines"] if isinstance(line, int) and int(line) > prefix_lines})
        if not lines:
            continue
        line_number = item.get("lineNumber")
        column_number = item.get("columnNumber")
        exact_line = int(line_number) - prefix_lines if isinstance(line_number, int) and int(line_number) > prefix_lines else None
        exact_column = int(column_number) if isinstance(column_number, int) and int(column_number) > 0 else None
        normalized.append({
            "kind": item.get("kind"), "label": item.get("label"), "name": item.get("name"),
            "code": item.get("code"), "line_start": min(lines), "line_end": max(lines),
            "line_number": exact_line, "column_number": exact_column,
            "ast_lines": lines, "joern_id": item.get("id"), "method_full_name": item.get("methodFullName"),
        })
    return {"status": "PASS", "operations": normalized}


def _p0_code_with_bug_marker(bug: Mapping[str, Any]) -> str | None:
    code = bug.get("buggy_fl")
    marker = "/* bug is here */"
    if not isinstance(code, str):
        return None
    if code.count(marker) == 1:
        return code
    location, start = bug.get("location"), bug.get("start")
    if code.count(marker) != 0 or not isinstance(location, list) or len(location) != 1 or not isinstance(location[0], int) or not isinstance(start, int):
        return None
    local_line = location[0] - start + 1
    lines = code.splitlines(keepends=True)
    if local_line < 1 or local_line > len(lines):
        return None
    line = lines[local_line - 1]
    ending = "\r\n" if line.endswith("\r\n") else "\n" if line.endswith("\n") else ""
    lines[local_line - 1] = line[:-len(ending)] if ending else line
    lines[local_line - 1] += " " + marker + ending
    return "".join(lines)


def determine_current_key_operations(bug_id: str, dataset: Mapping[str, Any], current_state_code: str,
                                     coverage: Mapping[str, Any], timeout: int = 120) -> dict[str, Any]:
    """Fix one P_t operation baseline for every candidate in the Control layer."""
    if coverage.get("status") != "PASS":
        return {"status": "unavailable", "reason": "current_coverage_unavailable"}
    bug = dataset.get(bug_id)
    p0_code = _p0_code_with_bug_marker(bug) if isinstance(bug, Mapping) else None
    if not isinstance(p0_code, str):
        return {"status": "unavailable", "reason": "p0_function_or_bug_marker_missing"}
    anchor = map_p0_defect_anchor(p0_code, current_state_code)
    if anchor.get("status") != "PASS":
        return {"status": "unavailable", "reason": anchor.get("reason", "anchor_mapping_failed"), "anchor": anchor}
    try:
        scope_start = _offset_line_number(current_state_code, anchor["current_anchor"]["start_offset"])
        scope_end = _offset_line_number(current_state_code, anchor["current_anchor"]["end_offset"])
    except (KeyError, TypeError, ValueError) as exc:
        return {"status": "unavailable", "reason": "mapped_anchor_range_invalid", "detail": str(exc), "anchor": anchor}
    joern = _joern_current_operations(current_state_code, timeout)
    if joern.get("status") != "PASS":
        return {"status": "unavailable", "reason": joern.get("reason", "joern_unavailable"), "detail": joern.get("detail"), "anchor": anchor}
    if anchor["current_anchor"].get("node_type") in CONTROL_STRUCTURE_ANCHOR_TYPES:
        # A terminating operation inside the defect control branch is the mechanism
        # being repaired, not a protected operation.  Only use executed normal
        # continuation operations after the complete control structure.
        scoped = [operation for operation in joern["operations"] if operation["line_start"] > scope_end]
        scope_kind = "after_control_anchor"
    else:
        scoped = [operation for operation in joern["operations"]
                  if scope_start <= operation["line_start"] and operation["line_end"] <= scope_end]
        scope_kind = "within_non_control_anchor"
    per_test: dict[str, Any] = {}
    for test_name, test_coverage in coverage.get("tests", {}).items():
        if test_coverage.get("status") != "PASS":
            return {"status": "unavailable", "reason": "test_coverage_unavailable", "test": test_name, "anchor": anchor}
        executed_lines = {int(line) for line in test_coverage.get("executed_lines", [])}
        function_start = coverage.get("function_start")
        if not isinstance(function_start, int):
            return {"status": "unavailable", "reason": "coverage_function_start_missing", "test": test_name, "anchor": anchor}
        function_executed_lines = {line - function_start + 1 for line in executed_lines}
        operations = [operation for operation in scoped if function_executed_lines.intersection(operation["ast_lines"])]
        if not operations:
            return {"status": "unavailable", "reason": "key_operations_empty", "test": test_name, "anchor": anchor, "scope": {"kind": scope_kind, "line_start": scope_start, "line_end": scope_end}, "tests": per_test}
        per_test[test_name] = {"executed_lines": sorted(executed_lines),
                               "function_executed_lines": sorted(function_executed_lines),
                               "operations": operations}
    return {"status": "PASS", "anchor": anchor, "scope": {"kind": scope_kind, "line_start": scope_start, "line_end": scope_end}, "tests": per_test}


def collect_candidate_coverage(bug_id: str, dataset: Mapping[str, Any], candidate_code: str,
                               failed_tests: Sequence[str], timeout: int = 300) -> dict[str, Any]:
    """Run the same F_t coverage tests on one independently restored candidate."""
    if bug_id not in dataset or not failed_tests:
        return {"status": "unavailable", "reason": "missing_bug_or_failed_tests", "tests": {}}
    project, version = bug_id.split("-", 1)
    results = {}
    with tempfile.TemporaryDirectory(prefix="pacefix_control_candidate_coverage_") as directory:
        work_dir = Path(directory) / bug_id
        status, _, err = run_command([DEFECTS4J, "checkout", "-p", project, "-v", version + "b", "-w", str(work_dir)], timeout, defects4j_environment())
        if status != "PASS":
            return {"status": "unavailable", "reason": "checkout_" + status.lower(), "detail": err.strip(), "tests": results}
        try:
            start, end = _apply_function(work_dir, dataset[bug_id], candidate_code)
        except Exception as exc:
            return {"status": "unavailable", "reason": "candidate_apply_failed", "detail": str(exc), "tests": results}
        for test_name in failed_tests:
            xml_path = work_dir / "coverage.xml"
            if xml_path.exists():
                xml_path.unlink()
            status, _, err = run_command([DEFECTS4J, "coverage", "-w", str(work_dir), "-t", test_name], timeout, defects4j_environment())
            if status != "PASS" or not xml_path.is_file():
                reason = "coverage_" + status.lower() if status != "PASS" else "coverage_xml_missing"
                results[test_name] = {"status": "unavailable", "reason": reason, "detail": err.strip()}
                return {"status": "unavailable", "reason": reason, "function_start": start, "function_end": end, "tests": results}
            try:
                root = ET.parse(xml_path).getroot()
                executed = sorted({int(line.attrib["number"]) for line in root.findall(".//line")
                                   if start <= int(line.attrib.get("number", -1)) <= end
                                   and int(line.attrib.get("hits", "0")) > 0})
            except (ET.ParseError, ValueError) as exc:
                results[test_name] = {"status": "unavailable", "reason": "coverage_xml_parse_failed", "detail": str(exc)}
                return {"status": "unavailable", "reason": "coverage_xml_parse_failed", "function_start": start, "function_end": end, "tests": results}
            results[test_name] = {"status": "PASS", "executed_lines": executed}
    return {"status": "PASS", "function_start": start, "function_end": end, "tests": results}


def _line_span_offsets(code: str, line_start: int, line_end: int) -> tuple[int, int]:
    if line_start < 1 or line_end < line_start:
        raise ValueError("invalid operation line span")
    starts = [0]
    for index, char in enumerate(code):
        if char == "\n":
            starts.append(index + 1)
    if line_end > len(starts):
        raise ValueError("operation line span outside function")
    start = starts[line_start - 1]
    end = starts[line_end] if line_end < len(starts) else len(code)
    return start, end


def _line_column_offset(code: str, line_number: int, column_number: int) -> int | None:
    if line_number < 1 or column_number < 1:
        return None
    starts = [0]
    for index, char in enumerate(code):
        if char == "\n":
            starts.append(index + 1)
    if line_number > len(starts):
        return None
    offset = starts[line_number - 1] + column_number - 1
    return offset if 0 <= offset <= len(code) else None


def _operation_node_types(kind: str) -> set[str]:
    return {
        "call": {"MethodInvocation", "SuperMethodInvocation"},
        "field_assignment": {"Assignment"},
        "return": {"ReturnStatement"},
        "throw": {"ThrowStatement"},
    }.get(kind, set())


def _current_candidate_matches(current_state_code: str, candidate_code: str) -> list[dict[str, Any]]:
    """Run GumTree on valid Java wrappers and return function-relative matches."""
    prefix, suffix = "class CandidateWrapper {\n", "\n}\n"
    raw_matches = gumtree_json(prefix + current_state_code + suffix, prefix + candidate_code + suffix)["matches"]
    matches = []
    for item in raw_matches:
        src, dest = _match_node(str(item.get("src", ""))), _match_node(str(item.get("dest", "")))
        if src is None or dest is None:
            continue
        src = dict(src, start_offset=src["start_offset"] - len(prefix), end_offset=src["end_offset"] - len(prefix))
        dest = dict(dest, start_offset=dest["start_offset"] - len(prefix), end_offset=dest["end_offset"] - len(prefix))
        if src["start_offset"] >= 0 and dest["start_offset"] >= 0:
            matches.append({"src": src, "dest": dest})
    return matches


def _map_operation_to_candidate(current_state_code: str, candidate_code: str,
                                matches: Sequence[Mapping[str, Any]], operation: Mapping[str, Any]) -> dict[str, Any]:
    try:
        start, end = _line_span_offsets(current_state_code, int(operation["line_start"]), int(operation["line_end"]))
    except (KeyError, TypeError, ValueError) as exc:
        return {"status": "unmapped", "reason": "operation_source_range_invalid", "detail": str(exc)}
    expected_types = _operation_node_types(str(operation.get("kind")))
    candidates = []
    for item in matches:
        src, dest = item.get("src"), item.get("dest")
        if not isinstance(src, Mapping) or not isinstance(dest, Mapping) or src.get("node_type") not in expected_types:
            continue
        if start <= src["start_offset"] and src["end_offset"] <= end:
            candidates.append((src, dest))
    if len(candidates) > 1:
        exact_line, exact_column = operation.get("line_number"), operation.get("column_number")
        exact_offset = (
            _line_column_offset(current_state_code, exact_line, exact_column)
            if isinstance(exact_line, int) and isinstance(exact_column, int) else None
        )
        if exact_offset is not None:
            candidates = [
                (source, destination) for source, destination in candidates
                if source["start_offset"] <= exact_offset < source["end_offset"]
            ]
    if len(candidates) != 1:
        reason = "operation_mapping_missing" if not candidates else "operation_mapping_not_unique"
        return {"status": "unmapped", "reason": reason}
    source, destination = candidates[0]
    if destination["start_offset"] < 0 or destination["end_offset"] > len(candidate_code):
        return {"status": "unmapped", "reason": "mapped_operation_outside_candidate"}
    return {"status": "PASS", "source_node": source, "candidate_node": destination}


def collect_candidate_operation_coverage(bug_id: str, dataset: Mapping[str, Any], current_state_code: str,
                                         layer: Sequence[Mapping[str, Any]], key_operations: Mapping[str, Any],
                                         failed_tests: Sequence[str], timeout: int = 300) -> dict[str, Any]:
    """Collect mapped-node execution facts for every candidate in an ambiguous layer."""
    if key_operations.get("status") != "PASS":
        return {"status": "unavailable", "reason": "current_key_operations_unavailable", "candidates": []}
    results, unavailable = [], False
    for candidate in layer:
        candidate_index, candidate_code = candidate.get("candidate_index"), candidate.get("patch_code")
        item: dict[str, Any] = {"candidate_index": candidate_index, "status": "PASS", "tests": {}}
        if not isinstance(candidate_code, str):
            item.update({"status": "unavailable", "reason": "candidate_code_missing"})
            results.append(item)
            unavailable = True
            continue
        coverage = collect_candidate_coverage(bug_id, dataset, candidate_code, failed_tests, timeout)
        item["coverage"] = coverage
        if coverage.get("status") != "PASS":
            item.update({"status": "unavailable", "reason": coverage.get("reason", "candidate_coverage_unavailable")})
            results.append(item)
            unavailable = True
            continue
        try:
            matches = _current_candidate_matches(current_state_code, candidate_code)
        except Exception as exc:
            item.update({"status": "unavailable", "reason": "candidate_gumtree_mapping_failed", "detail": str(exc)})
            results.append(item)
            unavailable = True
            continue
        candidate_start = coverage.get("function_start")
        if not isinstance(candidate_start, int):
            item.update({"status": "unavailable", "reason": "candidate_coverage_function_start_missing"})
            results.append(item)
            unavailable = True
            continue
        for test_name, current_test in key_operations.get("tests", {}).items():
            candidate_test = coverage.get("tests", {}).get(test_name, {})
            if candidate_test.get("status") != "PASS":
                item["tests"][test_name] = {"status": "unavailable", "reason": "candidate_test_coverage_unavailable"}
                item["status"], unavailable = "unavailable", True
                continue
            executed_lines = {int(line) - candidate_start + 1 for line in candidate_test.get("executed_lines", [])}
            operations = []
            for operation in current_test.get("operations", []):
                mapped = _map_operation_to_candidate(current_state_code, candidate_code, matches, operation)
                record = {"current_operation": operation, "mapping_status": mapped["status"]}
                if mapped["status"] != "PASS":
                    record["status"] = "unmapped"
                    record["reason"] = mapped.get("reason")
                    item["status"], unavailable = "unavailable", True
                else:
                    candidate_node = mapped["candidate_node"]
                    try:
                        mapped_start = _offset_line_number(candidate_code, candidate_node["start_offset"])
                        mapped_end = _offset_line_number(candidate_code, candidate_node["end_offset"])
                    except (KeyError, TypeError, ValueError) as exc:
                        record.update({"status": "unmapped", "reason": "mapped_operation_range_invalid", "detail": str(exc)})
                        item["status"], unavailable = "unavailable", True
                    else:
                        mapped_lines = list(range(mapped_start, mapped_end + 1))
                        record.update({"status": "executed" if executed_lines.intersection(mapped_lines) else "not_executed",
                                       "candidate_node": candidate_node,
                                       "candidate_line_start": mapped_start, "candidate_line_end": mapped_end,
                                       "candidate_executed_lines": sorted(executed_lines)})
                operations.append(record)
            item["tests"][test_name] = {"status": "PASS", "operations": operations}
        results.append(item)
    return {"status": "unavailable" if unavailable else "PASS",
            "reason": "candidate_coverage_or_mapping_unavailable" if unavailable else None,
            "candidates": results}


def _joern_cfg(code: str, timeout: int = 120) -> dict[str, Any]:
    prefix = "class CfgWrapper {\n"; suffix = "\n}\n"
    script = r"""import io.shiftleft.semanticcpg.language._
import io.shiftleft.codepropertygraph.generated.nodes._
import ujson._
@main def main(cpgFile: String, outFile: String): Unit = { importCpg(cpgFile)
 def row(n: CfgNode): Obj = { var chain=List[Long](); var current: Option[AstNode]=Some(n); while(current.nonEmpty) { val x=current.get; chain=chain :+ x.id; current=Iterator(x).astParent.l.headOption }; Obj("id"->n.id,"label"->n.label,"code"->n.code,"name"->(n match { case c: Call => c.name; case _ => "" }),"line"->n.lineNumber.getOrElse(-1),"astLines"->Arr.from(n.ast.lineNumber.l.distinct.sorted),"ancestors"->Arr.from(chain),"next"->Arr.from(Iterator(n).cfgNext.l.map(_.id))) }
 ujson.write(Arr.from(cpg.method.cfgNode.l.map(row)), indent=2) #> outFile
}"""
    with tempfile.TemporaryDirectory(prefix="pacefix_control_cfg_") as d:
        d=Path(d); src=d/'CfgWrapper.java'; cpg=d/'cpg.bin'; sc=d/'q.sc'; out=d/'cfg.json'
        src.write_text(prefix+code+suffix); sc.write_text(script)
        s,_,e=run_command(_java21_command([JOERN_PARSE,str(d),"--output",str(cpg)]),timeout)
        if s != 'PASS': return {'status':'unavailable','reason':'joern_cfg_parse_'+s.lower(),'detail':e.strip()}
        s,_,e=run_command(_java21_command([JOERN,"--script",str(sc),"--param",f"cpgFile={cpg}","--param",f"outFile={out}","--nocolors"]),timeout)
        if s != 'PASS' or not out.is_file(): return {'status':'unavailable','reason':'joern_cfg_query_'+s.lower(),'detail':e.strip()}
        try: rows=json.loads(out.read_text())
        except Exception as exc: return {'status':'unavailable','reason':'joern_cfg_json','detail':str(exc)}
    shift=prefix.count('\n'); nodes=[]
    for n in rows:
        lines=[x-shift for x in n.get('astLines',[]) if isinstance(x,int) and x>shift]
        n['ast_lines']=lines; n['line']=n.get('line',-1)-shift if n.get('line',-1)>shift else -1; nodes.append(n)
    return {'status':'PASS','nodes':nodes}

def _reachable(edges, start, target):
    todo=[str(start)]; seen=set()
    while todo:
        node=todo.pop()
        if node == str(target): return True
        if node in seen: continue
        seen.add(node); todo.extend(str(x) for x in edges.get(node,[]))
    return False

def _line_has_control(code, line):
    lines=code.splitlines()
    return 1 <= line <= len(lines) and bool(re.search(r'\b(if|for|while|switch|catch)\b',lines[line-1]))

def _candidate_control_edit_lines(diff, candidate_code, prefix_len):
    pairs=[(_match_node(str(x.get("src",""))), _match_node(str(x.get("dest","")))) for x in diff.get("matches", [])]
    result=[]
    for action in diff.get("actions", []):
        source=_match_node(str(action.get("tree", "")))
        if source is None: continue
        destinations=[] if action.get("action") == "insert-tree" and source["node_type"] in CONTROL_STRUCTURE_ANCHOR_TYPES else [dst for src,dst in pairs if src and dst and src["start_offset"] <= source["start_offset"] < src["end_offset"]]
        if len(destinations) > 1: return None
        offset=(destinations[0]["start_offset"] if destinations else source["start_offset"]) - prefix_len
        if 0 <= offset <= len(candidate_code):
            line=_offset_line_number(candidate_code,offset)
            if _line_has_control(candidate_code,line): result.append(line)
    if not result and any(node_type(str(a.get("tree", ""))) in CONTROL_STRUCTURE_ANCHOR_TYPES for a in diff.get("actions", [])):
        result = [index for index, line in enumerate(candidate_code.splitlines(), 1) if _line_has_control(candidate_code, index)]
    return sorted(set(result))

def assess_direct_skip(candidate_code: str, operation_record: Mapping[str,Any], control_lines: Sequence[int], timeout=120):
    """Conservative return/break-only direct-skip fact; never assesses replacement."""
    if operation_record.get('status') != 'not_executed' or operation_record.get('mapping_status') != 'PASS':
        return {'status':'unavailable','reason':'mapped_key_not_not_executed'}
    kline=operation_record.get('candidate_line_start'); executed=set(operation_record.get('candidate_executed_lines',[]))
    if not isinstance(kline,int): return {'status':'unavailable','reason':'candidate_key_line_missing'}
    cfg=_joern_cfg(candidate_code,timeout)
    if cfg.get('status')!='PASS': return cfg
    nodes=cfg['nodes']; edges={str(n['id']):n.get('next',[]) for n in nodes}
    exits=[]
    for n in nodes:
        kind='return' if n.get('label')=='RETURN' else 'break' if n.get('label')=='CONTROL_STRUCTURE' and n.get('code')=='break;' else 'continue' if n.get('label')=='CONTROL_STRUCTURE' and n.get('code')=='continue;' else 'throw' if n.get('name')=='<operator>.throw' else None
        if kind and n.get('line') in executed: exits.append((kind,n))
    if len(exits)!=1: return {'status':'unavailable','reason':'executed_exit_not_unique'}
    kind,e=exits[0]
    if kind in {'continue','throw'}: return {'status':'unavailable','reason':kind+'_unsupported'}
    if _line_has_control(candidate_code,e['line']): return {'status':'unavailable','reason':'exit_shares_control_line'}
    if e['line'] >= kline: return {'status':'unavailable','reason':'exit_not_before_key'}
    if kind=='return' and e.get('next'): return {'status':'unavailable','reason':'return_not_cfg_terminal'}
    key_nodes=[n for n in nodes if kline in n.get('ast_lines',[]) and n.get('label') in {'CALL','RETURN','CONTROL_STRUCTURE'}]
    if not key_nodes: return {'status':'unavailable','reason':'candidate_key_cfg_node_missing'}
    if kind=='break':
        loops=[n for n in nodes if n.get('label')=='CONTROL_STRUCTURE' and re.match(r'\s*(for|while|do)\b',str(n.get('code',''))) and e['line'] in n.get('ast_lines',[]) and kline in n.get('ast_lines',[])]
        if len(loops)!=1: return {'status':'unavailable','reason':'break_loop_not_unique'}
    if any(_reachable(edges,e['id'],k['id']) for k in key_nodes): return {'status':'unavailable','reason':'exit_can_reach_key'}
    control_nodes=[n for n in nodes if n.get('label')=='CONTROL_STRUCTURE' and n.get('line') in control_lines]
    if len(control_nodes)!=1: return {'status':'unavailable','reason':'candidate_control_node_not_unique'}
    control=control_nodes[0]
    controls=[control] if str(control['id']) in {str(x) for x in e.get('ancestors',[])} else []
    if len(controls)!=1: return {'status':'unavailable','reason':'control_edit_exit_attribution_not_unique'}
    return {'status':'PASS','directly_skipped':True,'exit_kind':kind,'exit_line':e['line'],'control_line':controls[0]['line']}

def _normalized_code(value: Any) -> str:
    return re.sub(r"\s+", "", str(value or ""))


def assess_replacement(candidate_code: str, operation_record: Mapping[str, Any], direct_skip: Mapping[str, Any], timeout: int = 120) -> dict[str, Any]:
    """Conservatively identify an executed, exact structural replacement before an exit."""
    if direct_skip.get("status") != "PASS" or not direct_skip.get("directly_skipped"):
        return {"status": "unavailable", "reason": "direct_skip_not_confirmed"}
    current = operation_record.get("current_operation")
    if not isinstance(current, Mapping) or not current.get("kind") or not current.get("code"):
        return {"status": "unavailable", "reason": "current_operation_missing"}
    exit_line, control_line = direct_skip.get("exit_line"), direct_skip.get("control_line")
    executed = set(operation_record.get("candidate_executed_lines", []))
    if not isinstance(exit_line, int) or not isinstance(control_line, int):
        return {"status": "unavailable", "reason": "exit_or_control_line_missing"}
    if _line_has_control(candidate_code, exit_line):
        return {"status": "unavailable", "reason": "replacement_line_coverage_ambiguous"}
    cfg = _joern_cfg(candidate_code, timeout)
    if cfg.get("status") != "PASS":
        return cfg
    controls = [node for node in cfg["nodes"] if node.get("label") == "CONTROL_STRUCTURE" and node.get("line") == control_line]
    if len(controls) != 1:
        return {"status": "unavailable", "reason": "replacement_control_node_not_unique"}
    control_id = str(controls[0]["id"])
    effects = []
    for node in cfg["nodes"]:
        line = node.get("line")
        if not isinstance(line, int) or line not in executed or line >= exit_line or _line_has_control(candidate_code, line):
            continue
        if control_id not in {str(item) for item in node.get("ancestors", [])}:
            continue
        if node.get("label") == "RETURN":
            kind = "return"
        elif node.get("name") == "<operator>.throw":
            kind = "throw"
        elif node.get("name") == "<operator>.assignment":
            left_hand_side = str(node.get("code", "")).split("=", 1)[0]
            kind = "field_assignment" if "." in left_hand_side else "assignment"
        elif node.get("label") == "CALL" and not str(node.get("name", "")).startswith("<operator>."):
            kind = "call"
        else:
            continue
        effects.append({"kind": kind, "code": node.get("code", ""), "line": line, "id": node.get("id")})
    expected_kind = str(current["kind"])
    expected_code = _normalized_code(current["code"])
    exact = [effect for effect in effects if effect["kind"] == expected_kind and _normalized_code(effect["code"]) == expected_code]
    if len(exact) == 1:
        return {"status": "PASS", "replacement": True, "replacement_operation": exact[0]}
    if len(exact) > 1:
        return {"status": "unavailable", "reason": "replacement_not_unique"}
    if not effects:
        return {"status": "PASS", "replacement": False}
    return {"status": "unavailable", "reason": "different_effect_before_exit", "effects": effects}


def _control_gumtree_diff(current_state_code: str, candidate_code: str) -> tuple[dict[str, Any], int]:
    prefix, suffix = "class ControlDiffWrapper {\n", "\n}\n"
    return gumtree_json(prefix + current_state_code + suffix, prefix + candidate_code + suffix), len(prefix)


def collect_direct_skip_facts(current_state_code, layer, candidate_operation_coverage):
    by_index={x.get('candidate_index'):x for x in candidate_operation_coverage.get('candidates',[])}; facts=[]; unavailable=False
    for candidate in layer:
        idx=candidate['candidate_index']; item={'candidate_index':idx,'operations':[]}
        try:
            diff, prefix_len = _control_gumtree_diff(current_state_code, candidate['patch_code'])
            control_lines=_candidate_control_edit_lines(diff,candidate['patch_code'],prefix_len)
        except Exception as exc: item.update({'status':'unavailable','reason':'gumtree_control_edits_failed','detail':str(exc)}); facts.append(item); unavailable=True; continue
        if not control_lines:
            item.update({'status':'PASS','control_modification':False,'reason':'no_patch_induced_control_modification'})
            facts.append(item)
            continue
        item['control_modification'] = True
        cov=by_index.get(idx,{})
        for test in cov.get('tests',{}).values():
            for op in test.get('operations',[]):
                direct = assess_direct_skip(candidate['patch_code'], op, control_lines)
                replacement = assess_replacement(candidate['patch_code'], op, direct) if direct.get('status') == 'PASS' else {'status': 'unavailable', 'reason': 'direct_skip_not_confirmed'}
                direct['replacement'] = replacement
                if replacement.get('status') == 'PASS':
                    direct['B'] = 0 if replacement.get('replacement') else 1
                item['operations'].append(direct)
        item['status']='PASS' if item['operations'] and all(x.get('status')=='PASS' and x.get('replacement',{}).get('status')=='PASS' for x in item['operations']) else 'unavailable'; unavailable |= item['status']!='PASS'; facts.append(item)
    return {'status':'unavailable' if unavailable else 'PASS','candidates':facts}


def _evidence_from_direct_skip_facts(facts: Mapping[str, Any]) -> dict[str, Any] | None:
    """Translate complete direct-skip/replacement facts into the existing binary gate input."""
    if facts.get("status") != "PASS":
        return None
    evidence = {}
    for candidate in facts.get("candidates", []):
        index = candidate.get("candidate_index")
        if index is None:
            return None
        if candidate.get("control_modification") is False:
            evidence[str(index)] = {
                "complete": True,
                "key_operation_directly_skipped": False,
                "corresponding_replacement_present": False,
            }
            continue
        operations = candidate.get("operations", [])
        if not operations or any(operation.get("B") not in {0, 1} for operation in operations):
            return None
        risk = any(operation["B"] == 1 for operation in operations)
        evidence[str(index)] = {
            "complete": True,
            "key_operation_directly_skipped": True,
            "corresponding_replacement_present": not risk,
        }
    return evidence

def node_type(tree: str) -> str:
    return str(tree).split(":", 1)[0].split(" ", 1)[0]

def control_edits(result: Mapping[str, Any]) -> list[dict[str, Any]]:
    """Return only newly introduced early exits, never ordinary condition edits."""
    exits = {"ReturnStatement", "ThrowStatement", "BreakStatement", "ContinueStatement"}
    return [
        {"action": action.get("action"), "node_type": node_type(action.get("tree", "")),
         "tree": action.get("tree"), "parent": action.get("parent"), "at": action.get("at")}
        for action in result["actions"]
        if str(action.get("action", "")).startswith("insert")
        and node_type(action.get("tree", "")) in exits
    ]

def evaluate_candidate_evidence(candidate_index: int, edits: Sequence[Mapping[str, Any]], evidence: Mapping[str, Any] | None) -> dict[str, Any]:
    if not edits:
        return {"candidate_index": candidate_index, "B": 0, "control_modification": False, "reason": "no_patch_induced_control_modification"}
    if evidence is None or not evidence.get("complete", False):
        return {"candidate_index": candidate_index, "B": None, "control_modification": True, "reason": "insufficient_control_evidence"}
    if not evidence.get("key_operation_directly_skipped", False):
        return {"candidate_index": candidate_index, "B": 0, "control_modification": True, "reason": "key_operation_not_directly_skipped"}
    if evidence.get("corresponding_replacement_present", False):
        return {"candidate_index": candidate_index, "B": 0, "control_modification": True, "reason": "corresponding_replacement_present"}
    return {"candidate_index": candidate_index, "B": 1, "control_modification": True, "reason": "all_three_control_conditions_confirmed"}

def apply_whole_layer_gate(original_candidates: Sequence[Mapping[str, Any]], evaluations: Sequence[Mapping[str, Any]], gate_failure: str | None = None) -> dict[str, Any]:
    indices = [candidate["candidate_index"] for candidate in original_candidates]
    if gate_failure or len(evaluations) != len(original_candidates):
        return {"control_evidence": "unavailable", "decision": "control_unavailable", "kept_candidate_indices": indices, "kept_candidates": list(original_candidates), "candidates": list(evaluations), "unavailable_reason": gate_failure or "candidate_evidence_insufficient"}
    # A candidate-local timeout/mapping error is unknown, not a reason to discard
    # completed evidence for the rest of the layer. Unknown candidates remain.
    values = {item["B"] for item in evaluations if item.get("B") in {0, 1}}
    if values == {0, 1}:
        keep = {item["candidate_index"] for item in evaluations if item.get("B") != 1}
        kept = [candidate for candidate in original_candidates if candidate["candidate_index"] in keep]
        decision = "mixed_control_keep_b0"
    else:
        kept, decision = list(original_candidates), "no_control_discrimination"
    return {"control_evidence": "available", "decision": decision, "kept_candidate_indices": [candidate["candidate_index"] for candidate in kept], "kept_candidates": kept, "candidates": list(evaluations)}

def load_layer(progress: Mapping[str, Any], records: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    if progress.get("decision") != "ambiguous_max_progress":
        raise ValueError("Control accepts only ambiguous_max_progress input")
    by_index = {record.get("candidate_index"): record for record in records}
    layer = []
    for index in progress.get("max_progress_candidate_indices", []):
        record = by_index.get(index)
        if record is None or not isinstance(record.get("patch_code"), str):
            raise ValueError(f"candidate {index} has no validator patch_code")
        layer.append({"candidate_index": index, "patch_code": record["patch_code"]})
    if len(layer) < 2:
        raise ValueError("ambiguous Control layer must contain at least two candidates")
    return layer

def analyze_layer(progress: Mapping[str, Any], records: Sequence[Mapping[str, Any]], current_state_code: str, evidence_by_candidate: Mapping[str, Any] | None = None) -> dict[str, Any]:
    layer, evaluations, gate_failure = load_layer(progress, records), [], None
    for candidate in layer:
        try:
            diff, _ = _control_gumtree_diff(current_state_code, candidate["patch_code"])
            edits = control_edits(diff)
        except Exception as exc:
            gate_failure = f"candidate {candidate['candidate_index']} GumTree failure: {exc}"
            break
        evidence = None if evidence_by_candidate is None else evidence_by_candidate.get(str(candidate["candidate_index"]))
        item = evaluate_candidate_evidence(candidate["candidate_index"], edits, evidence)
        item["gumtree_control_edits"] = edits
        evaluations.append(item)
    result = apply_whole_layer_gate(layer, evaluations, gate_failure)
    result.update({"bug_id": progress.get("bug_id"), "round_id": progress.get("round_id"), "current_failed_tests": progress.get("current_failed_tests"), "input_candidate_indices": [candidate["candidate_index"] for candidate in layer]})
    return result

def run_control_layer(progress: Mapping[str, Any], records: Sequence[Mapping[str, Any]],
                      current_state_code: str, dataset: Mapping[str, Any]) -> dict[str, Any]:
    """Run Control with candidate-local failures and optional flushed diagnostics."""
    def trace(candidate_index: int, phase: str, detail: str = "") -> None:
        if os.environ.get("PACEFIX_CONTROL_TRACE") == "1":
            print(f"CONTROL candidate={candidate_index} {phase}{(' ' + detail) if detail else ''}", flush=True)

    layer = load_layer(progress, records)
    edits_by_index, evaluations, early_exit_layer = {}, [], []
    for candidate in layer:
        index = candidate["candidate_index"]
        trace(index, "START candidate")
        try:
            diff, _ = _control_gumtree_diff(current_state_code, candidate["patch_code"])
            edits = control_edits(diff)
        except Exception as exc:
            evaluations.append({"candidate_index": index, "B": None, "control_modification": True,
                                "reason": "gumtree_control_edits_failed", "detail": str(exc),
                                "gumtree_control_edits": []})
            trace(index, "RESULT", "unknown gumtree_control_edits_failed")
            continue
        edits_by_index[index] = edits
        trace(index, "detect_new_early_exit", "found" if edits else "none")
        if not edits:
            evaluations.append({"candidate_index": index, "B": 0, "control_modification": False,
                                "reason": "no_patch_induced_early_exit", "gumtree_control_edits": edits})
            for phase in ("baseline_fault_coverage", "candidate_early_exit_coverage",
                          "candidate_fault_coverage", "fail_to_pass_check"):
                trace(index, phase, "skipped_no_new_early_exit")
            trace(index, "RESULT", "risk=0")
        else:
            early_exit_layer.append(candidate)

    coverage = {"status": "not_required", "tests": {}}
    key_operations = {"status": "not_required"}
    candidate_operation_coverage = {"status": "not_required", "candidates": []}
    direct_skip_facts = {"status": "not_required", "candidates": []}
    if early_exit_layer:
        coverage = collect_current_state_coverage(
            progress["bug_id"], dataset, current_state_code, progress["current_failed_tests"])
        key_operations = (determine_current_key_operations(
            progress["bug_id"], dataset, current_state_code, coverage)
            if coverage.get("status") == "PASS"
            else {"status": "unavailable", "reason": coverage.get("reason")})
        for candidate in early_exit_layer:
            index = candidate["candidate_index"]
            trace(index, "baseline_fault_coverage", coverage.get("status", "unavailable"))
            if key_operations.get("status") != "PASS":
                evaluations.append({"candidate_index": index, "B": None, "control_modification": True,
                                    "reason": key_operations.get("reason", "current_key_operations_unavailable"),
                                    "gumtree_control_edits": edits_by_index[index]})
                trace(index, "RESULT", "unknown baseline_evidence_unavailable")
                continue
            trace(index, "candidate_early_exit_coverage", "START")
            one_coverage = collect_candidate_operation_coverage(
                progress["bug_id"], dataset, current_state_code, [candidate],
                key_operations, progress["current_failed_tests"])
            trace(index, "candidate_fault_coverage", one_coverage.get("status", "unavailable"))
            record = next((item for item in records if item.get("candidate_index") == index), {})
            passed = set(progress["current_failed_tests"]).isdisjoint(
                set(record.get("next_failed_tests") or progress["current_failed_tests"]))
            trace(index, "fail_to_pass_check", "PASS" if passed else "FAIL")
            facts = (collect_direct_skip_facts(current_state_code, [candidate], one_coverage)
                     if one_coverage.get("status") == "PASS"
                     else {"status": "unavailable", "candidates": []})
            evidence = _evidence_from_direct_skip_facts(facts)
            if evidence is None or not passed:
                reason = "fail_to_pass_not_confirmed" if not passed else "candidate_control_evidence_unavailable"
                evaluations.append({"candidate_index": index, "B": None, "control_modification": True,
                                    "reason": reason, "gumtree_control_edits": edits_by_index[index]})
                trace(index, "RESULT", "unknown " + reason)
            else:
                item = evaluate_candidate_evidence(index, edits_by_index[index], evidence.get(str(index)))
                item["gumtree_control_edits"] = edits_by_index[index]
                evaluations.append(item)
                trace(index, "RESULT", f"risk={item['B']}")
            candidate_operation_coverage["candidates"].extend(one_coverage.get("candidates", []))
            direct_skip_facts["candidates"].extend(facts.get("candidates", []))

    order = {candidate["candidate_index"]: position for position, candidate in enumerate(layer)}
    evaluations.sort(key=lambda item: order[item["candidate_index"]])
    result = apply_whole_layer_gate(layer, evaluations)
    result.update({"bug_id": progress["bug_id"], "round_id": progress["round_id"],
                   "current_failed_tests": progress["current_failed_tests"],
                   "input_candidate_indices": [item["candidate_index"] for item in layer]})
    result["current_state_coverage"] = coverage
    result["current_key_operations"] = key_operations
    result["candidate_operation_coverage"] = candidate_operation_coverage
    result["direct_skip_facts"] = direct_skip_facts
    return result


def _legacy_simplified_control_layer(progress, records, current_state_code, dataset):
    """Superseded incomplete shortcut screen; retained only for source history."""
    layer = records if records and "patch_code" in records[0] else load_layer(progress, records)
    failed = list(progress.get("current_failed_tests", [])); bug_id=progress["bug_id"]
    base = collect_current_state_coverage(bug_id, dataset, current_state_code, failed)
    base_lines=set()
    bug=dataset.get(bug_id,{})
    for x in bug.get("location",[]) if isinstance(bug,Mapping) else []:
        if isinstance(x,int) and isinstance(base.get("function_start"),int): base_lines.add(x-base["function_start"]+1)
    evaluations=[]
    for c in layer:
        item={"candidate_index":c["candidate_index"],"risk":0,"status":"PASS"}
        try:
            diff,_=_control_gumtree_diff(current_state_code,c["patch_code"])
            exits=[a for a in diff.get("actions",[]) if a.get("action","").startswith("insert") and node_type(a.get("tree","")) in {"ReturnStatement","ThrowStatement","BreakStatement","ContinueStatement"}]
            item["new_exit_count"]=len(exits)
            if not exits: item["reason"]="no_new_early_exit"; evaluations.append(item); continue
            cov=collect_candidate_coverage(bug_id,dataset,c["patch_code"],failed)
            if base.get("status")!="PASS" or cov.get("status")!="PASS":
                item.update({"status":"unknown","reason":"coverage_unavailable"}); evaluations.append(item); continue
            # A candidate has direct-shortcut risk only with an inserted exit, P_t fault reach,
            # and loss of the corresponding candidate fault line under the passing test.
            base_hit=any(set(t.get("executed_lines",[])) for t in base.get("tests",{}).values())
            cand_hit=any(set(t.get("executed_lines",[]) for t in []) or False for t in [])
            if base_hit and base_lines:
                item["reason"]="early_exit_not_dynamically_attributed"
            else: item["reason"]="fault_region_not_reached"
        except Exception as exc: item.update({"status":"unknown","reason":"candidate_analysis_failed","detail":str(exc)})
        evaluations.append(item)
    risky={x["candidate_index"] for x in evaluations if x.get("risk")==1}
    ids=[c["candidate_index"] for c in layer]; keep=[c for c in layer if not risky or c["candidate_index"] not in risky]
    return {"control_evidence":"available","decision":"remove_direct_shortcut_risk" if risky and len(keep)<len(layer) else "no_control_discrimination","kept_candidate_indices":[c["candidate_index"] for c in keep],"kept_candidates":keep,"candidates":evaluations,"bug_id":bug_id,"round_id":progress.get("round_id")}

def main() -> None:
    parser = argparse.ArgumentParser(description="Apply the Control risk constraint.")
    parser.add_argument("--progress", required=True)
    parser.add_argument("--validator-results", required=True)
    parser.add_argument("--current-state-code-file", required=True)
    parser.add_argument("--dataset", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--evidence-file")
    args = parser.parse_args()
    progress = json.loads(Path(args.progress).read_text(encoding="utf-8"))
    records = json.loads(Path(args.validator_results).read_text(encoding="utf-8"))
    current_state_code = Path(args.current_state_code_file).read_text(encoding="utf-8")
    dataset = json.loads(Path(args.dataset).read_text(encoding="utf-8"))
    if args.evidence_file:
        json.loads(Path(args.evidence_file).read_text(encoding="utf-8"))
    result = run_control_layer(progress, records, current_state_code, dataset)
    Path(args.output).write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")

if __name__ == "__main__":
    main()
