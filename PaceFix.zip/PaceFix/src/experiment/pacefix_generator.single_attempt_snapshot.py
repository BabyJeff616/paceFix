import sys
import time

import openai
import os
from langchain_core.prompts import PromptTemplate
from langchain_community.callbacks import get_openai_callback
from langchain.callbacks.openai_info import OpenAICallbackHandler
from langchain_core.runnables.config import RunnableConfig
from langchain.agents import AgentExecutor, create_react_agent
from langchain_openai import ChatOpenAI

import re
import json
from datetime import datetime

from src.config import OPENAI_API_KEY
from src.agent.tools import *

os.environ["OPENAI_API_KEY"] = OPENAI_API_KEY

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
REPO_ROOT = os.path.abspath(os.path.join(SCRIPT_DIR, "..", ".."))

EXPERIMENT_OUTPUT = os.path.join(SCRIPT_DIR, "output")
LOG_DIR = os.path.join(EXPERIMENT_OUTPUT, "log")
SOLUTION_DIR = os.path.join(EXPERIMENT_OUTPUT, "sf_solutions")
PATCH_DIR = os.path.join(EXPERIMENT_OUTPUT, "sf_patches")

for directory in (LOG_DIR, SOLUTION_DIR, PATCH_DIR):
    os.makedirs(directory, exist_ok=True)



def extract_and_save_final_answer(text, output_file, name):
    root_cause_match = re.search(r"(?i)root\s*cause:?\s*(.+?)(?=\n+ *suggestion|\Z)", text, re.DOTALL | re.IGNORECASE)
    suggestions_matches = re.finditer(r"(?i)suggestion\s*(\d+):?\s*(.*?)(?=\n\s*suggestion|\Z)", text,
                                      re.DOTALL | re.IGNORECASE)

    if not root_cause_match:
        raise ValueError("Root Cause not found in the text")

    root_cause = root_cause_match.group(1).strip()
    suggestions = []

    for idx, match in enumerate(suggestions_matches):
        if idx >= 3:
            break
        suggestion_number = match.group(1)
        suggestion_text = match.group(2).strip()

        lines = suggestion_text.split('\n', 1)
        title = lines[0].strip()
        details = lines[1].strip() if len(lines) > 1 else ""

        suggestions.append("Suggestion " + suggestion_number + ". " + title + " " + details + "\n")
    if os.path.exists(output_file):
        with open(output_file, 'r', encoding='utf-8') as f:
            all_analyses = json.load(f)
    else:
        all_analyses = {}

    if name in all_analyses:
        all_analyses[name][root_cause] = suggestions
    else:
        all_analyses[name] = {
            root_cause: suggestions
        }

    # 保存为 JSON 文件
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(all_analyses, f, ensure_ascii=False, indent=2)

    return all_analyses


def parse_patches(result):
    pattern = r'\[START PATCH \d+\]\n```\w*\n(.*?)\n```\n\[END PATCH \d+\]'
    patches = re.findall(pattern, result, re.DOTALL)

    return [patch.strip() for patch in patches]


def api_gpt_response(prompt, n):
    response = openai.chat.completions.create(
        messages=[{"role": "user", "content": prompt}],
        model="gpt-4o-2024-05-13",
        n=n,
        temperature=1)
    return response


def append_patches_to_json(patches, file_path, project_name):
    if not os.path.exists(file_path):
        data = {}
    else:
        with open(file_path, 'r') as f:
            data = json.load(f)
    if project_name not in data:
        data[project_name] = {"patches": []}
    data[project_name]["patches"].extend(patches)
    with open(file_path, 'w') as f:
        json.dump(data, f, indent=2)


tools = [open_proj_tool, trace_method_usage_tool, find_method_in_file_tool, analyze_method_details_tool,
         analyze_method_control_flow_tool,
         find_class_loc_tool, identify_class_tool, get_imports_tool, close_proj_tool, example_patch_search_tool]

prompt_solution_template = PromptTemplate.from_template("""
You are an expert Java programmer and code analyzer. Your task is to analyze a given Java code snippet, identify the root cause of a bug, and provide repair suggestions.

## Available Tools

You have access to the following Joern-based tools and one Example Patch Search tool:
{tools}
{tool_names}

for each tool call:
  "tool": "Tool to be called from tools, if applicable. Set to 'None' if no tool is needed.",
  "parameters": "The input parameter(s) used by the tools. Only the parameter value(s) (e.g. getIndexOf), (e.g. getLegendItems, AbstractCategoryItemRenderer.java). Set to 'None' if there are no parameters.". DO NOT try to modify any parameter format(e.g., open("Chart-1_buggy") rather than open("Chart_1_buggy\"\n") etc.). 

- IMPORTANT: Do not modify tool parameters in any way. Use them exactly as provided in the input context. DO NOT Add any quota marks to the parameter because the tool call will process it.

## Analysis Process

1. Open the CPG for the buggy code (always required as first stage)
2. Analyze the buggy code, focusing on the area marked with /* bug is here */
3. Use tools to gather necessary information about( DO NOT Add any quota marks to the input parameter because the tool call will process it.):
   - Variable definitions and usages
   - Function calls and definitions
   - Control flow
   - Similar patterns in the codebase
   - Import statements and library usage
4. Synthesize gathered information
5. Close the project (always required after gather enough information and before output the Summary Answer)
6. Output the Summary Answer.
7. Concatenate the complete Buggy function code and root cause, use them as the input parameter of calling example_patch_search_tool. It will return a fix pattern contain buggy code, fix code and root cause.
8. Observe the fix pattern of similar bug from example_patch_search_tool output as reference, learn and update the root cause and suggestions as the Final Answer.

## Guidelines
- Open and close the CPG project properly
- Focus on the buggy function and lines(before or at) marked with /* bug is here */
- Avoid unnecessary tool calls if information can be inferred from context
- Ensure your analysis covers context, potential causes, and fix suggestions
- Gather repair contexts as much as you need to draw the root cause.
- Call example_patch_search_tool if you think the joern analyze information is not enough to provide the Final Answer.


## Input Context

- Buggy ID(proj_name): {buggy_id}
- Buggy File: {buggy_file_path}
- Buggy Function: 
```java
{buggy_code}
```
- Trigger Test: {trigger_src}
- Error Message: {err_msg}

To help you better use example_patch_search_tool call, make sure the parameter is the full buggy code concatenate with the root cause, here is an Example:
Action Input:"input_string":  <Buggy code>, Root Cause: <content>"


## Output Format

Use the following format for your analysis:

Thought: [Your reasoning about the next step]
Action: [Tool name]
Action Input: "value1", "value2"
Observation: [Tool output]
... (Repeat Thought/Action/Action Input/Observation as needed)
Thought: I now have enough information to provide the Summary Answer
Action: [Call example_patch_search_tool]
Action Input: "buggy_code, root_cause"
Observation: [Tool output]
Thought: I now have learnt the fix pattern, and I can update and output the Final Answer

Final Answer(IMPORTANT: Strictly follow the output format below and DO NOT add '#', '*' or other signs before each Root Cause & Suggestion title): 
Root Cause: [Detailed explanation of the bug's root cause]

Suggestion 1: [Suggestion title]
[Detailed description of the first repair suggestion, give step by step and sufficient suggestion to help generate correct patches. Only provide how to generate correct patch suggestions, not involve test process. Note that each suggestion should be independent]
Suggestion 2: [Suggestion title]
[Detailed description of the second repair suggestion, give step by step and sufficient suggestion to help generate correct patches. Only provide how to generate correct patch suggestions, not involve test process. Note that each suggestion should be independent]

[You may provide up to 3 repair suggestions in total. Do not provide more than 3 suggestions. Please make sure your Final Answer follows the format above exactly, without adding any extra marks or symbols]

## Begin Your Analysis

Start by opening the CPG and analyzing the buggy code. Focus on the area marked with /* bug is here */ and use the available tools to gather necessary information.
Exit the chain when you already output the Final Answer.
Thought: {agent_scratchpad}
""")

tool_descriptions = "\n".join(
    f"{i + 1}. {tool.description}\n"
    for i, tool in enumerate(tools)
)
tool_names = "\n".join(
    f"{i + 1}. {tool.name}\n"
    for i, tool in enumerate(tools)
)


class Logger(object):
    def __init__(self, filename='default.log', stream=sys.stdout):
        self.terminal = stream
        os.makedirs(os.path.dirname(filename), exist_ok=True)
        self.log = open(filename, 'a', encoding='utf-8')
        self._closed = False

    def _log(self, level, message):
        if message.strip():
            timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            message = f'[{timestamp}] [{level.upper()}] {message}\n'
            self.terminal.write(message)
            self.log.write(message)

    def info(self, message):
        self._log('info', message)

    def error(self, message):
        self._log('error', message)

    def warning(self, message):
        self._log('warning', message)

    def write(self, message):
        if message.strip():
            timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            message = f'[{timestamp}] {message}'
        self.terminal.write(message)
        self.log.write(message)

    def flush(self):
        self.terminal.flush()
        self.log.flush()

    def close(self):
        self.flush()
        self.log.close()



# Single Function Num: 274

bug_list = ["Chart-1"]

with open(os.path.join(REPO_ROOT, "D4J_dataset", "defects4j-sf.json"), "r") as f:
    data = json.load(f)
original_stdout = sys.stdout
for name in bug_list:
    logger = Logger(os.path.join(LOG_DIR, name + ".log"), sys.stdout)
    sys.stdout = logger
    try:
        i = 1
        current_time = None
        start_time = datetime.now()
        total_cost = 0
        # Gen solutions
        while i < 2:
            start_time_ite = datetime.now()
            print(f"Generating Solution for: {name}, Round: {i}")
            i += 1

            trigger_test_list = list(data[name]['trigger_test'].keys())
            trigger_src_list = []
            err_msg_list = []
            for trigger_test in trigger_test_list:
                trigger_src_list.append(data[name]['trigger_test'][trigger_test]['src'])
                err_msg_list.append(data[name]['trigger_test'][trigger_test]['clean_error_msg'])
            # trigger_src_list = slim_joern_token(str(trigger_src_list))
            # err_msg_list = slim_joern_token(str(err_msg_list))
            prompt = prompt_solution_template.partial(
                buggy_id=name + "_buggy",
                buggy_file_path=data[name]['loc'],
                buggy_code=data[name]['buggy_fl'],
                trigger_src=str(trigger_src_list),
                err_msg=str(err_msg_list)
            )
            llm = ChatOpenAI(model_name="gpt-4o-2024-05-13", temperature=1)

            agent = create_react_agent(llm, tools, prompt)
            try:
                agent_executor = AgentExecutor(agent=agent, tools=tools, verbose=True, stream_runnable=False,
                                               handle_parsing_errors="Check your output and make sure it conforms, use the Action/Action Input syntax. Output the Final Answer always should always required as last step. Exit after output the Final Answer.", )

                with get_openai_callback() as cb:
                    result = agent_executor.invoke({})
                    logger.info(f"Agent Total tokens: {cb.total_tokens}")
                    logger.info(f"Agent Prompt tokens: {cb.prompt_tokens}")
                    logger.info(f"Agent Completion tokens: {cb.completion_tokens}")
                    logger.info(f"Agent Cost (USD): ${cb.total_cost}")
                    total_cost += cb.total_cost
                # result = agent_executor.invoke({}, config=config)
                # logger.info(f"Agent Total tokens: {openai_callback_handler.total_tokens}")
                # logger.info(f"Agent Prompt tokens: {openai_callback_handler.prompt_tokens}")
                # logger.info(f"Agent Completion tokens: {openai_callback_handler.completion_tokens}")
                # logger.info(f"Agent Cost (USD): ${openai_callback_handler.total_cost}")
                logger.info(result['output'])
                extract_and_save_final_answer(result['output'], os.path.join(SOLUTION_DIR, name + ".json"), name)
            except ValueError as e:
                response = str(e)
                if not response.startswith("Could not parse LLM output: `"):
                    raise e
                response = response.removeprefix("Could not parse LLM output: `").removesuffix("`")
            if current_time:
                pre_current = current_time
            else:
                pre_current = start_time
            current_time = datetime.now()
            time_difference = current_time - pre_current
            logger.info(f"Iteration {i - 1} time: {time_difference}")

        current_time = datetime.now()
        time_difference = current_time - start_time
        logger.info(f"Time cost after iteration: {time_difference}")

        # Gen Patches
        trigger_test_list = list(data[name]['trigger_test'].keys())
        trigger_src_list = []
        err_msg_list = []
        for trigger_test in trigger_test_list:
            trigger_src_list.append(data[name]['trigger_test'][trigger_test]['src'])
            err_msg_list.append(data[name]['trigger_test'][trigger_test]['clean_error_msg'])
        # trigger_src_list = slim_joern_token(str(trigger_src_list))
        # err_msg_list = slim_joern_token(str(err_msg_list))
        output_patches_file = os.path.join(PATCH_DIR, name + ".json")
        buggy_code = data[name]['buggy_fl']
        context = ["buggy_id: " + name + "_buggy", "\nbuggy_code: " + buggy_code,
                   "\nbuggy_file_path: " + data[name]['loc'], "\ntrigger_src: " + str(trigger_src_list),
                   "\nerr_msg: " + str(err_msg_list)]

        with open(os.path.join(SOLUTION_DIR, name + ".json")) as f2:
            solutions = json.load(f2)

        for root_cause in solutions[name].keys():
            for suggestion in solutions[name][root_cause]:
                prompt_patch = f"""You expert Java programmer in generating patches for a given buggy snippet.\n Bug code information(buggy_id, buggy_code, buggy_file_path, trigger_src, err_msg):"+{str(context)}+"\nYour task is to generate ONE unique version of fix for the buggy function code for the pair of root cause and suggestion: Root Cause: {str(root_cause)}\n{str(suggestion)}\n You should look deeply through all the bug information and combine the root cause and repair suggestions to generate correct patches,
    Requirement:
    1. For each root cause and suggestion pair, generate ONE patch.
    2. Each patch should be a complete version of the buggy function code with the fix applied.
    3. Ensure each patch is unique and addresses the identified issue.
    4. When looking at the buggy function code, the location of the bug is indicated by the /* bug is here */ comment.
    5. The fix may involve changes to surrounding lines, not just the commented line itself.

    Return the whole fixed buggy function code, NOT just the line(s) of fixed area. Only output the following content, nothing else. Please format your response as follows:
    [START PATCH 1]
    ```java
    <entire buggy function fixed code here>
    ```
    [END PATCH 1]

                """

                try:
                    response = api_gpt_response(prompt_patch, 5)
                    usage = response.usage
                    if usage:
                        input_cost = usage.prompt_tokens * 0.000005
                        output_cost = usage.completion_tokens * 0.00002
                        patch_total_cost = input_cost + output_cost
                        logger.info(f"Patch prompt tokens: {usage.prompt_tokens}")
                        logger.info(f"Patch completion tokens: {usage.completion_tokens}")
                        logger.info(f"Patch total tokens: {usage.total_tokens}")
                        logger.info(f"Patch total cost $: {patch_total_cost}")
                        total_cost += patch_total_cost


                    else:
                        logger.info("No tokens recorded")
                    print("***********Gen Patch***********")
                    print(response)

                    for choice in response.choices:
                        print("-----------")
                        suggest_patch = []
                        # generated_text = choice['message']['content'].strip()
                        generated_text = choice.message.content.strip()
                        # print(generated_text)
                        suggest_patch.append(parse_patches(generated_text))
                        logger.info(f"suggest_patch: {parse_patches(generated_text)}")
                        append_patches_to_json(suggest_patch[0], output_patches_file, name)
                except openai.OpenAIError as e:
                    print(f'OpenAI API error: {e}')
                    break

        current_time_2 = datetime.now()
        time_difference_ite = current_time_2 - current_time
        logger.info(f"Time cost for generate patch: {time_difference_ite}")

        end_time = datetime.now()
        time_difference = end_time - start_time
        logger.info(f"Time cost for {name}: {time_difference}")
        logger.info(f"Money cost for {name}: {total_cost}")
    finally:
        sys.stdout = original_stdout
        logger.close()
        time.sleep(10)
