"""Deterministic final fallback for an already filtered candidate layer.

This module deliberately contains no experiment runner or validation logic.
"""
from __future__ import annotations

import difflib
import os
import inspect
import json
import subprocess
import tempfile
from pathlib import Path
from typing import Any, Mapping, Sequence


GUMTREE = "/home/reinfix/tools/gumtree/bin/gumtree"
JAVA21 = "/usr/lib/jvm/java-21-openjdk-amd64"
_WRAPPER_PREFIX = "class PaceFixFallbackWrapper {\n"
_WRAPPER_SUFFIX = "\n}\n"
_DECISION_TYPES = {
    "IfStatement", "ForStatement", "EnhancedForStatement", "WhileStatement",
    "DoStatement", "CatchClause", "ConditionalExpression",
}


def _run(command: Sequence[str], timeout: int) -> tuple[str, str, str]:
    try:
        result = subprocess.run(command, text=True, capture_output=True, timeout=timeout, check=False)
    except subprocess.TimeoutExpired:
        return "TIMEOUT", "", "TIMEOUT"
    return ("PASS", result.stdout, result.stderr) if result.returncode == 0 else ("ERROR", result.stdout, result.stderr)

def _gumtree_command(command: Sequence[str]) -> list[str]:
    path = f"{JAVA21}/bin:" + os.environ.get("PATH", "")
    return ["env", f"JAVA_HOME={JAVA21}", f"PATH={path}", *command]


def _wrapped(code: str) -> str:
    return _WRAPPER_PREFIX + code.strip() + _WRAPPER_SUFFIX


def _gumtree_diff(current_state_code: str, candidate_code: str, timeout: int) -> dict[str, Any] | None:
    with tempfile.TemporaryDirectory(prefix="pacefix_fallback_gumtree_") as directory:
        directory_path = Path(directory)
        before, after = directory_path / "Pt.java", directory_path / "Candidate.java"
        before.write_text(_wrapped(current_state_code), encoding="utf-8")
        after.write_text(_wrapped(candidate_code), encoding="utf-8")
        status, stdout, _ = _run(
            _gumtree_command([GUMTREE, "textdiff", "-g", "java-jdt", "-f", "JSON", str(before), str(after)]),
            timeout,
        )
    if status != "PASS":
        return None
    try:
        result = json.loads(stdout)
    except json.JSONDecodeError:
        return None
    return result if isinstance(result, dict) and isinstance(result.get("actions"), list) else None


def _ast_edit_count(current_state_code: str, candidate_code: str, timeout: int) -> int | None:
    diff = _gumtree_diff(current_state_code, candidate_code, timeout)
    return None if diff is None else len(diff["actions"])


def _changed_loc(current_state_code: str, candidate_code: str) -> int:
    before, after = current_state_code.splitlines(), candidate_code.splitlines()
    added = deleted = 0
    for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(a=before, b=after, autojunk=False).get_opcodes():
        if tag in {"replace", "delete"}:
            deleted += i2 - i1
        if tag in {"replace", "insert"}:
            added += j2 - j1
    return added + deleted


def _parse_jdt(code: str, timeout: int) -> Mapping[str, Any] | None:
    with tempfile.TemporaryDirectory(prefix="pacefix_fallback_jdt_") as directory:
        source = Path(directory) / "Candidate.java"
        source.write_text(_wrapped(code), encoding="utf-8")
        status, stdout, _ = _run(_gumtree_command([GUMTREE, "parse", "-g", "java-jdt", "-f", "JSON", str(source)]), timeout)
    if status != "PASS":
        return None
    try:
        result = json.loads(stdout)
    except json.JSONDecodeError:
        return None
    root = result.get("root") if isinstance(result, dict) else None
    return root if isinstance(root, Mapping) else None


def _cyclomatic_complexity(code: str, timeout: int) -> int | None:
    """Return 1 plus JDT decision points, including short-circuit boolean operators."""
    root = _parse_jdt(code, timeout)
    if root is None:
        return None
    decisions = 0

    def visit(node: Mapping[str, Any]) -> None:
        nonlocal decisions
        node_type = node.get("type")
        if node_type in _DECISION_TYPES:
            decisions += 1
        elif node_type == "SwitchCase" and node.get("label") != "default":
            decisions += 1
        elif node_type == "INFIX_EXPRESSION_OPERATOR" and node.get("label") in {"&&", "||"}:
            decisions += 1
        for child in node.get("children", []):
            if isinstance(child, Mapping):
                visit(child)

    visit(root)
    return 1 + decisions


def _candidate_index(candidate: Mapping[str, Any]) -> int:
    index = candidate.get("candidate_index")
    if not isinstance(index, int):
        raise ValueError("each candidate requires integer candidate_index")
    return index


def select_fallback(current_state_code: str, candidates: Sequence[Mapping[str, Any]], timeout: int = 60) -> dict[str, Any]:
    """Apply the fixed fallback order, computing a later metric only if needed."""
    if not isinstance(current_state_code, str) or not current_state_code.strip():
        raise ValueError("current_state_code must be non-empty")
    if not candidates:
        raise ValueError("fallback requires at least one candidate")
    by_index = {_candidate_index(c): c for c in candidates}
    if len(by_index) != len(candidates):
        raise ValueError("candidate_index values must be unique")
    remaining = list(by_index)
    facts = {index: {"candidate_index": index} for index in remaining}
    stages: dict[str, dict[str, Any]] = {}
    def narrow(field: str, values: Mapping[int, int | None]) -> bool:
        nonlocal remaining
        for index, value in values.items(): facts[index][field] = value
        active = [values[index] for index in remaining]
        if any(value is None for value in active):
            stages[field] = {"status": "skipped", "candidate_indices": list(remaining)}
            return False
        minimum = min(active)
        remaining = [index for index in remaining if values[index] == minimum]
        stages[field] = {"status": "applied", "minimum": minimum, "candidate_indices": list(remaining)}
        return len(remaining) == 1
    if narrow("ast_edit_count", {i: _ast_edit_count(current_state_code, by_index[i]["patch_code"], timeout) for i in remaining}):
        decided_by = "ast_edit_count"
    elif narrow("changed_loc", {i: _changed_loc(current_state_code, by_index[i]["patch_code"]) for i in remaining}):
        decided_by = "changed_loc"
    else:
        base = _cyclomatic_complexity(current_state_code, timeout)
        unique = narrow("complexity_delta", {i: None if base is None else (None if (value := _cyclomatic_complexity(by_index[i]["patch_code"], timeout)) is None else value - base) for i in remaining})
        decided_by = "complexity_delta" if unique else "generation_order"
    if len(remaining) > 1:
        selected = min(remaining)
        stages["generation_order"] = {"status": "applied", "candidate_indices": [selected]}
    else:
        selected = remaining[0]
        stages["generation_order"] = {"status": "not_needed", "candidate_indices": [selected]}
    return {"selected_candidate_index": selected, "decided_by": decided_by,
            "candidates": [facts[i] for i in by_index], "stages": stages}


# Stateful three-round orchestration.  Stage callables are injected so this
# module does not duplicate frozen Generator/Validator/Control/Dataflow rules.
from dataclasses import dataclass
import hashlib
from typing import Callable

from src.experiment.functional_progress import analyze_validator_results
from src.experiment.pcsf import build_pcsf


@dataclass(frozen=True)
class RunnerHooks:
    """Adapters for the existing stages; all return their existing JSON shapes."""
    generate: Callable[..., Any]
    validate: Callable[..., Sequence[Mapping[str, Any]]]
    control: Callable[[Mapping[str, Any], Sequence[Mapping[str, Any]], str], Mapping[str, Any]] | None = None
    dataflow: Callable[..., Mapping[str, Any]] | None = None
    pcsf: Callable[[str, Sequence[Mapping[str, Any]], Mapping[str, Any]], Mapping[str, Any]] | None = None
    fallback: Callable[[str, Sequence[Mapping[str, Any]]], Mapping[str, Any]] = select_fallback
    progress: Callable[[Sequence[Mapping[str, Any]]], Mapping[str, Any]] = analyze_validator_results


def _indices(records: Sequence[Mapping[str, Any]]) -> list[int]:
    values = []
    for record in records:
        index = record.get("candidate_index")
        if not isinstance(index, int):
            raise ValueError("validator records require integer candidate_index")
        values.append(index)
    if len(values) != len(set(values)):
        raise ValueError("validator records contain duplicate candidate_index")
    return values


def _subset_by_indices(records: Sequence[Mapping[str, Any]], indices: Sequence[int]) -> list[Mapping[str, Any]]:
    wanted = set(indices)
    result = [record for record in records if record["candidate_index"] in wanted]
    if len(result) != len(wanted):
        raise ValueError("stage output contains an unknown candidate_index")
    # Preserve the validator/generator's original order, not the order of an
    # auxiliary stage output.
    return result


def _call_validate_hook(
    hook: Callable[..., Sequence[Mapping[str, Any]]], bug_id: str, round_id: int,
    output_dir: str, current_state_code: str, current_failed_tests: Sequence[str],
    current_test_context: Sequence[Mapping[str, Any]],
) -> Sequence[Mapping[str, Any]]:
    """Bind F_t explicitly while preserving older four-argument test hooks."""
    try:
        inspect.signature(hook).bind(
            bug_id, round_id, output_dir, current_state_code,
            current_failed_tests, current_test_context,
        )
    except TypeError:
        return hook(bug_id, round_id, output_dir, current_state_code)
    return hook(
        bug_id, round_id, output_dir, current_state_code,
        current_failed_tests, current_test_context,
    )


def _candidate_layer(records: Sequence[Mapping[str, Any]], indices: Sequence[int]) -> list[dict[str, Any]]:
    result = []
    for record in _subset_by_indices(records, indices):
        code = record.get("patch_code")
        if not isinstance(code, str):
            raise ValueError(f"candidate {record['candidate_index']} lacks patch_code")
        result.append({"candidate_index": record["candidate_index"], "patch_code": code})
    return result


def _call_dataflow_hook(
    hook: Callable[..., Mapping[str, Any]], current_state_code: str,
    current_failed_tests: Sequence[str], candidates: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any]:
    """Pass F_t to real Dataflow while retaining existing two-argument mocks."""
    try:
        inspect.signature(hook).bind(current_state_code, current_failed_tests, candidates)
    except TypeError:
        return hook(current_state_code, candidates)
    return hook(current_state_code, current_failed_tests, candidates)


def _state_from_selected(record: Mapping[str, Any]) -> dict[str, Any]:
    if record.get("next_state_status") != "available":
        raise RuntimeError("selected_candidate_next_state_unavailable:" + str(record.get("candidate_index")))
    code, failed, context, state_hash = (
        record.get("patch_code"), record.get("next_failed_tests"),
        record.get("next_test_context"), record.get("next_state_sha256"),
    )
    if not isinstance(code, str) or not isinstance(failed, list) or not isinstance(context, list) or not isinstance(state_hash, str):
        raise RuntimeError("selected_candidate_next_state_invalid:" + str(record.get("candidate_index")))
    if hashlib.sha256(code.encode("utf-8")).hexdigest() != state_hash:
        raise RuntimeError("selected_candidate_next_state_hash_mismatch:" + str(record.get("candidate_index")))
    by_test = {item.get("test_id"): item for item in context if isinstance(item, Mapping)}
    if len(by_test) != len(context) or set(by_test) != set(failed):
        raise RuntimeError("selected_candidate_next_context_tests_mismatch:" + str(record.get("candidate_index")))
    if any(item.get("current_state_sha256") != state_hash for item in context):
        raise RuntimeError("selected_candidate_next_context_hash_mismatch:" + str(record.get("candidate_index")))
    return {"current_state_code": code, "current_failed_tests": list(failed),
            "current_test_context": list(context), "current_state_sha256": state_hash}


def _initial_state(code: str, failed_tests: Sequence[str], test_context: Sequence[Mapping[str, Any]], state_hash: str | None) -> dict[str, Any]:
    if not isinstance(code, str) or not isinstance(failed_tests, Sequence) or isinstance(failed_tests, (str, bytes)) or not isinstance(test_context, Sequence):
        raise ValueError("initial P0 state requires code, failed tests, and test context")
    digest = hashlib.sha256(code.encode("utf-8")).hexdigest()
    if state_hash is not None and state_hash != digest:
        raise ValueError("initial_state_sha256_mismatch")
    return {"current_state_code": code, "current_failed_tests": list(failed_tests),
            "current_test_context": list(test_context), "current_state_sha256": digest}


def attach_generation_batches(records: Sequence[Mapping[str, Any]], manifest_file: Path,
                              bug_id: str, round_id: int, current_state_code: str) -> list[Mapping[str, Any]]:
    """Attach only a manifest that exactly matches this P_t and validator output."""
    if not manifest_file.is_file():
        return list(records)
    try:
        manifest = json.loads(manifest_file.read_text(encoding="utf-8"))
        entries = manifest["candidates"]
        state_hash = hashlib.sha256(current_state_code.encode("utf-8")).hexdigest()
        if (manifest.get("bug_id") != bug_id or manifest.get("round_id") != round_id
                or manifest.get("current_state_sha256") != state_hash
                or manifest.get("candidate_count") != len(entries)):
            raise ValueError("generation_manifest_identity_or_state_mismatch")
        batches = {}
        for entry in entries:
            index, batch, patch_hash = entry["candidate_index"], entry["generation_batch"], entry["patch_sha256"]
            if (not isinstance(index, int) or not isinstance(batch, int) or isinstance(batch, bool)
                    or not 1 <= batch <= 3 or not isinstance(patch_hash, str) or index in batches):
                raise ValueError("generation_manifest_entry_invalid")
            batches[index] = (batch, patch_hash)
    except (OSError, KeyError, TypeError, ValueError, json.JSONDecodeError) as exc:
        raise RuntimeError("generation_manifest_invalid") from exc
    if set(batches) != {record.get("candidate_index") for record in records}:
        raise RuntimeError("generation_manifest_candidate_indices_mismatch")
    attached = []
    for record in records:
        index = record["candidate_index"]
        batch, patch_hash = batches[index]
        if not isinstance(record.get("patch_code"), str) or hashlib.sha256(record["patch_code"].encode("utf-8")).hexdigest() != patch_hash:
            raise RuntimeError("generation_manifest_patch_hash_mismatch")
        attached.append({**record, "generation_batch": batch})
    return attached


def _round_artifact_paths(output_dir: str, bug_id: str, round_id: int) -> tuple[Path, Path, Path]:
    round_dir = Path(output_dir).resolve() / f"round_{round_id}"
    return round_dir, round_dir / "patches.json", round_dir / "runner_trace.json"


def _round_trace_payload(bug_id: str, entry: Mapping[str, Any]) -> dict[str, Any]:
    """Persist only the durable state and selection facts for one round."""
    candidate_indices = list(entry.get("generated_candidate_indices", []))
    fallback_result = entry.get("fallback_result")
    if not isinstance(fallback_result, Mapping):
        fallback_result = {
            "used": bool(entry.get("fallback_used", False)),
            "selected_candidate_index": entry.get("selected_candidate_index"),
        }
    control_result = {
        "status": entry.get("control_status"),
        "unavailable_reason": entry.get("control_unavailable_reason"),
        "remaining_candidate_indices": list(entry.get("control_remaining_indices", [])),
    }
    dataflow_result = {
        "status": entry.get("dataflow_status"),
        "reason": entry.get("dataflow_reason"),
        "remaining_candidate_indices": list(entry.get("dataflow_remaining_indices", [])),
    }
    for key in (
        "common_failure_specific_count",
        "common_reference_count",
        "common_failure_specific_test_count",
        "common_reference_test_count",
    ):
        if key in entry:
            dataflow_result[key] = entry[key]
    return {
        "bug_id": bug_id,
        "round_id": entry["round_id"],
        "current_state_sha256": entry["current_state_sha256"],
        "current_failed_tests": list(entry["current_failed_tests"]),
        "generated_count": entry.get("generated_count", len(candidate_indices)),
        "candidate_indices": candidate_indices,
        "control_result": control_result,
        "dataflow_result": dataflow_result,
        "pcsf_feedback_input": entry.get("pcsf_feedback_input", ""),
        "pcsf_status": entry.get("pcsf_status", "not_run"),
        "pcsf_result": dict(entry.get("pcsf_result", {})),
        "fallback_result": dict(fallback_result),
        "selected_candidate_index": entry.get("selected_candidate_index"),
        "next_state_sha256": entry.get("next_state_sha256"),
        "next_failed_tests": entry.get("next_failed_tests"),
    }


def _write_round_trace(trace_file: Path, bug_id: str, entry: Mapping[str, Any]) -> None:
    """Atomically refresh a round trace without touching generated patches."""
    trace_file.parent.mkdir(parents=True, exist_ok=True)
    temporary = trace_file.with_suffix(".json.tmp")
    temporary.write_text(
        json.dumps(_round_trace_payload(bug_id, entry), ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary.replace(trace_file)


def _load_reusable_patches(
    patches_file: Path, trace_file: Path, bug_id: str, round_id: int, state: Mapping[str, Any],
    pcsf_feedback: str = "",
) -> list[str]:
    """Load a completed generation only when its persisted input state matches."""
    if not trace_file.is_file():
        raise RuntimeError(f"existing_patches_missing_runner_trace:{trace_file}")
    try:
        trace = json.loads(trace_file.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"existing_runner_trace_invalid:{trace_file}") from exc
    if not isinstance(trace, Mapping) or trace.get("bug_id") != bug_id or trace.get("round_id") != round_id:
        raise RuntimeError("existing_patches_trace_identity_mismatch")
    if trace.get("current_state_sha256") != state["current_state_sha256"]:
        raise RuntimeError("existing_patches_current_state_sha256_mismatch")
    if trace.get("current_failed_tests") != list(state["current_failed_tests"]):
        raise RuntimeError("existing_patches_current_failed_tests_mismatch")
    if trace.get("pcsf_feedback_input", "") != pcsf_feedback:
        raise RuntimeError("existing_patches_pcsf_feedback_mismatch")
    try:
        payload = json.loads(patches_file.read_text(encoding="utf-8"))
        patches = payload[bug_id]["patches"]
    except (OSError, KeyError, TypeError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"existing_patches_invalid:{patches_file}") from exc
    if not isinstance(patches, list) or not all(isinstance(patch, str) for patch in patches):
        raise RuntimeError("existing_patches_invalid")
    return patches


def run_three_rounds(bug_id: str, output_dir: str, initial_state_code: str,
                     initial_failed_tests: Sequence[str], initial_test_context: Sequence[Mapping[str, Any]],
                     hooks: RunnerHooks, initial_state_sha256: str | None = None) -> dict[str, Any]:
    """Run at most three rounds, using only validator-recorded next-state facts.

    The injected adapters make this orchestration testable without invoking
    Defects4J, Joern, coverage, or an LLM.  They also keep every frozen stage's
    own methods and rules outside the runner.
    """
    state = _initial_state(initial_state_code, initial_failed_tests, initial_test_context, initial_state_sha256)
    trace: list[dict[str, Any]] = []
    termination = "round_limit"
    previous_pcsf_feedback = ""

    for round_id in range(1, 4):
        entry: dict[str, Any] = {
            "round_id": round_id,
            "current_state_sha256": state["current_state_sha256"],
            "current_failed_tests": list(state["current_failed_tests"]),
            "generated_candidate_indices": [], "acceptable_indices": [], "max_progress_indices": [],
            "control_status": "not_run", "control_unavailable_reason": None,
            "control_remaining_indices": [],
            "dataflow_status": "not_run", "dataflow_reason": None,
            "dataflow_remaining_indices": [],
            "fallback_used": False, "selected_candidate_index": None,
            "next_state_sha256": None, "next_failed_tests": None,
            "generated_count": 0,
            "pcsf_feedback_input": previous_pcsf_feedback if round_id > 1 else "",
            "pcsf_status": "not_run",
            "pcsf_result": {},
        }
        _, patches_file, trace_file = _round_artifact_paths(output_dir, bug_id, round_id)
        if patches_file.is_file():
            patches = _load_reusable_patches(
                patches_file, trace_file, bug_id, round_id, state, entry["pcsf_feedback_input"])
            entry["generated_count"] = len(patches)
            entry["generated_candidate_indices"] = list(range(1, len(patches) + 1))
            _write_round_trace(trace_file, bug_id, entry)
            generation = {"reused_patches": True}
        else:
            # This must precede generation so a later validation failure cannot
            # cause the same P_t/F_t invocation to be sampled again.
            _write_round_trace(trace_file, bug_id, entry)
            if round_id == 1:
                generation = hooks.generate(bug_id, round_id, output_dir)
            else:
                generation = hooks.generate(
                    bug_id, round_id, output_dir,
                    current_state_code=state["current_state_code"],
                    current_failed_tests=state["current_failed_tests"],
                    current_test_context=state["current_test_context"],
                    pcsf_feedback=previous_pcsf_feedback or None,
                )
            if patches_file.is_file():
                patches = _load_reusable_patches(
                    patches_file, trace_file, bug_id, round_id, state, entry["pcsf_feedback_input"])
                entry["generated_count"] = len(patches)
                entry["generated_candidate_indices"] = list(range(1, len(patches) + 1))
            _write_round_trace(trace_file, bug_id, entry)
        if isinstance(generation, Mapping) and generation.get("budget_exhausted") is True:
            entry["generation_budget_exhausted"] = True
            _write_round_trace(trace_file, bug_id, entry)
            trace.append(entry)
            termination = "budget_exhausted"
            break

        if isinstance(generation, Mapping) and generation.get("generation_unavailable"):
            # A failed ReAct pass is not a per-bug candidate-budget exhaustion.
            # Keep P_t and allow the next, distinct round to use its own budget.
            entry["generation_unavailable_reason"] = str(generation["generation_unavailable"])
            entry["control_status"] = "not_run_generation_unavailable"
            entry["dataflow_status"] = "not_run_generation_unavailable"
            _write_round_trace(trace_file, bug_id, entry)
            trace.append(entry)
            continue
        if not patches:
            # A completed generation may legitimately contain no parseable
            # candidates (for example, after a recovered ReAct final answer).
            # It is not valid Validator input and does not consume later rounds.
            entry["generation_unavailable_reason"] = "no_candidates_generated"
            entry["control_status"] = "not_run_no_generated_candidates"
            entry["dataflow_status"] = "not_run_no_generated_candidates"
            entry["pcsf_status"] = "skipped_no_generated_candidates"
            _write_round_trace(trace_file, bug_id, entry)
            trace.append(entry)
            continue

        records = list(_call_validate_hook(
            hooks.validate, bug_id, round_id, output_dir, state["current_state_code"],
            state["current_failed_tests"], state["current_test_context"],
        ))
        generated_indices = _indices(records)
        if generated_indices != list(range(1, len(patches) + 1)):
            raise RuntimeError("validator_candidate_indices_do_not_match_patches_order")
        if any(record.get("bug_id") != bug_id or record.get("round_id") != round_id for record in records):
            raise RuntimeError("validator_record_identity_mismatch")
        if any(record.get("current_state_sha256") != state["current_state_sha256"] for record in records):
            raise RuntimeError("validator_current_state_sha256_mismatch")
        if any(record.get("current_failed_tests") != list(state["current_failed_tests"]) for record in records):
            raise RuntimeError("validator_current_failed_tests_mismatch")
        entry["generated_candidate_indices"] = generated_indices
        entry["generated_count"] = len(generated_indices)
        progress = hooks.progress(records)
        candidate_summaries = progress.get("candidates", [])
        entry["acceptable_indices"] = [item["candidate_index"] for item in candidate_summaries if item.get("acceptable") is True]
        max_indices = list(progress.get("max_progress_candidate_indices", []))
        entry["max_progress_indices"] = max_indices

        if progress.get("decision") == "no_acceptable_candidate":
            entry["control_status"] = "not_run_no_acceptable_candidate"
            entry["dataflow_status"] = "not_run_no_acceptable_candidate"
            _write_round_trace(trace_file, bug_id, entry)
            trace.append(entry)
            continue
        if not max_indices or not set(max_indices).issubset(set(generated_indices)):
            raise RuntimeError("progress_candidate_indices_invalid")

        remaining = _subset_by_indices(records, max_indices)
        if len(remaining) > 1:
            if hooks.dataflow is None:
                raise RuntimeError("dataflow_hook_required_for_ambiguous_progress")
            dataflow = _call_dataflow_hook(
                hooks.dataflow, state["current_state_code"], state["current_failed_tests"],
                _candidate_layer(remaining, _indices(remaining)),
            )
            entry["dataflow_status"] = str(dataflow.get("status", "unknown"))
            entry["dataflow_reason"] = dataflow.get("reason")
            entry["dataflow_candidates"] = list(dataflow.get("candidates", []))
            if dataflow.get("status") == "available":
                top = list(dataflow.get("highest_score_candidate_indices", []))
                if not top or not set(top).issubset(set(_indices(remaining))):
                    raise RuntimeError("dataflow_candidate_indices_invalid")
                remaining = _subset_by_indices(remaining, top)
        else:
            entry["dataflow_status"] = "not_run_unique_progress"
        entry["dataflow_remaining_indices"] = _indices(remaining)

        if len(remaining) > 1:
            if hooks.control is None:
                raise RuntimeError("control_hook_required_for_unresolved_dataflow")
            control_progress = dict(progress)
            control_progress["max_progress_candidate_indices"] = _indices(remaining)
            control = hooks.control(control_progress, remaining, state["current_state_code"])
            control_indices = list(control.get("kept_candidate_indices", []))
            if not control_indices or not set(control_indices).issubset(set(_indices(remaining))):
                raise RuntimeError("control_candidate_indices_invalid")
            remaining = _subset_by_indices(remaining, control_indices)
            entry["control_status"] = str(control.get("control_evidence", control.get("decision", "unknown")))
            entry["control_unavailable_reason"] = control.get("unavailable_reason")
            entry["control_candidates"] = list(control.get("candidates", []))
        else:
            entry["control_status"] = "not_run_unique_dataflow"
        entry["control_remaining_indices"] = _indices(remaining)

        if len(remaining) > 1:
            fallback = hooks.fallback(state["current_state_code"], _candidate_layer(remaining, _indices(remaining)))
            selected_index = fallback.get("selected_candidate_index")
            if selected_index not in _indices(remaining):
                raise RuntimeError("fallback_candidate_index_invalid")
            entry["fallback_used"] = True
            entry["fallback_result"] = {
                "used": True,
                "selected_candidate_index": selected_index,
                "decided_by": fallback.get("decided_by"),
            }
        else:
            selected_index = remaining[0]["candidate_index"]
        selected = _subset_by_indices(records, [selected_index])[0]
        next_state = _state_from_selected(selected)
        entry["selected_candidate_index"] = selected_index
        entry["next_state_sha256"] = next_state["current_state_sha256"]
        entry["next_failed_tests"] = list(next_state["current_failed_tests"])
        if not next_state["current_failed_tests"]:
            entry["pcsf_status"] = "skipped_all_tests_pass"
        elif round_id == 3:
            entry["pcsf_status"] = "skipped_no_next_round"
        elif hooks.pcsf is not None:
            pcsf = hooks.pcsf(state["current_state_code"], records, progress)
            entry["pcsf_result"] = dict(pcsf)
            entry["pcsf_status"] = str(pcsf.get("status", "unknown"))
            previous_pcsf_feedback = str(entry["pcsf_result"].get("feedback_text", ""))
        else:
            entry["pcsf_status"] = "not_configured"
        _write_round_trace(trace_file, bug_id, entry)
        trace.append(entry)
        state = next_state
        if not state["current_failed_tests"]:
            termination = "all_tests_pass"
            break
    return {"bug_id": bug_id, "termination": termination, "rounds": trace,
            "final_state_sha256": state["current_state_sha256"],
            "final_failed_tests": list(state["current_failed_tests"]),
            "final_state_code": state["current_state_code"]}


def build_real_runner_hooks(
    dataset_path: str | None = None,
    validation_output_dir: str | None = None,
) -> RunnerHooks:
    """Connect frozen experiment modules; defer all heavy work to hooks."""
    from src.experiment.control_risk import run_control_layer
    from src.experiment.dataflow_evidence import run_dataflow_layer
    from src.experiment.pacefix_generator import generate_once
    from src.experiment.pacefix_validator import (
        clean_tmp_folder, checkout_defects4j_project, defects4j_export_relevant,
        validate_patches_per_bug,
    )

    repo_root = Path(__file__).resolve().parents[2]
    dataset_file = Path(dataset_path) if dataset_path else repo_root / "D4J_dataset" / "defects4j-v12-sf-255.json"
    dataset = json.loads(dataset_file.read_text(encoding="utf-8"))
    if not isinstance(dataset, Mapping):
        raise ValueError("Dataflow dataset must be a JSON object")
    validation_root = Path(validation_output_dir) if validation_output_dir else repo_root / "experiment_output" / "validation"
    relevant_classes_by_bug: dict[str, list[str]] = {}
    current_bug_id: list[str] = [""]

    def generate_adapter(bug_id: str, round_id: int, output_dir: str, **state: Any) -> None:
        current_bug_id[0] = bug_id
        return generate_once(bug_id, round_id, output_dir, dataset_path=str(dataset_file), **state)

    def validate_adapter(
        bug_id: str, round_id: int, output_dir: str, current_state_code: str,
        current_failed_tests: Sequence[str] | None = None,
        current_test_context: Sequence[Mapping[str, Any]] | None = None,
    ) -> Sequence[Mapping[str, Any]]:
        # Reused rounds bypass generate_adapter, so establish the same bug
        # context here before a possible later Dataflow call.
        current_bug_id[0] = bug_id
        patches_file = Path(output_dir).resolve() / f"round_{round_id}" / "patches.json"
        try:
            generated = json.loads(patches_file.read_text(encoding="utf-8"))
            patches = generated[bug_id]["patches"]
        except (OSError, KeyError, TypeError, json.JSONDecodeError) as exc:
            raise RuntimeError(f"generated_patches_unavailable:{patches_file}") from exc
        if not isinstance(patches, list) or not all(isinstance(patch, str) for patch in patches):
            raise RuntimeError("generated_patches_invalid")

        validation_tmp = Path("/tmp/llm4apr_validation")
        # Validator helpers change into the checkout directory.  Reset to a
        # durable directory before deleting/recreating that temporary tree.
        os.chdir(repo_root)
        clean_tmp_folder(str(validation_tmp))
        round_validation_output = validation_root / f"round_{round_id}"
        round_validation_output.mkdir(parents=True, exist_ok=True)
        (validation_tmp / "config.json").write_text(json.dumps({
            "input_path": str(patches_file), "output_path": str(round_validation_output),
            "dataset_path": str(dataset_file), "log_mode": False,
        }), encoding="utf-8")
        payload: dict[str, Any] = {"patches": patches, "round_id": round_id}
        if current_failed_tests is not None:
            payload["current_failed_tests"] = list(current_failed_tests)
        if current_test_context is not None:
            payload["current_test_context"] = list(current_test_context)
        if round_id > 1:
            payload["current_state_code"] = current_state_code
        records = validate_patches_per_bug((bug_id, payload))
        if not isinstance(records, list):
            raise RuntimeError("validator_records_unavailable")
        return attach_generation_batches(
            records, patches_file.parent / "generation_manifest.json",
            bug_id, round_id, current_state_code,
        )

    def control_adapter(progress: Mapping[str, Any], records: Sequence[Mapping[str, Any]], current_state_code: str) -> Mapping[str, Any]:
        return run_control_layer(progress, records, current_state_code, dataset)

    def relevant_classes(bug_id: str) -> list[str]:
        cached = relevant_classes_by_bug.get(bug_id)
        if cached is not None:
            return cached
        with tempfile.TemporaryDirectory(prefix="pacefix_runner_relevant_") as directory:
            project_dir = Path(directory) / bug_id
            checkout_defects4j_project(bug_id, str(project_dir))
            stdout, stderr = defects4j_export_relevant(str(project_dir))
        if stdout == "TIMEOUT" or stderr == "TIMEOUT":
            raise RuntimeError("relevant_test_export_timeout")
        classes = [line.strip() for line in str(stdout).splitlines() if line.strip()]
        if not classes:
            raise RuntimeError("relevant_test_export_empty:" + str(stderr).strip())
        relevant_classes_by_bug[bug_id] = classes
        return classes

    def dataflow_adapter(current_state_code: str, current_failed_tests: Sequence[str], candidates: Sequence[Mapping[str, Any]]) -> Mapping[str, Any]:
        bug_id = current_bug_id[0]
        if not bug_id:
            raise RuntimeError("dataflow_bug_context_unavailable")
        return run_dataflow_layer(bug_id, current_state_code, current_failed_tests, candidates, dataset)

    def pcsf_adapter(current_state_code: str, records: Sequence[Mapping[str, Any]], progress: Mapping[str, Any]) -> Mapping[str, Any]:
        return build_pcsf(current_state_code, records, progress)

    return RunnerHooks(
        generate=generate_adapter, validate=validate_adapter,
        control=control_adapter, dataflow=dataflow_adapter, pcsf=pcsf_adapter,
        fallback=select_fallback, progress=analyze_validator_results,
    )
