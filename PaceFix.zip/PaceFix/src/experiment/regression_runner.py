import argparse,hashlib,json,os,sys,tempfile,traceback
from pathlib import Path

if __package__ in {None, ""}:
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from src.experiment.dataflow_evidence import run_dataflow_layer
from src.experiment.control_risk import run_control_layer
from src.experiment.pacefix_runner import select_fallback
from src.experiment.functional_progress import analyze_validator_results

CONFIG={"Chart-11":"experiment_output/runner_chart11_smoke_03","Chart-12":"experiment_output/gpt4o_mini_runner_chart12_02","Chart-13":"experiment_output/gpt4o_mini_runner_chart13_01","Chart-26":"experiment_output/gpt4o_mini_multiround_chart26_01","Chart-4":"experiment_output/gpt4o_mini_multiround_chart4_02"}

def current_failed_tests(records):
    values={tuple(record.get("current_failed_tests",[])) for record in records}
    if len(values)!=1 or not values or not next(iter(values)):
        raise RuntimeError("validator_current_failed_tests_inconsistent")
    return list(next(iter(values)))

def write(path,data):
    fd,tmp=tempfile.mkstemp(prefix=path.name+".",dir=path.parent); os.close(fd)
    Path(tmp).write_text(json.dumps(data,indent=2)+"\n"); os.replace(tmp,path)

def main():
    a=argparse.ArgumentParser();a.add_argument("bug");ns=a.parse_args(); bug=ns.bug
    root=CONFIG[bug]; out=Path("experiment_output")/f"regression_{bug}.json"
    state=json.loads(out.read_text()) if out.exists() else {"bug":bug,"status":"running"}
    print("START",flush=True)
    try:
        if "loaded" not in state:
            data=json.loads(Path("D4J_dataset/defects4j-sf.json").read_text()); records=json.loads((Path(root)/"validator_results"/bug/"round_1"/f"{bug}-validated.jsonl").read_text()); failed=current_failed_tests(records); progress=analyze_validator_results(records); indices=progress["max_progress_candidate_indices"]
            state["loaded"]={"root":root,"candidate_indices":indices,"failed_tests":failed,"current_state_sha256":records[0].get("current_state_sha256")};write(out,state)
        print("MAX_PROGRESS_DONE",flush=True)
        data=json.loads(Path("D4J_dataset/defects4j-sf.json").read_text()); records=json.loads((Path(root)/"validator_results"/bug/"round_1"/f"{bug}-validated.jsonl").read_text()); failed=current_failed_tests(records); progress=analyze_validator_results(records); indices=progress["max_progress_candidate_indices"]; pt=data[bug]["buggy_fl"]
        if hashlib.sha256(pt.encode("utf-8")).hexdigest() != records[0].get("current_state_sha256"):
            raise RuntimeError("validator_current_state_sha256_mismatch")
        if (state.get("loaded",{}).get("failed_tests") != failed or
                state.get("loaded",{}).get("candidate_indices") != indices or
                state.get("loaded",{}).get("current_state_sha256") != records[0].get("current_state_sha256")):
            raise RuntimeError("existing_checkpoint_current_layer_mismatch")
        layer=[x for x in records if x["candidate_index"] in indices]
        if "dataflow_done" not in state:
            d=run_dataflow_layer(bug,pt,failed,layer,data);state["dataflow_done"]={"status":d["status"],"candidates":d["candidates"],"remaining":d["highest_score_candidate_indices"]};write(out,state)
        print("DATAFLOW_DONE",flush=True); layer=[x for x in layer if x["candidate_index"] in state["dataflow_done"]["remaining"]]
        if len(layer)>1 and "control_done" not in state:
            control_progress=dict(progress);control_progress["max_progress_candidate_indices"]=[x["candidate_index"] for x in layer]
            c=run_control_layer(control_progress,layer,pt,data);state["control_done"]={"decision":c["decision"],"candidates":c["candidates"],"remaining":c["kept_candidate_indices"]};write(out,state)
        print("CONTROL_DONE",flush=True)
        if "control_done" in state: layer=[x for x in layer if x["candidate_index"] in state["control_done"]["remaining"]]
        if "fallback_done" not in state:
            f=select_fallback(pt,[{"candidate_index":x["candidate_index"],"patch_code":x["patch_code"]} for x in layer]) if len(layer)>1 else {"selected_candidate_index":layer[0]["candidate_index"],"decided_by":"unique"};state["fallback_done"]=f;write(out,state)
        print("FALLBACK_DONE",flush=True);state["completed"]={"final":state["fallback_done"]["selected_candidate_index"]};state["status"]="completed";write(out,state);print("COMPLETED",flush=True)
    except Exception as e:
        if str(e).startswith("existing_checkpoint_"):
            raise
        state.update({"status":"failed","stage":next((x for x in ["fallback_done","control_done","dataflow_done","loaded"] if x not in state),"loaded"),"error":str(e)[:500]});write(out,state);raise
if __name__=="__main__":main()
