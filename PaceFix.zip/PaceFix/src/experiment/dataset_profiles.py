"""Central dataset/output profiles for the formal experiment launchers.

Profiles only select already prepared Defects4J metadata and a durable output
root. They never alter the PaceFix generation or selection methodology.
"""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]

@dataclass(frozen=True)
class DatasetProfile:
    name: str
    dataset_path: Path
    output_root: Path

_PROFILES = {
    "v1.2": DatasetProfile("v1.2", REPO_ROOT / "D4J_dataset" / "defects4j-v12-sf-255.json", REPO_ROOT / "experiment_output" / "Defects4J"),
    "v2.0": DatasetProfile("v2.0", REPO_ROOT / "D4J_dataset" / "defects4j-v20-sf-228.json", REPO_ROOT / "experiment_output" / "Defects4J2.0"),
}

def get_dataset_profile(name: str = "v1.2") -> DatasetProfile:
    try: profile = _PROFILES[name]
    except KeyError as exc: raise ValueError(f"unsupported_dataset:{name}") from exc
    if not profile.dataset_path.is_file(): raise RuntimeError(f"dataset_metadata_missing:{profile.dataset_path}")
    return profile

def dataset_choices() -> tuple[str, ...]:
    return tuple(_PROFILES)
