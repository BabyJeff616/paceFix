"""Per-round patch-structure feedback (PCSF).

PCSF is observational only: it never ranks or removes candidates.  It compares
validated, safe candidates from one P_t against their own P_t -> candidate
GumTree diffs and returns at most three structural suggestions for the next
round.
"""
from __future__ import annotations

import json
import math
import os
import subprocess
import tempfile
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from src.experiment.functional_progress import summarize_candidate

GUMTREE = "/home/reinfix/tools/gumtree/bin/gumtree"
JAVA21 = "/usr/lib/jvm/java-21-openjdk-amd64"
_PREFIX = "class PcsfWrapper {\n"
_SUFFIX = "\n}\n"


def _command(command: Sequence[str]) -> list[str]:
    return ["env", f"JAVA_HOME={JAVA21}", f"PATH={JAVA21}/bin:" + os.environ.get("PATH", ""), *command]


def gumtree_diff(current_state_code: str, candidate_code: str, timeout: int = 60) -> Mapping[str, Any]:
    with tempfile.TemporaryDirectory(prefix="pacefix_pcsf_gumtree_") as directory:
        directory = Path(directory)
        before, after = directory / "Pt.java", directory / "Candidate.java"
        before.write_text(_PREFIX + current_state_code.strip() + _SUFFIX, encoding="utf-8")
        after.write_text(_PREFIX + candidate_code.strip() + _SUFFIX, encoding="utf-8")
        completed = subprocess.run(
            _command([GUMTREE, "textdiff", "-g", "java-jdt", "-f", "JSON", str(before), str(after)]),
            text=True, capture_output=True, timeout=timeout, check=False,
        )
    if completed.returncode != 0:
        raise RuntimeError("gumtree_failed:" + completed.stderr.strip())
    payload = json.loads(completed.stdout)
    if not isinstance(payload, Mapping) or not isinstance(payload.get("actions"), list):
        raise ValueError("gumtree_actions_missing")
    return payload


def _node_type(value: Any) -> str | None:
    text = str(value or "").strip()
    if not text:
        return None
    return text.split(":", 1)[0].split(" ", 1)[0] or None


def normalize_actions(diff: Mapping[str, Any]) -> set[str]:
    """Deduplicate edit-type + node-type + parent-type signatures per candidate."""
    signatures: set[str] = set()
    for action in diff.get("actions", []):
        if not isinstance(action, Mapping):
            continue
        edit = str(action.get("action", "")).split("-", 1)[0]
        node = _node_type(action.get("tree"))
        parent = _node_type(action.get("parent"))
        if edit not in {"insert", "delete", "update", "move"} or node is None or parent is None:
            continue
        signatures.add(f"{edit} + {node} + {parent}")
    return signatures


def _eligible_cohort(records: Sequence[Mapping[str, Any]], progress: Mapping[str, Any]) -> tuple[list[Mapping[str, Any]], int | None, int | None]:
    """Return the AGENTS.md adaptive near-max-progress cohort for this round."""
    failed_tests = progress.get("current_failed_tests")
    max_progress = progress.get("max_progress")
    if not isinstance(failed_tests, list) or not isinstance(max_progress, int) or max_progress < 1:
        return [], None, None
    threshold = max(2, math.ceil(0.2 * len(failed_tests)))
    minimum_progress = max_progress - threshold
    cohort: list[Mapping[str, Any]] = []
    for record in records:
        try:
            summary = summarize_candidate(record, failed_tests)
        except (TypeError, ValueError):
            continue
        if (summary.get("acceptable") is True
                and summary.get("progress", -1) >= minimum_progress
                and isinstance(record.get("patch_code"), str)):
            cohort.append(record)
    return cohort, threshold, minimum_progress


def build_pcsf(current_state_code: str, records: Sequence[Mapping[str, Any]], progress: Mapping[str, Any],
               diff_fn: Callable[[str, str], Mapping[str, Any]] = gumtree_diff) -> dict[str, Any]:
    """Build one round's non-ranking PCSF result from the adaptive cohort."""
    cohort, threshold, minimum_progress = _eligible_cohort(records, progress)
    base = {
        "cohort_candidate_indices": [r["candidate_index"] for r in cohort],
        "ambiguity_threshold": threshold,
        "minimum_progress": minimum_progress,
    }
    if not cohort:
        return {"status": "unavailable", "reason": "eligible_cohort_candidates_missing", "signals": [], "feedback_text": "", **base}
    if len(cohort) < 2:
        return {"status": "no_signal", "reason": "fewer_than_two_cohort_candidates", "signals": [], "feedback_text": "", **base}
    signatures: dict[int, set[str]] = {}
    for record in cohort:
        index = record["candidate_index"]
        try:
            signatures[index] = normalize_actions(diff_fn(current_state_code, record["patch_code"]))
        except (OSError, subprocess.TimeoutExpired, RuntimeError, ValueError, json.JSONDecodeError) as exc:
            return {"status": "unavailable", "reason": "gumtree_diff_failed", "detail": str(exc), "signals": [], "feedback_text": "", **base}

    signals = []
    cohort_count = len(cohort)
    all_signatures = set().union(*(signatures[r["candidate_index"]] for r in cohort))
    for signature in all_signatures:
        cohort_records = [r for r in cohort if signature in signatures[r["candidate_index"]]]
        if len(cohort_records) >= 2:
            signals.append({"signature": signature, "cohort_count": len(cohort_records),
                            "cohort_fraction": len(cohort_records) / cohort_count})
    signals.sort(key=lambda item: (-item["cohort_fraction"], -item["cohort_count"], item["signature"]))
    signals = signals[:3]
    feedback = "" if not signals else "PCSF structural feedback from the preceding round:\n" + "\n".join(
        f"- {item['signature']} (cohort {item['cohort_count']}/{cohort_count})"
        for item in signals
    )
    return {"status": "available" if signals else "no_signal", "reason": None if signals else "no_stable_structure_signal",
            "signals": signals, "feedback_text": feedback, **base}
