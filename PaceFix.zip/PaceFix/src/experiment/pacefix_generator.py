import sys
import time
import argparse

import openai
import os
import shutil
from langchain_core.prompts import PromptTemplate
from langchain_community.callbacks import get_openai_callback
from langchain.callbacks.openai_info import OpenAICallbackHandler
from langchain_core.runnables.config import RunnableConfig
from langchain.agents import AgentExecutor, create_react_agent
from langchain_openai import ChatOpenAI

import re
import json
from datetime import datetime
import hashlib

from src.config import OPENAI_API_KEY, OPENAI_BASE_URL
from src.experiment.pacefix_tools import *

os.environ["OPENAI_API_KEY"] = OPENAI_API_KEY
os.environ["OPENAI_BASE_URL"] = OPENAI_BASE_URL
os.environ["OPENAI_API_BASE"] = OPENAI_BASE_URL

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
REPO_ROOT = os.path.abspath(os.path.join(SCRIPT_DIR, "..", ".."))
EXPERIMENT_MODEL = "gpt-3.5-turbo"



def extract_and_save_final_answer(text, output_file, name):
    root_cause_match = re.search(r"(?i)root\s*cause:?\s*(.+?)(?=\n+ *suggestion|\Z)", text, re.DOTALL | re.IGNORECASE)
    suggestions_matches = re.finditer(r"(?i)suggestion\s*(\d+):?\s*(.*?)(?=\n\s*suggestion|\Z)", text,
                                      re.DOTALL | re.IGNORECASE)

    if not root_cause_match:
        raise ValueError("Root Cause not found in the text")

    root_cause = root_cause_match.group(1).strip()
    suggestions = []

    for idx, match in enumerate(suggestions_matches):
        if idx >= 3:
            break
        suggestion_number = match.group(1)
        suggestion_text = match.group(2).strip()

        lines = suggestion_text.split('\n', 1)
        title = lines[0].strip()
        details = lines[1].strip() if len(lines) > 1 else ""

        suggestions.append("Suggestion " + suggestion_number + ". " + title + " " + details + "\n")
    all_analyses = {
        name: {
            root_cause: suggestions
        }
    }

    # 保存为 JSON 文件
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(all_analyses, f, ensure_ascii=False, indent=2)

    return all_analyses


def is_react_iteration_limit(value) -> bool:
    return "Agent stopped due to iteration limit or time limit." in str(value)


def recover_react_final_answer_from_log(log_file, output_file, name):
    """Recover a valid final answer already emitted before ReAct parsing failed."""
    if not os.path.isfile(log_file):
        return None
    with open(log_file, encoding="utf-8") as f:
        log_text = f.read()
    matches = re.findall(
        r"Could not parse LLM output: \`(.*?)(?=\`\s*\nFor troubleshooting)",
        log_text,
        re.DOTALL,
    )
    for text in reversed(matches):
        try:
            return extract_and_save_final_answer(text, output_file, name)
        except ValueError:
            continue
    return None


def parse_patches(result):
    pattern = r'\[START PATCH \d+\]\n```\w*\n(.*?)\n```\n\[END PATCH \d+\]'
    patches = re.findall(pattern, result, re.DOTALL)

    return [patch.strip() for patch in patches]


def api_gpt_response(prompt, n):
    response = openai.chat.completions.create(
        messages=[{"role": "user", "content": prompt}],
        model=EXPERIMENT_MODEL,
        n=n,
        temperature=1,
        timeout=120)
    return response


def append_patches_to_json(patches, file_path, project_name):
    if not os.path.exists(file_path):
        data = {}
    else:
        with open(file_path, 'r') as f:
            data = json.load(f)
    if project_name not in data:
        data[project_name] = {"patches": []}
    data[project_name]["patches"].extend(patches)
    with open(file_path, 'w') as f:
        json.dump(data, f, indent=2)


tools = [open_proj_tool, trace_method_usage_tool, find_method_in_file_tool, analyze_method_details_tool,
         analyze_method_control_flow_tool,
         find_class_loc_tool, identify_class_tool, get_imports_tool, close_proj_tool, example_patch_search_tool]

def write_generation_manifest(file_path, bug_id, round_id, current_state_code, candidates, patches):
    """Persist the exact P_t and patch-to-batch mapping for one fresh round."""
    if not isinstance(current_state_code, str) or not isinstance(patches, list):
        raise ValueError("generation_manifest_requires_state_and_patches")
    if Path(file_path).exists():
        raise FileExistsError(f"generation manifest already exists: {file_path}")
    expected_indices = list(range(1, len(patches) + 1))
    entries = list(candidates)
    if [entry.get("candidate_index") for entry in entries] != expected_indices:
        raise ValueError("generation_manifest_candidate_order_mismatch")
    normalized = []
    for entry, patch in zip(entries, patches):
        batch = entry.get("generation_batch")
        if not isinstance(batch, int) or isinstance(batch, bool) or not 1 <= batch <= 3 or not isinstance(patch, str):
            raise ValueError("generation_manifest_entry_invalid")
        normalized.append({
            "candidate_index": entry["candidate_index"],
            "generation_batch": batch,
            "patch_sha256": hashlib.sha256(patch.encode("utf-8")).hexdigest(),
        })
    payload = {
        "bug_id": bug_id,
        "round_id": round_id,
        "current_state_sha256": hashlib.sha256(current_state_code.encode("utf-8")).hexdigest(),
        "candidate_count": len(patches),
        "candidates": normalized,
    }
    Path(file_path).write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    return payload


prompt_solution_template = PromptTemplate.from_template("""
You are an expert Java programmer and code analyzer. Your task is to analyze a given Java code snippet, identify the root cause of a bug, and provide repair suggestions.

## Available Tools

You have access to the following Joern-based tools and one Example Patch Search tool:
{tools}
{tool_names}

for each tool call:
  "tool": "Tool to be called from tools, if applicable. Set to 'None' if no tool is needed.",
  "parameters": "The input parameter(s) used by the tools. Only the parameter value(s) (e.g. getIndexOf), (e.g. getLegendItems, AbstractCategoryItemRenderer.java). Set to 'None' if there are no parameters.". DO NOT try to modify any parameter format(e.g., open("Chart-1_buggy") rather than open("Chart_1_buggy\"\n") etc.). 

- IMPORTANT: Do not modify tool parameters in any way. Use them exactly as provided in the input context. DO NOT Add any quota marks to the parameter because the tool call will process it.
- An Action must be exactly one name listed in {tool_names}. Never write Call <tool>, Final Action, or any other prefix. For example, use Action: example_patch_search.

## Analysis Process

1. Open the CPG for the buggy code (always required as first stage)
2. Analyze the buggy code, focusing on the area marked with /* bug is here */
3. Use tools to gather necessary information about( DO NOT Add any quota marks to the input parameter because the tool call will process it.):
   - Variable definitions and usages
   - Function calls and definitions
   - Control flow
   - Similar patterns in the codebase
   - Import statements and library usage
4. Synthesize gathered information
5. Close the project (always required after gather enough information and before output the Summary Answer)
6. Output the Summary Answer.
7. Concatenate the complete Buggy function code and root cause, use them as the input parameter of calling example_patch_search. It will return a fix pattern contain buggy code, fix code and root cause.
8. Observe the fix pattern of similar bug from example_patch_search output as reference, learn and update the root cause and suggestions as the Final Answer.

## Guidelines
- Open and close the CPG project properly
- Focus on the buggy function and lines(before or at) marked with /* bug is here */
- Avoid unnecessary tool calls if information can be inferred from context
- Ensure your analysis covers context, potential causes, and fix suggestions
- Gather repair contexts as much as you need to draw the root cause.
- Call example_patch_search if you think the joern analyze information is not enough to provide the Final Answer.


## Input Context

- Buggy ID(proj_name): {buggy_id}
- Buggy File: {buggy_file_path}
- Buggy Function: 
```java
{buggy_code}
```
- Trigger Test: {trigger_src}
- Error Message: {err_msg}

To help you better use example_patch_search call, make sure the parameter is the full buggy code concatenate with the root cause, here is an Example:
Action Input:"input_string":  <Buggy code>, Root Cause: <content>"


## Output Format

Use the following format for your analysis:

Thought: [Your reasoning about the next step]
Action: [Tool name]
Action Input: "value1", "value2"
Observation: [Tool output]
... (Repeat Thought/Action/Action Input/Observation as needed)
Thought: I now have enough information to provide the Summary Answer
Action: example_patch_search
Action Input: "buggy_code, root_cause"
Observation: [Tool output]
Thought: I now have learnt the fix pattern, and I can update and output the Final Answer

Final Answer(IMPORTANT: Strictly follow the output format below and DO NOT add '#', '*' or other signs before each Root Cause & Suggestion title): 
Root Cause: [Detailed explanation of the bug's root cause]

Suggestion 1: [Suggestion title]
[Detailed description of the first repair suggestion, give step by step and sufficient suggestion to help generate correct patches. Only provide how to generate correct patch suggestions, not involve test process. Note that each suggestion should be independent]
Suggestion 2: [Suggestion title]
[Detailed description of the second repair suggestion, give step by step and sufficient suggestion to help generate correct patches. Only provide how to generate correct patch suggestions, not involve test process. Note that each suggestion should be independent]

[You may provide up to 3 repair suggestions in total. Do not provide more than 3 suggestions. Please make sure your Final Answer follows the format above exactly, without adding any extra marks or symbols]

## Begin Your Analysis

Start by opening the CPG and analyzing the buggy code. Focus on the area marked with /* bug is here */ and use the available tools to gather necessary information.
Exit the chain when you already output the Final Answer.
Thought: {agent_scratchpad}
""")

tool_descriptions = "\n".join(
    f"{i + 1}. {tool.description}\n"
    for i, tool in enumerate(tools)
)
tool_names = "\n".join(
    f"{i + 1}. {tool.name}\n"
    for i, tool in enumerate(tools)
)


class Logger(object):
    def __init__(self, filename='default.log', stream=sys.stdout):
        self.terminal = stream
        os.makedirs(os.path.dirname(filename), exist_ok=True)
        self.log = open(filename, 'a', encoding='utf-8')
        self._closed = False

    def _log(self, level, message):
        if message.strip():
            timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            message = f'[{timestamp}] [{level.upper()}] {message}\n'
            self.terminal.write(message)
            self.log.write(message)

    def info(self, message):
        self._log('info', message)

    def error(self, message):
        self._log('error', message)

    def warning(self, message):
        self._log('warning', message)

    def write(self, message):
        if message.strip():
            timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            message = f'[{timestamp}] {message}'
        self.terminal.write(message)
        self.log.write(message)

    def flush(self):
        self.terminal.flush()
        self.log.flush()

    def close(self):
        self.flush()
        self.log.close()



# Fixed single-round PaceFix candidate generator.
def _state_prompt_context(current_failed_tests, current_test_context, state_sha256):
    """Validate P_t failure facts and preserve their test/source/error prompt roles."""
    if not isinstance(current_failed_tests, (list, tuple)) or not all(isinstance(test_id, str) for test_id in current_failed_tests):
        raise ValueError("current_failed_tests must be an ordered list of test identifiers")
    if not isinstance(current_test_context, list):
        raise ValueError("current_test_context must be a list")
    expected = list(current_failed_tests)
    by_test = {}
    for item in current_test_context:
        if not isinstance(item, dict):
            raise ValueError("current_test_context entries must be objects")
        test_id = item.get("test_id")
        if test_id not in expected or test_id in by_test:
            raise ValueError("current_test_context test identifiers must match current_failed_tests")
        if item.get("current_state_sha256") != state_sha256:
            raise ValueError("current_test_context_state_mismatch")
        if not isinstance(item.get("failure_info"), str):
            raise ValueError("current_test_context entries require failure_info")
        by_test[test_id] = item
    if set(by_test) != set(expected):
        raise ValueError("current_test_context must cover exactly current_failed_tests")
    ordered = [by_test[test_id] for test_id in expected]
    test_sources = [{"test_id": item["test_id"], "test_source": item.get("test_source")} for item in ordered]
    failure_info = [{"test_id": item["test_id"], "failure_info": item["failure_info"]} for item in ordered]
    return test_sources, failure_info


def generate_once(bug_id, round_id, output_dir, current_state_code=None, current_failed_tests=None, current_test_context=None, joern_project_name=None, pcsf_feedback=None, dataset_path=None):
    if not 1 <= round_id <= 3:
        raise ValueError("round_id must be between 1 and 3")

    round_dir = os.path.join(os.path.abspath(output_dir), f"round_{round_id}")
    if os.path.exists(round_dir):
        # The runner persists its input-state trace before making an API call.
        # That sole file is safe to coexist with a new generation; any other
        # round content remains an explicit no-overwrite error.
        existing_entries = set(os.listdir(round_dir))
        allowed_recovery_entries = {"runner_trace.json", ".log", ".sf_solutions"}
        if not existing_entries.issubset(allowed_recovery_entries):
            raise FileExistsError(f"Round output directory already exists: {round_dir}")
        for artifact in ("patches.json", "generation_manifest.json"):
            artifact_path = os.path.join(round_dir, artifact)
            if os.path.exists(artifact_path):
                raise FileExistsError(f"Round output artifact already exists: {artifact_path}")

    LOG_DIR = os.path.join(round_dir, ".log")
    SOLUTION_DIR = os.path.join(round_dir, ".sf_solutions")
    PATCH_DIR = round_dir
    bug_list = [bug_id]
    metadata_path = dataset_path or os.path.join(REPO_ROOT, "D4J_dataset", "defects4j-v12-sf-255.json")
    with open(metadata_path, "r") as f:
        data = json.load(f)
    state_project = None
    state_trigger_src = None
    state_err_msg = None
    if current_state_code is None:
        if current_failed_tests is not None or current_test_context is not None or joern_project_name is not None or pcsf_feedback is not None:
            raise ValueError("state-aware inputs require current_state_code")
        # Round 1 needs the same live P_t/P0 Joern project as later rounds;
        # otherwise the ReAct analysis tools point at an absent legacy project.
        initial_code = data[bug_id]["buggy_fl"]
        state_project = create_state_project(bug_id, round_id, initial_code, data[bug_id])
        joern_project_name = state_project["project_name"]
        if state_project["state_sha256"] != hashlib.sha256(initial_code.encode("utf-8")).hexdigest():
            raise ValueError("initial_state_project_sha256_mismatch")
    else:
        if current_failed_tests is None or current_test_context is None:
            raise ValueError("state-aware generation requires current_failed_tests and current_test_context")
        if pcsf_feedback is not None and not isinstance(pcsf_feedback, str):
            raise ValueError("pcsf_feedback must be text")
        state_sha256 = hashlib.sha256(current_state_code.encode("utf-8")).hexdigest()
        expected_project_name = state_project_name(bug_id, round_id, current_state_code)
        if joern_project_name is not None and joern_project_name != expected_project_name:
            raise ValueError("joern_project_name_state_mismatch")
        state_trigger_src, state_err_msg = _state_prompt_context(
            current_failed_tests, current_test_context, state_sha256
        )
        state_project = create_state_project(bug_id, round_id, current_state_code, data[bug_id]) if joern_project_name is None else None
        joern_project_name = joern_project_name or state_project["project_name"]
        if state_project is not None and state_project["state_sha256"] != state_sha256:
            raise ValueError("state_project_sha256_mismatch")
    for directory in (LOG_DIR, SOLUTION_DIR, PATCH_DIR):
        os.makedirs(directory, exist_ok=True)
    original_stdout = sys.stdout
    for name in bug_list:
        logger = Logger(os.path.join(LOG_DIR, name + ".log"), sys.stdout)
        sys.stdout = logger
        try:
            i = 1
            current_time = None
            start_time = datetime.now()
            total_cost = 0
            solution_file = os.path.join(SOLUTION_DIR, "solution.json")
            recovered_solution = recover_react_final_answer_from_log(
                os.path.join(LOG_DIR, name + ".log"), solution_file, name
            )
            if recovered_solution is not None:
                logger.info("Recovered existing ReAct final answer from log; skipping ReAct API invocation.")

            # A live Joern process can still become unusable after an OOM.
            # One service restart/re-import is allowed for this generation only.
            joern_restarted = False
            api_connection_attempts = 0
            # Gen solutions
            while recovered_solution is None and i < 2:
                start_time_ite = datetime.now()
                print(f"Generating Solution for: {name}, Round: {round_id}")
                i += 1

                trigger_test_list = list(data[name]['trigger_test'].keys())
                trigger_src_list = []
                err_msg_list = []
                for trigger_test in trigger_test_list:
                    trigger_src_list.append(data[name]['trigger_test'][trigger_test]['src'])
                    err_msg_list.append(data[name]['trigger_test'][trigger_test]['clean_error_msg'])
                # Keep the required failure context within one ReAct request. Large
                # compiler diagnostics are observational detail, not additional tests.
                trigger_src_context = slim_joern_token(str(
                    state_trigger_src if current_state_code is not None else trigger_src_list
                ))
                err_msg_context = slim_joern_token(str(
                    state_err_msg if current_state_code is not None else err_msg_list
                ))
                prompt = prompt_solution_template.partial(
                    buggy_id=joern_project_name,
                    buggy_file_path=data[name]['loc'],
                    buggy_code=current_state_code if current_state_code is not None else data[name]['buggy_fl'],
                    trigger_src=trigger_src_context,
                    err_msg=err_msg_context
                )
                llm = ChatOpenAI(model_name=EXPERIMENT_MODEL, temperature=1, timeout=120)

                agent = create_react_agent(llm, tools, prompt)
                try:
                    agent_executor = AgentExecutor(agent=agent, tools=tools, verbose=True, stream_runnable=False,
                                                   handle_parsing_errors="Check your output and make sure it conforms, use the Action/Action Input syntax. Output the Final Answer always should always required as last step. Exit after output the Final Answer.", )

                    with get_openai_callback() as cb:
                        result = agent_executor.invoke({})
                        logger.info(f"Agent Total tokens: {cb.total_tokens}")
                        logger.info(f"Agent Prompt tokens: {cb.prompt_tokens}")
                        logger.info(f"Agent Completion tokens: {cb.completion_tokens}")
                        logger.info(f"Agent Cost (USD): ${cb.total_cost}")
                        total_cost += cb.total_cost
                    # result = agent_executor.invoke({}, config=config)
                    # logger.info(f"Agent Total tokens: {openai_callback_handler.total_tokens}")
                    # logger.info(f"Agent Prompt tokens: {openai_callback_handler.prompt_tokens}")
                    # logger.info(f"Agent Completion tokens: {openai_callback_handler.completion_tokens}")
                    # logger.info(f"Agent Cost (USD): ${openai_callback_handler.total_cost}")
                    logger.info(result['output'])
                    extract_and_save_final_answer(result['output'], solution_file, name)
                except ValueError as e:
                    # AgentExecutor writes verbose output through Logger. Flush it
                    # before reading the same log for a recoverable final answer.
                    logger.flush()
                    recovered_solution = recover_react_final_answer_from_log(
                        os.path.join(LOG_DIR, name + ".log"), solution_file, name
                    )
                    if recovered_solution is not None:
                        logger.info("Recovered ReAct final answer from parse-failure log; skipping ReAct retry.")
                        break
                    response = str(e)
                    agent_output = ""
                    if "result" in locals() and isinstance(result, dict):
                        agent_output = result.get("output", "")
                    if is_react_iteration_limit(response) or is_react_iteration_limit(agent_output):
                        logger.error("ReAct reached its iteration limit; marking this round generation unavailable.")
                        return {"generation_unavailable": "react_iteration_limit"}
                    if not response.startswith("Could not parse LLM output: `"):
                        raise e
                    response = response.removeprefix("Could not parse LLM output: `").removesuffix("`")
                except openai.APIConnectionError as exc:
                    # A connection failure has no successful generation result and
                    # must not consume a candidate/round budget. Retry once before
                    # leaving the checkpoint resumable for a real outage.
                    api_connection_attempts += 1
                    if api_connection_attempts < 2:
                        delay_seconds = 5
                        logger.error(
                            f"OpenAI connection failed; retrying ReAct once in {delay_seconds}s "
                            f"(attempt {api_connection_attempts + 1}/2)."
                        )
                        time.sleep(delay_seconds)
                        i = 0
                        continue
                    raise RuntimeError("react_api_connection_retry_exhausted") from exc
                except Exception as exc:
                    # Joern can remain alive after a JVM OOM yet reject CPGQLS
                    # messages. Recreate its one-round disposable project once.
                    if type(exc).__name__ not in {"InvalidMessage", "TimeoutError"} or joern_restarted:
                        raise
                    logger.error("Joern CPGQLS connection failed; restarting once and retrying this ReAct pass.")
                    from src.experiment.service_manager import restart_joern_service
                    restart_joern_service()
                    reset_joern_client()
                    if state_project is not None:
                        shutil.rmtree(state_project.get("checkout_root", ""), ignore_errors=True)
                    state_code_for_project = current_state_code if current_state_code is not None else data[name]["buggy_fl"]
                    state_project = create_state_project(bug_id, round_id, state_code_for_project, data[bug_id])
                    joern_project_name = state_project["project_name"]
                    joern_restarted = True
                    i = 0
                    continue
                if current_time:
                    pre_current = current_time
                else:
                    pre_current = start_time
                current_time = datetime.now()
                time_difference = current_time - pre_current
                logger.info(f"Iteration {i - 1} time: {time_difference}")

            current_time = datetime.now()
            time_difference = current_time - start_time
            logger.info(f"Time cost after iteration: {time_difference}")
            if not os.path.isfile(solution_file):
                logger.error("ReAct produced no recoverable final answer; ending this generation without retry.")
                return {"generation_unavailable": "react_no_final_answer"}

            # Gen Patches
            trigger_test_list = list(data[name]['trigger_test'].keys())
            trigger_src_list = []
            err_msg_list = []
            for trigger_test in trigger_test_list:
                trigger_src_list.append(data[name]['trigger_test'][trigger_test]['src'])
                err_msg_list.append(data[name]['trigger_test'][trigger_test]['clean_error_msg'])
            trigger_src_context = slim_joern_token(str(
                state_trigger_src if current_state_code is not None else trigger_src_list
            ))
            err_msg_context = slim_joern_token(str(
                state_err_msg if current_state_code is not None else err_msg_list
            ))
            output_patches_file = os.path.join(PATCH_DIR, "patches.json")
            buggy_code = current_state_code if current_state_code is not None else data[name]['buggy_fl']
            context = ["buggy_id: " + joern_project_name, "\nbuggy_code: " + buggy_code,
                       "\nbuggy_file_path: " + data[name]['loc'], "\ntrigger_src: " + trigger_src_context,
                       "\nerr_msg: " + err_msg_context]
            # Round 2+ may only append the previous round's observational PCSF
            # text to the existing repair input.  It does not alter suggestions,
            # budgets, or current-state failure facts.
            if pcsf_feedback:
                context.append("\nprevious_round_pcsf:\n" + pcsf_feedback)

            with open(solution_file) as f2:
                solutions = json.load(f2)

            append_patches_to_json([], output_patches_file, name)
            generation_manifest = []
            generation_manifest_file = os.path.join(PATCH_DIR, "generation_manifest.json")
            round_raw_sample_count = 0
            round_suggestion_count = 0
            for root_cause in solutions[name].keys():
                for suggestion in solutions[name][root_cause]:
                    if round_suggestion_count >= 3:
                        break
                    round_suggestion_count += 1
                    suggestion_index = round_suggestion_count
                    suggestion_raw_sample_count = 0
                    prompt_patch = f"""You expert Java programmer in generating patches for a given buggy snippet.\n Bug code information(buggy_id, buggy_code, buggy_file_path, trigger_src, err_msg):"+{str(context)}+"\nYour task is to generate ONE unique version of fix for the buggy function code for the pair of root cause and suggestion: Root Cause: {str(root_cause)}\n{str(suggestion)}\n You should look deeply through all the bug information and combine the root cause and repair suggestions to generate correct patches,
        Requirement:
        1. For each root cause and suggestion pair, generate ONE patch.
        2. Each patch should be a complete version of the buggy function code with the fix applied.
        3. Ensure each patch is unique and addresses the identified issue.
        4. When looking at the buggy function code, the location of the bug is indicated by the /* bug is here */ comment.
        5. The fix may involve changes to surrounding lines, not just the commented line itself.

        Return the whole fixed buggy function code, NOT just the line(s) of fixed area. Only output the following content, nothing else. Please format your response as follows:
        [START PATCH 1]
        ```java
        <entire buggy function fixed code here>
        ```
        [END PATCH 1]

                    """

                    try:
                        response = api_gpt_response(prompt_patch, 5)
                        usage = response.usage
                        if usage:
                            input_cost = usage.prompt_tokens * 0.000005
                            output_cost = usage.completion_tokens * 0.00002
                            patch_total_cost = input_cost + output_cost
                            logger.info(f"Patch prompt tokens: {usage.prompt_tokens}")
                            logger.info(f"Patch completion tokens: {usage.completion_tokens}")
                            logger.info(f"Patch total tokens: {usage.total_tokens}")
                            logger.info(f"Patch total cost $: {patch_total_cost}")
                            total_cost += patch_total_cost


                        else:
                            logger.info("No tokens recorded")
                        print("***********Gen Patch***********")
                        print(response)

                        choices = response.choices
                        if len(choices) > 5:
                            raise ValueError(f"Expected at most 5 completions, received {len(choices)}")
                        for completion_index, choice in enumerate(choices, start=1):
                            print("-----------")
                            generated_text = choice.message.content.strip()
                            patch_blocks = parse_patches(generated_text)
                            suggestion_raw_sample_count += 1
                            round_raw_sample_count += 1
                            assert suggestion_raw_sample_count <= 5
                            assert round_raw_sample_count <= 15
                            if not patch_blocks:
                                parse_status = "no_patch_block"
                            elif len(patch_blocks) == 1:
                                parse_status = "ok"
                                append_patches_to_json([patch_blocks[0]], output_patches_file, name)
                                generation_manifest.append({"candidate_index": len(generation_manifest) + 1, "generation_batch": suggestion_index})
                            else:
                                parse_status = "multiple_patch_blocks_first_used"
                                append_patches_to_json([patch_blocks[0]], output_patches_file, name)
                                generation_manifest.append({"candidate_index": len(generation_manifest) + 1, "generation_batch": suggestion_index})
                            logger.info(
                                f"bug_id={bug_id} round_id={round_id} "
                                f"suggestion_index={suggestion_index} completion_index={completion_index} "
                                f"raw_sample_index={round_raw_sample_count} parse_status={parse_status}"
                            )
                    except openai.OpenAIError as e:
                        print(f'OpenAI API error: {e}')
                        break

                if round_suggestion_count >= 3:
                    break

            generated_payload = json.loads(Path(output_patches_file).read_text(encoding="utf-8"))
            generated_patches = generated_payload[name]["patches"]
            write_generation_manifest(
                generation_manifest_file, bug_id, round_id, buggy_code,
                generation_manifest, generated_patches,
            )

            current_time_2 = datetime.now()
            time_difference_ite = current_time_2 - current_time
            logger.info(f"Time cost for generate patch: {time_difference_ite}")

            end_time = datetime.now()
            time_difference = end_time - start_time
            logger.info(f"Time cost for {name}: {time_difference}")
            logger.info(f"Money cost for {name}: {total_cost}")
        finally:
            sys.stdout = original_stdout
            logger.close()
            if state_project is not None:
                try:
                    cleanup_state_project(state_project)
                except Exception as exc:
                    # Cleanup must not turn a recorded generation outcome into an
                    # execution failure; the disposable checkout is still removed
                    # by cleanup_state_project's finally block when possible.
                    print(f"State Joern cleanup failed: {exc}", file=sys.stderr)
                finally:
                    state_project = None
            time.sleep(10)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--bug-id", required=True)
    parser.add_argument("--round-id", required=True, type=int)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--current-state-code-file")
    parser.add_argument("--current-failed-tests-file")
    parser.add_argument("--current-test-context-file")
    parser.add_argument("--joern-project-name")
    args = parser.parse_args()
    state_code = None
    failed_tests = None
    test_context = None
    if args.current_state_code_file:
        with open(args.current_state_code_file, encoding="utf-8") as state_file:
            state_code = state_file.read()
    if args.current_failed_tests_file:
        with open(args.current_failed_tests_file, encoding="utf-8") as failed_file:
            failed_tests = json.load(failed_file)
    if args.current_test_context_file:
        with open(args.current_test_context_file, encoding="utf-8") as context_file:
            test_context = json.load(context_file)
    generate_once(
        args.bug_id, args.round_id, args.output_dir,
        current_state_code=state_code,
        current_failed_tests=failed_tests,
        current_test_context=test_context,
        joern_project_name=args.joern_project_name,
    )
