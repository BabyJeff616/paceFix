import asyncio
import tiktoken
import hashlib
import re
import os
import shutil
import subprocess
import tempfile
import time
from pathlib import Path
from cpgqls_client import CPGQLSClient
import requests
from langchain.tools import StructuredTool
from datetime import datetime

from src.config import JOERN_ADDR

server_endpoint = JOERN_ADDR
client = CPGQLSClient(server_endpoint)
proj_name_gl = ""


def reset_joern_client() -> None:
    """Reconnect after a local Joern restart."""
    global client
    client = CPGQLSClient(server_endpoint)


_JOERN_QUERY_TIMEOUT_SECONDS = 180


def _execute_joern(query: str, timeout_seconds: int = _JOERN_QUERY_TIMEOUT_SECONDS):
    """Run one CPGQLS query with a bounded wall-clock wait."""
    try:
        return client._loop.run_until_complete(
            asyncio.wait_for(client._send_query(query), timeout=timeout_seconds)
        )
    except asyncio.TimeoutError as exc:
        raise TimeoutError(f"joern_query_timeout:{timeout_seconds}s") from exc


def _tool_input(value: str) -> str:
    """Remove optional ReAct quoting before emitting a Scala query."""
    return str(value).strip().strip(chr(34)).strip(chr(39)).strip()


_REACT_CONTROL_TEXT = ("thought:", "action:", "action input:", "observation:", "final answer:")
_JAVA_FILE_NAME = re.compile(r"^[A-Za-z0-9_$.-]+[.]java$")
_SAFE_SYMBOL_NAME = re.compile(r"^(?:[A-Za-z_$][A-Za-z0-9_$.]*|<init>|<operator>[.][A-Za-z0-9_$.]+)$")


def _validated_tool_value(value: str, label: str, pattern: re.Pattern | None = None) -> tuple[str | None, str | None]:
    """Accept one plain ReAct argument, never arbitrary Scala/source text."""
    raw = _tool_input(value)
    lower = raw.lower()
    if not raw or chr(10) in raw or chr(13) in raw or any(marker in lower for marker in _REACT_CONTROL_TEXT):
        return None, f"invalid tool input: {label} must be one plain value; please retry the tool call."
    if pattern is not None and not pattern.fullmatch(raw):
        return None, f"invalid tool input: {label} has an unsupported format ({raw!r}); please retry the tool call."
    return raw, None


def _parse_method_and_file(value: str) -> tuple[str, str] | str:
    """Parse a ReAct method/file argument without aborting the generation run."""
    raw, error = _validated_tool_value(value, "method_name, FileName.java")
    if error is not None:
        return error
    if "," not in raw:
        return (
            "invalid tool input: expected 'method_name, FileName.java'; "
            f"received {raw!r}. Please retry this tool with both values."
        )
    method_name, file_name = (part.strip() for part in raw.split(",", 1))
    if not method_name or not file_name:
        return (
            "invalid tool input: both method name and file name are required; "
            f"received {raw!r}. Please retry this tool with both values."
        )
    if not _JAVA_FILE_NAME.fullmatch(file_name):
        return (
            "invalid tool input: file name must be a plain '*.java' basename; "
            f"received {file_name!r}. Please retry the tool call."
        )
    return method_name, file_name

# ReAct observations must remain bounded: Joern/RAG queries can return whole-project
# data, which is not valid input for a single model context. This only limits the
# text returned to the generation agent; it does not change any query or experiment
# selection rule.
_MAX_TOOL_OBSERVATION_TOKENS = 3000

def _bounded_tool_observation(value, token_upper_limit: int = _MAX_TOOL_OBSERVATION_TOKENS) -> str:
    text = value if isinstance(value, str) else str(value)
    encoding = tiktoken.get_encoding("cl100k_base")
    tokens = encoding.encode(text)
    if len(tokens) <= token_upper_limit:
        return text
    prefix = encoding.decode(tokens[:token_upper_limit])
    return prefix + "\n[tool observation truncated to %d tokens]\n" % token_upper_limit


D4J = "/home/reinfix/defects4j-2.0.0/framework/bin/defects4j"
JAVA8 = "/usr/lib/jvm/java-8-openjdk-amd64"

def state_project_name(bug_id: str, round_id: int, current_state_code: str) -> str:
    digest = hashlib.sha256(current_state_code.encode("utf-8")).hexdigest()
    return f"{bug_id}_round_{round_id}_{digest[:12]}"

_STATE_PROJECT_NAME = re.compile(r"([A-Za-z]+-\d+_round_[1-3]_[0-9a-f]{12})")
_WORKSPACE_ROOT = Path(__file__).resolve().parents[2] / "workspace"


def _state_workspace_names() -> set[str]:
    if not _WORKSPACE_ROOT.is_dir():
        return set()
    return {
        path.name for path in _WORKSPACE_ROOT.iterdir()
        if path.is_dir() and _STATE_PROJECT_NAME.fullmatch(path.name)
    }


def _remove_state_workspace_dirs(names: set[str]) -> None:
    for name in names:
        path = _WORKSPACE_ROOT / name
        if path.is_dir():
            shutil.rmtree(path, ignore_errors=True)


def _state_project_input(value: str) -> str | None:
    """Accept only the formal state-project identifier used by this runner."""
    name = _tool_input(value)
    return name if _STATE_PROJECT_NAME.fullmatch(name) else None


def remove_orphaned_state_projects() -> None:
    """Discard CPGs left by an interrupted earlier formal generation.

    Formal batch execution is sequential, so a new state project has no live
    predecessor. Keeping stale CPGs only accumulates Joern heap usage.
    """
    names = _state_workspace_names()
    for attempt in range(2):
        try:
            response = _execute_joern("workspace")
            stdout = response.get("stdout", "") if isinstance(response, dict) else ""
            names.update(_STATE_PROJECT_NAME.findall(str(stdout)))
            for name in sorted(names):
                try:
                    _execute_joern(f'close("{name}")')
                finally:
                    _execute_joern(f'delete("{name}")')
            _remove_state_workspace_dirs(names)
            return
        except Exception:
            _remove_state_workspace_dirs(names)
            if attempt:
                raise
            from src.experiment.service_manager import restart_joern_service
            restart_joern_service()
            reset_joern_client()

def create_state_project(bug_id: str, round_id: int, current_state_code: str, bug_info: dict) -> dict:
    """Create a disposable full-project CPG for one P_t; caller must clean it."""
    project, bug_number = bug_id.split("-", 1)
    project_name = state_project_name(bug_id, round_id, current_state_code)
    env = dict(os.environ, JAVA_HOME=JAVA8, PATH=JAVA8 + "/bin:" + os.environ.get("PATH", ""))

    # Importing a large project can be the first operation to expose a live but
    # exhausted Joern JVM. Recover it once here, before ReAct starts.
    for attempt in range(2):
        remove_orphaned_state_projects()
        root = Path(tempfile.mkdtemp(prefix="pacefix_state_joern_"))
        checkout = root / bug_id
        result = subprocess.run(
            [D4J, "checkout", "-p", project, "-v", bug_number + "b", "-w", str(checkout)],
            env=env, text=True, capture_output=True, check=False,
        )
        if result.returncode != 0:
            shutil.rmtree(root, ignore_errors=True)
            raise RuntimeError("state_checkout_failed: " + result.stderr.strip())
        target = checkout / str(bug_info["loc"])
        try:
            source, encoding = target.read_text(encoding="utf-8"), "utf-8"
        except UnicodeDecodeError:
            source, encoding = target.read_text(encoding="ISO-8859-1"), "ISO-8859-1"
        lines = source.splitlines(keepends=True)
        lines[int(bug_info["start"]) - 1:int(bug_info["end"])] = [current_state_code.strip() + "\n"]
        target.write_text("".join(lines), encoding=encoding)
        import_started = time.monotonic()
        try:
            imported = _execute_joern(f'importCode(inputPath="{checkout}", projectName="{project_name}")')
        except Exception as exc:
            shutil.rmtree(root, ignore_errors=True)
            if attempt or type(exc).__name__ not in {"TimeoutError", "InvalidMessage"}:
                raise
            from src.experiment.service_manager import restart_joern_service
            restart_joern_service()
            reset_joern_client()
            continue
        if not isinstance(imported, dict):
            shutil.rmtree(root, ignore_errors=True)
            raise RuntimeError("state_project_import_failed")
        return {
            "project_name": project_name,
            "state_sha256": hashlib.sha256(current_state_code.encode("utf-8")).hexdigest(),
            "checkout_root": str(root),
            "import_seconds": time.monotonic() - import_started,
        }
    raise RuntimeError("state_project_import_recovery_exhausted")

def cleanup_state_project(state_project: dict) -> None:
    project_name = state_project.get("project_name")
    try:
        if project_name:
            try:
                _execute_joern(f'close("{project_name}")')
            finally:
                _execute_joern(f'delete("{project_name}")')
    finally:
        shutil.rmtree(state_project.get("checkout_root", ""), ignore_errors=True)

def open_proj(proj_name: str) -> str:
    """
    Open the current analysing project by proj_name.

    @param proj_name: The name of project to open. "
    @return: The result of the request execution.

    """

    if not proj_name.endswith("\n"):
        print(proj_name)
    proj_name = _state_project_input(proj_name)
    if proj_name is None:
        return "invalid_state_project_name; open skipped"
    query = f'open("{proj_name}")'
    print(query)
    result = _execute_joern(query)
    global proj_name_gl
    proj_name_gl = proj_name
    return _bounded_tool_observation(result['stdout'])


def identify_variable(input_string: str) -> str:
    """
    Identifies variable definitions and usages for a given variable name.

    @param input_string: A string containing both the variable name and file name,
                         separated by a comma. Format: variable_name, file_name
    @return: The result of the query execution.
    """
    parsed = _parse_method_and_file(input_string)
    if isinstance(parsed, str):
        return parsed
    variable_name, file_name = parsed
    query = f'cpg.identifier.name("{variable_name}").filter(_.location.filename.matches(".*{file_name}.*")).map(n=>List(n.code, n.typeFullName, n.start.dump)).take(3).l'
    print(query)
    result = _execute_joern(query)
    return _bounded_tool_observation(result['stdout'])


def trace_method_usage(method_name: str) -> str:
    """
    Traces the usage of a specific method in the code.

    @param method_name: The name of the method to trace.
    @return: The result of the query execution.
    """
    method_name, error = _validated_tool_value(method_name, "method name", _SAFE_SYMBOL_NAME)
    if error is not None:
        return error
    query = f'cpg.call.name("{method_name}").map(n=>List(n.code, n.methodFullName)).l'
    print(query)
    result = _execute_joern(query)
    return slim_joern_token(result['stdout'])


def find_method_in_file(input_string: str) -> str:
    """
    Finds a specific method within a given file and retrieves its location and the whole method code. DO NOT Add any quota marks(") to the input parameter because the tool call will process it.

    @param input_string: A string containing both the method name and file name, separated by a comma. method_name: The name of the method to find. file_name: The name of the file to search within (only the file name, not the file path). Format: method_name, file_name.
    @return: The result of the query execution.

    input_string Example: visit, CheckSideEffects.java
    """
    parsed = _parse_method_and_file(input_string)
    if isinstance(parsed, str):
        return parsed
    method_name, file_name = parsed
    query = (
        f'cpg.method.name("{method_name}")'
        f'.filter(_.location.filename.matches(".*{file_name}"))'
        f'.map(m => (m.location.filename, m.start.dump))'
        f'.l'
    )
    print(query)
    result = _execute_joern(query)
    return _bounded_tool_observation(result['stdout'])


def analyze_method_details(input_string: str) -> str:
    """
    Identifies various aspects of a given method in a file. DO NOT Add any quota marks(") to the input parameter because the tool call will process it.

    @param input_string: A string containing both the method name and file name, separated by a comma. method_name: The name of the method to find. file_name: The name of the file to search within (only the file name, not the file path). Format: method_name, file_name. Example: visit, CheckSideEffects.java

    @return: The result of the query execution, including:
        - Method name and parameter types
        - Filename where the method is located
        - All throw statements within the method
        - All if statement conditions within the method
        - All method calls within the method
        - All variable assignments within the method
        - The return statement of the method
    """
    parsed = _parse_method_and_file(input_string)
    if isinstance(parsed, str):
        return parsed
    method_name, file_name = parsed
    query = f"""
    cpg.method("{method_name}").filter(_.location.filename.matches(".*{file_name}")).map{{ method =>
      (
        method.name,
        method.parameter.map(_.typeFullName).mkString(", "),
        method.location.filename,
        method.ast.isCall.name("throw.*").code.l,
        method.ast.isControlStructure.isIf.condition.code.l,
        method.ast.isCall.name.l,
        method.ast.isCall.name("<operator>.assignment").code.l,
        method.ast.isReturn.code.l
      )
    }}.l
    """
    print(query)
    result = _execute_joern(query)
    return _bounded_tool_observation(result['stdout'])

def find_class_loc(input_string: str) -> str:
    """
    Finds the location of a class with a given name.

    @param input_string: The name of the class to locate
    @return: A string containing the location/full type name of the class
    """
    class_name, error = _validated_tool_value(input_string, "class name", _SAFE_SYMBOL_NAME)
    if error is not None:
        return error

    query = (
        f'cpg.identifier.name("{class_name}").typeFullName.take(1).l'
    )
    print(query)
    result = _execute_joern(query)
    return _bounded_tool_observation(result['stdout'])

def identify_class(input_string: str) -> str:
    """
    Identifies the class code matches the given search string for a class name.

    @param input_string: The name of the class
    @return: A string containing the class codes
    """

    class_name, error = _validated_tool_value(input_string, "class name", _SAFE_SYMBOL_NAME)
    if error is not None:
        return error

    query = (
        f'cpg.typeDecl.fullName(".*{class_name}.*").astChildren.code.dedup.l'
    )
    print(query)
    result = _execute_joern(query)
    return _bounded_tool_observation(result['stdout'])



def analyze_method_control_flow(method_name: str) -> str:
    """
    Analyzes the control flow (if, while, for, etc.) structures within a specific method.

    @param method_name: The name of the method to analyze.
    @return: The code of the control flow structures within the method.
    """
    method_name, error = _validated_tool_value(method_name, "method name", _SAFE_SYMBOL_NAME)
    if error is not None:
        return error
    query = f'cpg.method.name("{method_name}").ast.isControlStructure.code.l'
    print(query)
    result = _execute_joern(query)
    return _bounded_tool_observation(result['stdout'])


def get_imports(file_name: str) -> str:
    """
    Retrieves all import statements from a specific file.

    @param file_name: The name of the file to search within (only the file name, not the file path).
    @return: The code of all import statements within the file.
    """
    file_name, error = _validated_tool_value(file_name, "Java file name", _JAVA_FILE_NAME)
    if error is not None:
        return error
    query = (
        f'cpg.imports'
        f'.filter(_.location.filename.matches(".*{file_name}"))'
        f'.map(m => (m.code))'
        f'.l'
    )
    print(query)
    result = _execute_joern(query)
    return _bounded_tool_observation(result['stdout'])

def close_proj(proj_name: str) -> str:
    """
    Close the current analysing project by proj_name.

    @param proj_name: The name of project to close. Example format: "Chart-1_buggy"
    @return: The result of the request execution.

    Example: close_proj("Chart-1_buggy")
    """
    proj_name = _state_project_input(proj_name)
    if proj_name is None:
        return "invalid_state_project_name; close skipped"
    print(proj_name)

    query = f'close("{proj_name}")'
    print(query)
    result = _execute_joern(query)
    return _bounded_tool_observation(result['stdout'])


def example_patch_search(input_string: str) -> str:
    """
    Search for the most similar (by similarity rate) fix pattern example in a Knowledge Base and return it.

    @param input_string: Buggy code concatenate with Root cause. input example:  public boolean equals(Object obj) \n\n    if (obj == this) \n   return true, Root Cause: The `equals` method in the `ShapeList` class is calling `super.equals(obj)` which likely only checks the reference equality or fields defined in the superclass, rather than checking the properties specific to `ShapeList`. This would lead to instances that may contain the same shapes being considered unequal if the parent class does not override `equals` appropriately for deep equality checks.
    @return: The most similar fix pattern, including BuggyCode, FixedCode, RootCause

    """
    url = "http://localhost:5000/search"
    data = {
        "query": input_string,
        "n": 1,
        "threshold": 0.6
    }
    start_time = datetime.now()
    try:
        response = requests.post(url, json=data, timeout=30)
        response.raise_for_status()
        payload = response.json()
    except requests.RequestException as exc:
        print(f"Example retrieval unavailable: {exc}")
        payload = {"status": "unavailable", "reason": "example_retrieval_unavailable"}
    end_time = datetime.now()
    time_difference = end_time - start_time
    print(f"Time cost for retrieving: {time_difference}")
    try:
        close_proj(proj_name=proj_name_gl)
    except Exception as exc:
        print(f"Project close after example retrieval failed: {exc}")
    if "'similarity'" in str(payload):
        print("example found")
        with open("/home/reinfix/ReInFix/src/experiment/output/searched_example.txt", "a", encoding="utf-8") as f:
            f.write(proj_name_gl + "\n")

    return _bounded_tool_observation(payload)

def slim_joern_token(joern_response):
    return _bounded_tool_observation(joern_response)


def num_tokens_from_string(string: str) -> int:
    encoding_name = "cl100k_base"
    encoding = tiktoken.get_encoding(encoding_name)
    num_tokens = len(encoding.encode(string))
    return num_tokens


# Define the tools
open_proj_tool = StructuredTool.from_function(open_proj)
identify_variable_tool = StructuredTool.from_function(identify_variable)
trace_method_usage_tool = StructuredTool.from_function(trace_method_usage)
find_method_in_file_tool = StructuredTool.from_function(find_method_in_file)
analyze_method_details_tool = StructuredTool.from_function(analyze_method_details)
analyze_method_control_flow_tool = StructuredTool.from_function(analyze_method_control_flow)
find_class_loc_tool = StructuredTool.from_function(find_class_loc)
identify_class_tool = StructuredTool.from_function(identify_class)
get_imports_tool = StructuredTool.from_function(get_imports)
close_proj_tool = StructuredTool.from_function(close_proj)
example_patch_search_tool = StructuredTool.from_function(example_patch_search)


