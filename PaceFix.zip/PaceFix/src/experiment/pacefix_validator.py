import os
import hashlib
import sys
import time
import json
import shutil
import random
import psutil
import argparse
import threading
import traceback
import subprocess
import multiprocessing
from pathlib import Path
import concurrent.futures as cf
from contextlib import contextmanager, redirect_stdout, redirect_stderr



def clean_tmp_folder(tmp_dir):
    if os.path.isdir(tmp_dir) and tmp_dir.startswith('/tmp/'):
        shutil.rmtree(tmp_dir)
    os.makedirs(tmp_dir)


def strip_lines(lines):
    return [line.strip() for line in lines]


def encoding_check(encoding_check_file_path):
    file_content = None
    encoding_mode = 'utf-8'
    try:
        with open(encoding_check_file_path, 'r', encoding=encoding_mode) as f:
            file_content = f.read()
    except UnicodeDecodeError:
        encoding_mode = 'ISO-8859-1'
        with open(encoding_check_file_path, 'r', encoding=encoding_mode) as f:
            file_content = f.read()
    except Exception as e:
        print(f"[ERROR] read encoding_check FAILURE: {e}")
        return None
    return encoding_mode, file_content


DEFECTS4J = "/home/reinfix/defects4j-2.0.0/framework/bin/defects4j"
JAVA8 = "/usr/lib/jvm/java-8-openjdk-amd64"


def defects4j_environment():
    env = dict(os.environ)
    env["JAVA_HOME"] = JAVA8
    env["PATH"] = JAVA8 + "/bin:" + os.path.dirname(DEFECTS4J) + ":" + env.get("PATH", "")
    return env


def checkout_defects4j_project(current_bug, project_dir, timeout=300):
    """Create one clean validation checkout with a bounded external wait."""
    project, bug_id = current_bug.split('-')
    command = [DEFECTS4J, "checkout", "-p", project, "-v", bug_id + "b", "-w", project_dir]
    print('[CHECKOUT]', " ".join(command), flush=True)
    start = time.monotonic()
    out, err = command_with_timeout(command, timeout, defects4j_environment())
    status = command_status(out, err)
    if status == 'TIMEOUT':
        raise RuntimeError(f"defects4j_checkout_timeout:{current_bug}:{timeout}s")
    if status != 'PASS':
        detail = str(err).strip() or str(out).strip()
        raise RuntimeError(f"defects4j_checkout_failed:{current_bug}: {detail}")
    print(f'[CHECKOUT] completed {current_bug} in {time.monotonic() - start:.1f}s', flush=True)


def monitor_memory(pid, interval, stop_event, max_memory_event):
    max_memory = 0
    try:
        main_proc = psutil.Process(pid)
        while not stop_event.is_set():
            procs = [main_proc] + main_proc.children(recursive=True)
            total_memory_usage = sum(proc.memory_info().rss for proc in procs if proc.is_running())
            max_memory = max(max_memory, total_memory_usage)
            time.sleep(interval)
    except psutil.NoSuchProcess:
        pass
    max_memory_event[0] = max_memory / (1024 ** 3)


def command_with_timeout(cmd, timeout=90, env=None):
    max_memory_event = [None]
    process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, env=env)
    stop_event = threading.Event()
    monitor_thread = threading.Thread(target=monitor_memory, args=(process.pid, 1, stop_event, max_memory_event))
    try:
        monitor_thread.start()
        stdout, stderr = process.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        ps_process = psutil.Process(process.pid)
        procs_kill = [ps_process] + ps_process.children(recursive=True)
        for proc in procs_kill:
            proc.kill()
        return 'TIMEOUT', 'TIMEOUT'
    finally:
        stop_event.set()
        monitor_thread.join()
        max_memory_usage = max_memory_event[0]
        if max_memory_usage and max_memory_usage > 6:
            print(f'[WARNING] MEMORY OCCUPIED {max_memory_usage:.2f} GB -- {cmd}')
    return stdout, stderr


def defects4j_test_suite(project_dir, timeout=1000):
    os.chdir(project_dir)
    out, err = command_with_timeout([DEFECTS4J, "test", "-r"], timeout, defects4j_environment())
    if "Compilation failed" in str(out):
        print("[FAIL] Compile tests for ", project_dir)
    return out, err


def defects4j_export_trigger(project_dir, timeout=90):
    os.chdir(project_dir)
    out, err = command_with_timeout([DEFECTS4J, "export", "-p", "tests.trigger"], timeout, defects4j_environment())
    return out, err


def defects4j_export_relevant(project_dir, timeout=90):
    original_dir = os.getcwd()
    try:
        os.chdir(project_dir)
        return command_with_timeout(
            [DEFECTS4J, "export", "-p", "tests.relevant"], timeout, defects4j_environment()
        )
    finally:
        os.chdir(original_dir)


def defects4j_test_one(project_dir, test_case, timeout=100):
    print(f'[VALIDATOR] current-failed-test {test_case}', flush=True)
    os.chdir(project_dir)
    out, err = command_with_timeout([DEFECTS4J, "test", "-t", test_case], timeout, defects4j_environment())
    return out, err


def defects4j_compile(project_dir, timeout=1000):
    os.chdir(project_dir)
    return command_with_timeout([DEFECTS4J, "compile"], timeout, defects4j_environment())


def defects4j_test_full_suite(project_dir, timeout=1000):
    print('[VALIDATOR] full test suite', flush=True)
    os.chdir(project_dir)
    return command_with_timeout([DEFECTS4J, "test"], timeout, defects4j_environment())


def command_status(out, err):
    text = f"{out}\n{err}"
    if 'TIMEOUT' in text:
        return 'TIMEOUT'
    if 'Compilation failed' in text or 'BUILD FAILED' in text:
        return 'FAIL'
    if 'Failing tests: 0' in text:
        return 'PASS'
    if 'FAIL' in text or 'Failing tests:' in text:
        return 'FAIL'
    return 'PASS'


def parse_failing_tests(out):
    return [test_case.strip() for test_case in str(out).split(' - ')[1:] if test_case.strip()]


def test_result(out, err):
    status = command_status(out, err)
    if status == 'PASS' and 'Failing tests: 0' not in str(out):
        status = 'ERROR'
    return {
        'status': status,
        'failure_info': str(err).strip() or str(out).strip(),
    }


def read_test_source(proj_dir, test_id):
    test_class = test_id.split('::', 1)[0].rsplit('.', 1)[-1] + '.java'
    matches = list(Path(proj_dir).rglob(test_class))
    if len(matches) != 1:
        return None
    try:
        return matches[0].read_text(encoding='utf-8')
    except UnicodeDecodeError:
        return matches[0].read_text(encoding='ISO-8859-1')


def next_state_from_existing_results(patch_code, full_suite_ran, full_suite_status,
                                     full_suite_failing_tests, ft_test_results, proj_dir):
    """Serialize P_(t+1) facts from this candidate's already-run tests only."""
    if not full_suite_ran:
        return {'next_state_sha256': None, 'next_failed_tests': None,
                'next_test_context': None, 'next_state_status': 'unavailable',
                'next_state_reason': 'full_suite_not_run'}
    if full_suite_status not in ('PASS', 'FAIL'):
        return {'next_state_sha256': None, 'next_failed_tests': None,
                'next_test_context': None, 'next_state_status': 'unavailable',
                'next_state_reason': 'full_suite_result_unavailable'}
    state_hash = hashlib.sha256(patch_code.encode('utf-8')).hexdigest()
    next_failed_tests = list(full_suite_failing_tests)
    context = []
    for test_id in next_failed_tests:
        result = ft_test_results.get(test_id)
        if not isinstance(result, dict) or not isinstance(result.get('failure_info'), str):
            return {'next_state_sha256': state_hash, 'next_failed_tests': next_failed_tests,
                    'next_test_context': None, 'next_state_status': 'unavailable',
                    'next_state_reason': 'next_failed_test_missing_ft_result:' + str(test_id)}
        context.append({'test_id': test_id, 'failure_info': result['failure_info'],
                        'test_source': read_test_source(proj_dir, test_id),
                        'current_state_sha256': state_hash})
    return {'next_state_sha256': state_hash, 'next_failed_tests': next_failed_tests,
            'next_test_context': context, 'next_state_status': 'available',
            'next_state_reason': None}


def extract_d4j_result(err, out, val_stage):
    err_str, out_str = str(err), str(out)
    if 'TIMEOUT' in err_str or 'TIMEOUT' in out_str:
        correctness = 'TRIGGER_TIMEOUT' if val_stage == 'trigger' else 'RELEVANT_TIMEOUT'
    elif 'FAIL' in err_str or 'FAIL' in out_str:
        correctness = 'UNCOMPILABLE'
    elif "Failing tests: 0" in out_str:
        correctness = 'PLAUSIBLE'
    else:
        correctness = 'TRIGGER_ERROR' if val_stage == 'trigger' else 'RELEVANT_ERROR'
    return correctness




class ValTime:
    def __init__(self, val_start_time):
        self.val_start_timestamp = val_start_time
        
        self.val_init_time = 0
        self.val_overall_time = 0

        self.val_trigger_time = 0
        self.curr_trigger_time = 0
        self.trigger_start_timestamp = 0

        self.val_relevant_time = 0
        self.curr_relevant_time = 0
        self.relevant_start_timestamp = 0

        self.curr_overall_time = 0

    def set_init_time(self, init_timestamp):
        self.val_init_time = init_timestamp - self.val_start_timestamp

    def set_trigger_start_timestamp(self, trigger_start_timestamp):
        self.trigger_start_timestamp = trigger_start_timestamp
    
    def set_relevant_start_timestamp(self, relevant_start_timestamp):
        self.relevant_start_timestamp = relevant_start_timestamp

    def set_trigger_end_time(self, trigger_end_timestamp):
        self.curr_trigger_time = trigger_end_timestamp - self.trigger_start_timestamp
        self.val_trigger_time += self.curr_trigger_time
    
    def set_relevant_end_time(self, relevant_end_timestamp):
        self.curr_relevant_time = relevant_end_timestamp - self.relevant_start_timestamp
        self.val_relevant_time += self.curr_relevant_time
    
    def get_curr_overall_time(self):
        self.curr_overall_time = self.curr_trigger_time + self.curr_relevant_time
        return int(self.curr_overall_time)
    
    def set_overall_time(self, end_timestamp):
        self.val_overall_time = end_timestamp - self.val_start_timestamp
    
    def get_relevant_time(self):
        return int()
    
    def print_validation_time_info(self, curr_bug):
        print(f"[TIME INFO] PREPARE  = {int(self.val_init_time)}s")
        print(f"[TIME INFO] TRIGGER  = {int(self.val_trigger_time)}s")
        if self.val_relevant_time > 2:
            print(f"[TIME INFO] RELEVANT = {int(self.val_relevant_time)}s")
        print(f'[TIME INFO] TOTAL {curr_bug} -- {int(int(self.val_overall_time))}s')
        print('=' * 100)




class ValInfo():
    def __init__(self, candidate_patch):
        self.unvrf_patches = candidate_patch
        self.curr_bug = candidate_patch[0]
        self.input_info = candidate_patch[1]
        self.patches = self.input_info['patches']
        self.round_id = self.input_info.get('round_id', 1)
        self.current_state_code = self.input_info.get('current_state_code')
        self.expected_current_failed_tests = self.input_info.get('current_failed_tests')
        self.expected_current_test_context = self.input_info.get('current_test_context')
        self.patch_id = 0
        self.validated_result = []
        self.init_buggy_project()
        self.init_extract_project_info()
        self.init_bug_status_info()

    def init_buggy_project(self):
        self.validation_path = '/tmp/llm4apr_validation/'
        self.proj_dir = os.path.join(self.validation_path, self.curr_bug)
        clean_tmp_folder(self.proj_dir)
        with open(os.path.join(self.validation_path, 'config.json'), 'r') as f:
            config_info = json.load(f)
        self.val_result_path = config_info['output_path']
        with open(config_info['dataset_path'], 'r') as f:
            self.dataset = json.load(f)
        self.bug_info = self.dataset[self.curr_bug]
        checkout_defects4j_project(self.curr_bug, self.proj_dir)

    def init_extract_project_info(self):
        bug_path = self.dataset[self.curr_bug]['loc']
        self.buggy_file_path = os.path.join(self.proj_dir, bug_path)
        self.encoding_mode, self.original_buggy_file_content = encoding_check(self.buggy_file_path)
        self.backup_buggy_file_path = f'{self.buggy_file_path}.llm4apr_backup'
        shutil.copyfile(self.buggy_file_path, self.backup_buggy_file_path)

    def restore_p0_source(self):
        shutil.copyfile(self.backup_buggy_file_path, self.buggy_file_path)

    def init_bug_status_info(self):
        self.restore_p0_source()
        # buggy_fl is repair-context text, not necessarily a byte-for-byte
        # copy of the checkout source. When P_t is still P0, do not rewrite it.
        if (self.current_state_code is not None
                and self.current_state_code != self.bug_info["buggy_fl"]):
            PatchValidation(self.current_state_code).apply_patch(
                self.dataset[self.curr_bug], self.proj_dir, self.encoding_mode
            )
        compile_out, compile_err = defects4j_compile(self.proj_dir)
        self.current_compile_status = command_status(compile_out, compile_err)
        self.current_suite_status = 'NOT_RUN'
        self.failed_test_cases = []
        self.current_test_context = []
        state_code = self.current_state_code if self.current_state_code is not None else self.bug_info['buggy_fl']
        self.current_state_sha256 = hashlib.sha256(state_code.encode('utf-8')).hexdigest()
        if self.current_compile_status == 'PASS':
            suite_out, suite_err = defects4j_test_full_suite(self.proj_dir)
            self.current_suite_status = command_status(suite_out, suite_err)
            if self.current_suite_status in ('PASS', 'FAIL'):
                self.failed_test_cases = parse_failing_tests(suite_out)
                failure_info = str(suite_err).strip() or str(suite_out).strip()
                for test_id in self.failed_test_cases:
                    test_class = test_id.split('::', 1)[0].rsplit('.', 1)[-1] + '.java'
                    matches = list(Path(self.proj_dir).rglob(test_class))
                    source = None
                    if len(matches) == 1:
                        try:
                            source = matches[0].read_text(encoding='utf-8')
                        except UnicodeDecodeError:
                            source = matches[0].read_text(encoding='ISO-8859-1')
                    self.current_test_context.append({'test_id': test_id, 'failure_info': failure_info, 'test_source': source, 'current_state_sha256': self.current_state_sha256})
        self.restore_p0_source()
        self.observed_failed_test_cases = list(self.failed_test_cases)
        if self.expected_current_failed_tests is not None:
            expected = self.expected_current_failed_tests
            context = self.expected_current_test_context
            if (not isinstance(expected, list) or not all(isinstance(item, str) for item in expected)
                    or not isinstance(context, list)):
                raise RuntimeError("validator_expected_current_state_invalid")
            by_test = {
                item.get("test_id"): item for item in context
                if isinstance(item, dict) and isinstance(item.get("test_id"), str)
            }
            if set(by_test) != set(expected):
                raise RuntimeError("validator_expected_test_context_mismatch")
            self.failed_test_cases = list(expected)
            self.current_test_context = [by_test[test_id] for test_id in self.failed_test_cases]

    def check_init_success(self):
        return self.current_compile_status == 'PASS' and len(self.failed_test_cases) > 0

    def patch_id_counter(self):
        self.patch_id += 1

    def update_patch_val_result(self, patch_validation_info):
        self.validated_result.append(patch_validation_info)

    def save_validation_results(self, done=False):
        if not done and len(self.validated_result) % 10 != 0:
            return
        filename = str(self.curr_bug) + '-validated.jsonl'
        log_file = os.path.join(self.val_result_path, filename)
        os.makedirs(self.val_result_path, exist_ok=True)
        with open(log_file, 'w') as f:
            json.dump(self.validated_result, f, indent=2)


class PatchValidation():
    def __init__(self, patch_code):
        self.patch_code = patch_code
        self.patch_status = 'UNVERIFIED'
        self.failing_test = {
            'TRIGGER' : [],
            'RELEVANT' : [],
            'TIMEOUT' : [],
        }
        self.patch_val_info = {}

    def apply_patch(self, bug_info, proj_dir, encoding_mode):
        bug_path = bug_info['loc']
        start_loc = bug_info['start']
        end_loc = bug_info['end']
        patch = self.patch_code.strip()
        buggy_full_path = os.path.join(proj_dir, bug_path)        
        with open(buggy_full_path, 'r', encoding=encoding_mode) as file:
            orig_buggy_code = file.readlines()
        with open(buggy_full_path, 'w', encoding=encoding_mode, errors='ignore') as file:
            patched = False
            for idx, line in enumerate(orig_buggy_code):
                if start_loc - 1 <= idx <= end_loc -1:
                    if not patched:
                        file.write(patch)
                        patched = True
                else:
                    file.write(line)
            assert patched, f'[ERROR] [ASSERT FAILURE] insert_fix_into_src not pateced'
        return

    
    def trigger_test_validation(self, trigger_tests, proj_dir):
        for trigger in trigger_tests:
            if self.patch_status == 'UNVERIFIED' or self.patch_status == 'PLAUSIBLE':
                out, err = defects4j_test_one(proj_dir, trigger)
                self.patch_status = extract_d4j_result(err, out, 'trigger')
                if self.patch_status == 'TRIGGER_ERROR': 
                    self.failing_test['TRIGGER'].append(trigger)
                elif self.patch_status == 'TRIGGER_TIMEOUT':
                    self.failing_test['TIMEOUT'].append(trigger)


    def relevant_test_validation(self, proj_dir):
        if self.patch_status != 'PLAUSIBLE':
            return
        out, err = defects4j_test_suite(proj_dir)
        self.patch_status = extract_d4j_result(err, out, 'relevant')
        self.failing_test['RELEVANT'] = [test_case.strip() for test_case in str(out).split(' - ')[1:]]
    
    
    def print_curr_patch_status(self, curr_bug, curr_overall_time):
        print(f'[PATCH STATUS] | {curr_bug:20} | {self.patch_status:16} | {curr_overall_time:4}s  |')
        
        
    def recover_buggy_file(self, backup_buggy_file_path, orig_file_content, patch_id, encoding_mode, proj_dir):
        if '.llm4apr_backup' not in backup_buggy_file_path:
            print(f'[ERROR] .llm4apr_backup not in backup_file')
            return
        recover_buggy_path = backup_buggy_file_path.replace('.llm4apr_backup', '')
        patched_backup_file_path = f'{recover_buggy_path}_{patch_id}_{self.patch_status}'
        shutil.move(recover_buggy_path, patched_backup_file_path)
        shutil.copyfile(backup_buggy_file_path, recover_buggy_path)
        with open(recover_buggy_path, 'r', encoding=encoding_mode) as f:
            file_content = f.read()
            assert orig_file_content == file_content, f'[ERROR] [ASSERT FAILURE] recover_original_file'
        
        # fix the bug of defects4j project's incremental compilation error in trigger test
        assert proj_dir.startswith('/tmp/llm4apr_validation/'), f'[ERROR] [ASSERT FAILURE] \
                recover_buggy_file FAILURE {proj_dir} NOT TEMP FILE'
        rm_class_filename = os.path.basename(recover_buggy_path).replace('.java', '.class')
        root_dir = Path(proj_dir)
        for file in root_dir.rglob(rm_class_filename):
            file.unlink()
            return

    def summarize_patch_info(self, bug_name):
        self.patch_val_info = {
            'patch_code': self.patch_code, 
            'patch_status': self.patch_status, 
            'failing_tests': self.failing_test,
            'val_cnt' : 1,
            'bug_name' : bug_name
        }
        return self.patch_val_info
        



def validate_patches_per_bug(candidate_patch):
    val_info = ValInfo(candidate_patch)
    if not val_info.check_init_success():
        raise RuntimeError(
            "validator_current_state_unavailable:"
            f"compile={val_info.current_compile_status},"
            f"suite={val_info.current_suite_status},"
            f"failed_tests={len(val_info.failed_test_cases)}"
        )

    plausible_patches = []
    candidate_total = len(val_info.patches)
    for curr_patch_code in val_info.patches:
        val_info.patch_id_counter()
        print(f'[VALIDATOR] candidate {val_info.patch_id}/{candidate_total}', flush=True)
        val_info.restore_p0_source()
        PatchValidation(curr_patch_code).apply_patch(
            val_info.dataset[val_info.curr_bug], val_info.proj_dir, val_info.encoding_mode
        )

        compile_out, compile_err = defects4j_compile(val_info.proj_dir)
        compile_status = command_status(compile_out, compile_err)
        ft_test_results = {}
        full_suite_ran = False
        full_suite_status = 'NOT_RUN'
        full_suite_failing_tests = []
        patch_status = 'UNVERIFIED'

        if compile_status == 'PASS':
            for test_case in val_info.failed_test_cases:
                out, err = defects4j_test_one(val_info.proj_dir, test_case)
                ft_test_results[test_case] = test_result(out, err)
            repaired = [test for test, result in ft_test_results.items() if result['status'] == 'PASS']
            if repaired:
                print(
                    f'[VALIDATOR] candidate {val_info.patch_id}/{candidate_total}: '
                    f'progress={len(repaired)}; checking regressions',
                    flush=True,
                )
                full_suite_ran = True
                suite_out, suite_err = defects4j_test_full_suite(val_info.proj_dir)
                full_suite_status = command_status(suite_out, suite_err)
                if full_suite_status in ('PASS', 'FAIL'):
                    full_suite_failing_tests = parse_failing_tests(suite_out)
                if full_suite_status == 'PASS' and not full_suite_failing_tests:
                    patch_status = 'PLAUSIBLE'
                elif full_suite_status == 'TIMEOUT':
                    patch_status = 'FULL_SUITE_TIMEOUT'
                else:
                    patch_status = 'FULL_SUITE_FAIL'
            else:
                print(
                    f'[VALIDATOR] candidate {val_info.patch_id}/{candidate_total}: no progress; '
                    'skipping regression suite',
                    flush=True,
                )
                patch_status = 'NO_FT_REPAIR'
        elif compile_status == 'TIMEOUT':
            patch_status = 'COMPILE_TIMEOUT'
        else:
            patch_status = 'UNCOMPILABLE'

        next_state = next_state_from_existing_results(
            curr_patch_code, full_suite_ran, full_suite_status,
            full_suite_failing_tests, ft_test_results, val_info.proj_dir,
        )
        legacy_failing_tests = {
            'TRIGGER': [test for test, result in ft_test_results.items() if result['status'] not in ('PASS', 'TIMEOUT')],
            'RELEVANT': full_suite_failing_tests,
            'TIMEOUT': [test for test, result in ft_test_results.items() if result['status'] == 'TIMEOUT'],
        }
        summary = {
            'patch_code': curr_patch_code,
            'patch_status': patch_status,
            'failing_tests': legacy_failing_tests,
            'val_cnt': 1,
            'bug_name': val_info.curr_bug,
            'bug_id': val_info.curr_bug,
            'round_id': val_info.round_id,
            'candidate_index': val_info.patch_id,
            'compile_status': compile_status,
            'current_failed_tests': val_info.failed_test_cases,
            'current_test_context': val_info.current_test_context,
                'current_state_sha256': val_info.current_state_sha256,
            'ft_test_results': ft_test_results,
            'full_suite_ran': full_suite_ran,
            'full_suite_status': full_suite_status,
            'full_suite_failing_tests': full_suite_failing_tests,
            **next_state,
        }
        val_info.update_patch_val_result(summary)
        val_info.save_validation_results()
        if patch_status == 'PLAUSIBLE':
            plausible_patches.append({'patch_code': curr_patch_code, 'bug_name': val_info.curr_bug})
        val_info.restore_p0_source()

    val_info.save_validation_results(done=True)
    if plausible_patches:
        plausible_file_path = os.path.join(val_info.val_result_path, f"{val_info.curr_bug}-plausible.json")
        with open(plausible_file_path, 'w') as f:
            json.dump(plausible_patches, f, indent=2)
    return val_info.validated_result


def validate_defects4j(candidate_patches):
    workers = int(multiprocessing.cpu_count())
    print(workers)
    with cf.ProcessPoolExecutor(max_workers=workers) as pool:
        future = pool.map(validate_patches_per_bug, candidate_patches.items())
        for result in future:
            try:
                pass 
            except Exception as e:
                print(f"Exception: {repr(e)}")
                traceback.print_exc()
                continue
    print('[END VALIDATION]')
    sys.stdout.flush()
    time.sleep(3)
    return

@contextmanager
def log_or_print(log_mode, log_path):
    if log_mode:
        with open(log_path, 'a') as log_file, redirect_stdout(log_file), redirect_stderr(log_file):
            yield
    else:
        yield

def shuffle_validated_patches(candidate_patches):
    items = list(candidate_patches.items())
    random.shuffle(items)
    shuffled_patches = {key: value for key, value in items}
    return shuffled_patches


if __name__ == '__main__':
    start_val_time = time.time()

    parser = argparse.ArgumentParser()
    parser.add_argument('-i', type=str, required=True, help='patch file path')
    parser.add_argument('-o', type=str, required=False, help='validation result output path(Empty Dir)', \
                        default='/tmp/llm4apr_validation/result')
    parser.add_argument('-d', type=str, required=False, help='validation dataset path')
    parser.add_argument('-log', action='store_true', help='log mode(std-o/e to validation.log).')
    args = parser.parse_args()
    
    validation_config = {
        'input_path'    : os.path.abspath(args.i),
        'output_path'   : os.path.abspath(args.o),
        'dataset_path'  : os.path.abspath(args.d),
        'log_mode'      : args.log,
    }
    input_patch_file =  os.path.abspath(args.i)
    output_result_dir =  os.path.abspath(args.o)

    validation_tmp_path = '/tmp/llm4apr_validation/'
    validation_config_path = '/tmp/llm4apr_validation/config.json'
    log_file_path = os.path.join(os.path.abspath(args.o), 'validation.log')

    clean_tmp_folder(validation_tmp_path)
    with open(validation_config_path, 'w') as f:
        json.dump(validation_config, f, indent=2)

    assert not os.path.exists(output_result_dir) or (os.path.isdir(output_result_dir) and len(os.listdir(output_result_dir)) == 0), \
        f"[ERROR] [ASSERT FAILURE] {output_result_dir} should either not exist or be an empty directory."
    
    candidate_patches = json.load(open(input_patch_file, 'r'))

    os.makedirs(output_result_dir)
    with log_or_print(log_mode=args.log, log_path=log_file_path):
        validate_defects4j(candidate_patches)
        print(f'[TIME INFO] total_time = {int(time.time() - start_val_time)} s')
