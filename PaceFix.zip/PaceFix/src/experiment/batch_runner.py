"""Sequential launcher for the existing formal PaceFix experiment pipeline."""
from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence, TextIO

from src.experiment.interactive_runner import (
    DEFAULT_OUTPUT_ROOT,
    _is_resumable_run,
    run_experiment,
    validate_bug_id,
)
from src.experiment.dataset_profiles import dataset_choices, get_dataset_profile
from src.experiment.service_manager import ensure_formal_services


def parse_bug_input(text: str, validate: Callable[[str], str] = validate_bug_id) -> list[str]:
    """Split whitespace-separated IDs, validate them, and preserve input order."""
    if not text.split():
        raise ValueError("bug_id_empty")
    result: list[str] = []
    seen: set[str] = set()
    for item in text.split():
        bug_id = validate(item)
        if bug_id not in seen:
            seen.add(bug_id)
            result.append(bug_id)
    return result


def _completed_result(run_dir: Path) -> bool:
    # A summary written after an execution error is diagnostic only; the
    # running checkpoint means this Bug must resume rather than be skipped.
    return (run_dir / "summary.md").is_file() and not _is_resumable_run(run_dir, run_dir.name)


def run_batch(
    bug_ids: Sequence[str], *, output_root: Path = DEFAULT_OUTPUT_ROOT,
    run_one: Callable[..., tuple[Path, Mapping[str, Any]]] = run_experiment,
    ensure_services: Callable[[], None] = ensure_formal_services,
    stream: TextIO | None = None, dataset_path: Path | None = None,
) -> list[dict[str, Any]]:
    """Run validated Bug IDs sequentially through the frozen single-Bug chain."""
    if not bug_ids:
        raise ValueError("bug_id_empty")
    out = stream or sys.stdout
    root = output_root.resolve()
    # Initialize services once per batch; individual Bugs use the ready set.
    ensure_services()
    results: list[dict[str, Any]] = []
    total = len(bug_ids)
    for position, bug_id in enumerate(bug_ids, 1):
        print(f"[{position}/{total}] {bug_id}", file=out, flush=True)
        run_dir = root / bug_id
        if _completed_result(run_dir):
            print("SKIPPED (completed)", file=out, flush=True)
            results.append({"bug_id": bug_id, "status": "completed", "run_dir": str(run_dir)})
            continue
        resume_dir = run_dir if _is_resumable_run(run_dir, bug_id) else None
        try:
            kwargs: dict[str, Any] = {
                "output_root": root, "run_dir": resume_dir, "ensure_services": False,
            }
            if dataset_path is not None:
                kwargs["dataset_path"] = dataset_path
            _, result = run_one(bug_id, **kwargs)
        except KeyboardInterrupt:
            # The single-Bug runner keeps its checkpoint when interrupted.
            print("INTERRUPTED", file=out, flush=True)
            raise
        except Exception as exc:
            print(f"FAILED ({type(exc).__name__}: {exc})", file=out, flush=True)
            results.append({
                "bug_id": bug_id, "status": "error", "error": str(exc),
                "run_dir": str(run_dir),
            })
            # A resumable error is unfinished work: stop this batch rather than
            # silently advancing to a different Bug.
            if _is_resumable_run(run_dir, bug_id):
                print("PAUSED (resumable error)", file=out, flush=True)
                break
            continue
        status = "SUCCESS" if result.get("termination") == "all_tests_pass" else "FAILED"
        print(status, file=out, flush=True)
        results.append({
            "bug_id": bug_id, "status": status.lower(), "result": result,
            "run_dir": str(run_dir),
        })
    return results


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Run formal PaceFix experiments sequentially.")
    parser.add_argument("--bugs", help="Whitespace-separated Defects4J Bug IDs")
    parser.add_argument("--dataset", choices=dataset_choices(), default="v1.2")
    parser.add_argument("--output-root", type=Path)
    args = parser.parse_args(argv)
    text = args.bugs
    if text is None:
        try:
            text = input("请输入 Bug（多个用空格分隔）：").strip()
        except EOFError:
            return 0
    try:
        profile = get_dataset_profile(args.dataset)
        bug_ids = parse_bug_input(text, validate=lambda item: validate_bug_id(item, profile.dataset_path))
        run_batch(bug_ids, output_root=args.output_root or profile.output_root, dataset_path=profile.dataset_path)
    except (ValueError, RuntimeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
