"""Frozen execution-guided intra-procedural Dataflow baseline for one P_t."""
from __future__ import annotations
import argparse
import hashlib
import json
import subprocess
import tempfile
import os
import re
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any, Mapping, Sequence

DEFECTS4J="/home/reinfix/defects4j-2.0.0/framework/bin/defects4j"
JOERN="/home/reinfix/tools/joern-v4.0.6/joern-cli/joern"
JOERN_PARSE="/home/reinfix/tools/joern-v4.0.6/joern-cli/joern-parse"
GUMTREE="/home/reinfix/tools/gumtree/bin/gumtree"
JAVA8="/usr/lib/jvm/java-8-openjdk-amd64"
JAVA21="/usr/lib/jvm/java-21-openjdk-amd64"


# Process-local caches: they are intentionally not persisted as experimental data.
# The method cache contains only identities that have covered this target function;
# coverage cache contains only P_t/test measurements, never baseline conclusions.
_COVERING_METHODS: dict[str, tuple[str, ...]] = {}
_PT_COVERAGE: dict[tuple[str, str, str, int, int], list[dict[str, Any]]] = {}

def _state_hash(current_state_code: str) -> str:
    return hashlib.sha256(current_state_code.encode("utf-8")).hexdigest()

def _method_cache_key(bug_id: str, start: int, end: int) -> str:
    return f"{bug_id}:{start}:{end}"

def _cache_root() -> Path:
    root = Path(os.environ.get("PACEFIX_DATAFLOW_CACHE_DIR", tempfile.gettempdir())) / "pacefix_dataflow_cache"
    root.mkdir(parents=True, exist_ok=True)
    return root

def _cache_file(bug_id: str) -> Path:
    return _cache_root() / (re.sub(r"[^A-Za-z0-9_.-]", "_", bug_id) + ".json")

def _load_disk_cache(bug_id: str) -> dict[str, Any]:
    try:
        value = json.loads(_cache_file(bug_id).read_text())
    except (FileNotFoundError, OSError, json.JSONDecodeError):
        return {"covering_methods": {}, "coverage": {}, "complete_method_scans": []}
    if not isinstance(value, Mapping):
        return {"covering_methods": {}, "coverage": {}, "complete_method_scans": []}
    return {
        "covering_methods": value.get("covering_methods") if isinstance(value.get("covering_methods"), Mapping) else {},
        "coverage": value.get("coverage") if isinstance(value.get("coverage"), Mapping) else {},
        "complete_method_scans": value.get("complete_method_scans") if isinstance(value.get("complete_method_scans"), list) else [],
    }

def _save_disk_cache(bug_id: str, value: Mapping[str, Any]) -> None:
    target = _cache_file(bug_id)
    temporary = target.with_suffix(".tmp")
    temporary.write_text(json.dumps(value, sort_keys=True))
    temporary.replace(target)

def _coverage_cache_key(bug_id: str, state_hash: str, test: str, start: int, end: int) -> tuple[str, str, str, int, int]:
    return bug_id, state_hash, test, start, end

def get_cached_pt_coverage(bug_id: str, state_hash: str, test: str, start: int, end: int) -> dict[str, Any] | None:
    samples = _PT_COVERAGE.get(_coverage_cache_key(bug_id, state_hash, test, start, end))
    return dict(samples[0]) if samples else None

def _cached_coverage(
    work_dir: Path, bug_id: str, state_hash: str, test: str, start: int, end: int,
    timeout: int, cache: dict[str, Any], required_samples: int, stats: dict[str, int],
) -> list[dict[str, Any]]:
    key = _coverage_cache_key(bug_id, state_hash, test, start, end)
    encoded = "|".join(map(str, key))
    samples = _PT_COVERAGE.get(key)
    if samples is None:
        raw = cache["coverage"].get(encoded, [])
        samples = [dict(item) for item in raw if isinstance(item, Mapping)]
        _PT_COVERAGE[key] = samples
    reused = min(len(samples), required_samples)
    stats["coverage_cache_hits"] += reused
    while len(samples) < required_samples:
        samples.append(_coverage_once(work_dir, test, start, end, timeout))
        stats["coverage_cache_misses"] += 1
    cache["coverage"][encoded] = samples
    return samples[:required_samples]
def _java_command(java_home: str, command: Sequence[str]) -> list[str]:
    # Preserve the configured Defects4J/SVN toolchain and only select the Java
    # runtime for this subprocess.  Replacing PATH with a minimal system path
    # breaks Defects4J checkout on this environment.
    path = f"{java_home}/bin:" + os.environ.get("PATH", "")
    return ["env", f"JAVA_HOME={java_home}", f"PATH={path}", *command]

def _run(command: Sequence[str], timeout: int) -> tuple[str,str,str]:
    try: result=subprocess.run(command,text=True,capture_output=True,timeout=timeout,check=False)
    except subprocess.TimeoutExpired: return "TIMEOUT","","TIMEOUT"
    return ("PASS",result.stdout,result.stderr) if result.returncode==0 else ("ERROR",result.stdout,result.stderr)

def _apply_function(work_dir: Path, bug: Mapping[str,Any], code: str) -> tuple[int,int]:
    target=work_dir/str(bug["loc"])
    try: source,encoding=target.read_text(encoding="utf-8"),"utf-8"
    except UnicodeDecodeError: source,encoding=target.read_text(encoding="ISO-8859-1"),"ISO-8859-1"
    lines=source.splitlines(keepends=True); start,end=int(bug["start"]),int(bug["end"]); replacement=code.strip()+"\n"
    lines[start-1:end]=[replacement]; target.write_text("".join(lines),encoding=encoding)
    return start,start+replacement.count("\n")-1

def _discover_test_methods(work_dir: Path, test_classes: Sequence[str], timeout: int) -> dict[str,Any]:
    """Use JUnit's real runners, never a test-name convention, to enumerate methods."""
    try:
        cp_result=subprocess.run(_java_command(JAVA8,[DEFECTS4J,"export","-p","cp.test"]),cwd=work_dir,text=True,capture_output=True,timeout=timeout,check=False)
        bin_result=subprocess.run(_java_command(JAVA8,[DEFECTS4J,"export","-p","dir.bin.tests"]),cwd=work_dir,text=True,capture_output=True,timeout=timeout,check=False)
    except subprocess.TimeoutExpired: return {"status":"unavailable","reason":"test_metadata_export_timeout"}
    if cp_result.returncode!=0: return {"status":"unavailable","reason":"test_classpath_export_failed","detail":cp_result.stderr.strip()}
    if bin_result.returncode!=0: return {"status":"unavailable","reason":"test_binary_dir_export_failed","detail":bin_result.stderr.strip()}
    cp, bin_tests = cp_result.stdout, bin_result.stdout
    source=r"""import java.util.*; import junit.framework.*; import org.junit.runner.*;
public class PaceFixTestMethods {
 static void add(Test t, Set<String> out) { if(t instanceof TestSuite) { Enumeration e=((TestSuite)t).tests(); while(e.hasMoreElements()) add((Test)e.nextElement(),out); } else if(t instanceof TestCase) out.add(((TestCase)t).getClass().getName()+"::"+((TestCase)t).getName()); }
 static void add4(Description d,String c,Set<String> out) { if(d.getChildren().isEmpty()&&d.getMethodName()!=null) out.add(c+"::"+d.getMethodName()); for(Description x:d.getChildren()) add4(x,c,out); }
 public static void main(String[] a)throws Exception { Class c=Class.forName(a[0]); Set<String> out=new TreeSet<String>(); try{add(new TestSuite(c),out);}catch(Throwable e){} if(out.isEmpty()) add4(Request.aClass(c).getRunner().getDescription(),c.getName(),out); for(String x:out)System.out.println(x); }
}"""
    with tempfile.TemporaryDirectory(prefix="pacefix_dataflow_junit_") as path:
        root=Path(path); java=root/"PaceFixTestMethods.java"; java.write_text(source)
        env=dict(os.environ); env["JAVA_HOME"]=JAVA8; env["PATH"]=JAVA8+"/bin:/usr/bin:/bin"
        try:
            compile_result=subprocess.run([JAVA8+"/bin/javac","-cp",cp.strip(),str(java)],cwd=work_dir,text=True,capture_output=True,timeout=timeout,check=False,env=env)
        except subprocess.TimeoutExpired: return {"status":"unavailable","reason":"test_discovery_compile_timeout"}
        if compile_result.returncode!=0: return {"status":"unavailable","reason":"test_discovery_compile_failed","detail":compile_result.stderr.strip()}
        methods=[]; failed=[]
        runner_cp=f"{root}:{bin_tests.strip()}:{cp.strip()}"
        for test_class in test_classes:
            try: result=subprocess.run([JAVA8+"/bin/java","-cp",runner_cp,"PaceFixTestMethods",test_class],cwd=work_dir,text=True,capture_output=True,timeout=timeout,check=False,env=env)
            except subprocess.TimeoutExpired: failed.append({"class":test_class,"reason":"timeout"}); continue
            found=[line.strip() for line in result.stdout.splitlines() if "::" in line]
            if result.returncode!=0 or not found: failed.append({"class":test_class,"reason":"runner_failed" if result.returncode else "no_methods","detail":result.stderr.strip()}); continue
            methods.extend(found)
    if failed: return {"status":"unavailable","reason":"test_method_discovery_incomplete","failed_classes":failed}
    return {"status":"PASS","methods":methods}

def _coverage_once(work_dir: Path, test: str, start: int, end: int, timeout: int) -> dict[str,Any]:
    xml=work_dir/"coverage.xml"
    if xml.exists(): xml.unlink()
    status,out,err=_run(_java_command(JAVA8,[DEFECTS4J,"coverage","-w",str(work_dir),"-t",test]),timeout)
    if status!="PASS" or not xml.is_file():
        return {"status":"unavailable","reason":"coverage_"+status.lower() if status!="PASS" else "coverage_xml_missing","detail":err.strip()}
    try:
        root=ET.parse(xml).getroot()
        lines=sorted({int(x.attrib["number"]) for x in root.findall(".//line") if start<=int(x.attrib.get("number",-1))<=end and int(x.attrib.get("hits","0"))>0})
    except (ET.ParseError,ValueError) as exc: return {"status":"unavailable","reason":"coverage_xml_parse_failed","detail":str(exc)}
    return {"status":"PASS","test_status":"FAIL" if re.search(r"run\.dev\.tests\).*?\bFAIL\b",err) else "PASS","executed_lines":lines}

def collect_pt_coverage(bug_id: str,dataset: Mapping[str,Any],current_state_code: str,failing_tests: Sequence[str],passing_tests: Sequence[str],timeout: int=300) -> dict[str,Any]:
    bug=dataset.get(bug_id)
    if not isinstance(bug,Mapping) or not failing_tests: return {"status":"unavailable","reason":"missing_bug_or_failing_tests"}
    try: project,version=bug_id.split("-",1)
    except ValueError: return {"status":"unavailable","reason":"invalid_bug_id"}
    state_hash=_state_hash(current_state_code); stats={"coverage_cache_hits":0,"coverage_cache_misses":0}
    with tempfile.TemporaryDirectory(prefix="pacefix_dataflow_coverage_") as path:
        work=Path(path)/bug_id; status,_,err=_run(_java_command(JAVA8,[DEFECTS4J,"checkout","-p",project,"-v",version+"b","-w",str(work)]),timeout)
        if status!="PASS": return {"status":"unavailable","reason":"checkout_"+status.lower(),"detail":err.strip()}
        try: start,end=_apply_function(work,bug,current_state_code)
        except Exception as exc: return {"status":"unavailable","reason":"current_state_apply_failed","detail":str(exc)}
        cache=_load_disk_cache(bug_id); method_key=_method_cache_key(bug_id,int(bug["start"]),int(bug["end"]))
        failing={}; failing_coverage_errors={}
        for test in failing_tests:
            result=_cached_coverage(work,bug_id,state_hash,str(test),start,end,timeout,cache,1,stats)[0]
            # F_t is supplied by the validator.  One instrumentation failure
            # lowers evidence coverage; it must not discard other F_t evidence.
            if result["status"]!="PASS":
                failing_coverage_errors[str(test)]=result
                continue
            if result["executed_lines"]:
                failing[str(test)]=result
            else:
                failing_coverage_errors[str(test)]={"status":"unavailable","reason":"no_function_execution"}
        failed_set={str(test) for test in failing_tests}
        known=cache["covering_methods"].get(method_key)
        method_cache_hit=isinstance(known,list) and method_key in cache["complete_method_scans"]
        if method_cache_hit:
            passing_methods=[str(test) for test in known if str(test) not in failed_set]
        else:
            discovery=_discover_test_methods(work,list(passing_tests),timeout)
            if discovery["status"]!="PASS": return {"status":"unavailable","reason":discovery["reason"],"detail":discovery}
            passing_methods=[test for test in discovery["methods"] if test not in failed_set]
        passing={}; first_pass_covered=0; covering_methods=[]; scan_complete=True
        for test in passing_methods:
            first=_cached_coverage(work,bug_id,state_hash,test,start,end,timeout,cache,1,stats)[0]
            if first["status"]!="PASS":
                # A timeout/error means the initial full-method scan is incomplete.
                scan_complete=False
            if first["status"]!="PASS" or first["test_status"]!="PASS" or not first["executed_lines"]:
                passing[test]=[first]
                continue
            first_pass_covered+=1; covering_methods.append(test)
            passing[test]=_cached_coverage(work,bug_id,state_hash,test,start,end,timeout,cache,3,stats)
        if not method_cache_hit and scan_complete:
            cache["covering_methods"][method_key]=covering_methods
            cache["complete_method_scans"]=sorted(set(cache["complete_method_scans"]) | {method_key})
        _save_disk_cache(bug_id,cache)
    if not failing: return {"status":"unavailable","reason":"no_failing_test_covers_target_function","function_start":start,"function_end":end,"failing_test_coverage_errors":failing_coverage_errors}
    return {"status":"available","function_start":start,"function_end":end,"failing_tests":failing,"failing_test_coverage_errors":failing_coverage_errors,"passing_runs":passing,"relevant_test_classes":list(passing_tests),"passing_method_candidates":passing_methods,"first_pass_covered_count":first_pass_covered,"passing_coverage_call_count":stats["coverage_cache_misses"],"coverage_cache_hits":stats["coverage_cache_hits"],"method_cache_hit":method_cache_hit}

def _joern_graph(current_state_code: str,timeout: int=120) -> dict[str,Any]:
    prefix,suffix="class DataflowWrapper {\n","\n}\n"
    script=r"""import io.shiftleft.semanticcpg.language._
import io.shiftleft.codepropertygraph.generated.nodes._
import ujson._
@main def main(cpgFile: String, outFile: String): Unit = {
 importCpg(cpgFile)
 def lines(n: AstNode): List[Int] = n.ast.lineNumber.l.distinct.sorted
 def row(n: CfgNode): Obj = Obj("id"->n.id,"label"->n.label,"name"->(n match { case c: Call => c.name; case _ => "" }),"code"->n.code,"lineNumber"->n.lineNumber.getOrElse(-1),"columnNumber"->n.columnNumber.getOrElse(-1),"astLines"->Arr.from(lines(n)))
 val targetStart = __TARGET_START__
 val targetEnd = __TARGET_END__
 val methods=cpg.method.l.filter { method =>
   val astLines=method.ast.lineNumber.l
   method.code != "<empty>" && astLines.nonEmpty &&
   astLines.min >= targetStart && astLines.max <= targetEnd
 }
 if(methods.size != 1) throw new RuntimeException("target_method_not_unique")
 val nodes=methods.head.cfgNode.l; val ids=nodes.map(_.id).toSet
 val edges=nodes.flatMap { source => source._reachingDefOut.l.collect { case target: CfgNode if ids.contains(target.id) => Obj("defId"->source.id,"useId"->target.id) } }
 ujson.write(Obj("nodes"->Arr.from(nodes.map(row)),"edges"->Arr.from(edges)),indent=2) #> outFile
}"""
    target_start = prefix.count("\n") + 1
    target_end = target_start + current_state_code.strip().count("\n")
    script = script.replace("__TARGET_START__", str(target_start)).replace("__TARGET_END__", str(target_end))
    with tempfile.TemporaryDirectory(prefix="pacefix_dataflow_joern_") as path:
        root=Path(path); (root/"DataflowWrapper.java").write_text(prefix+current_state_code+suffix); (root/"query.sc").write_text(script)
        status,_,err=_run(_java_command(JAVA21,[JOERN_PARSE,str(root),"--output",str(root/"cpg.bin")]),timeout)
        if status!="PASS": return {"status":"unavailable","reason":"joern_parse_"+status.lower(),"detail":err.strip()}
        status,_,err=_run(_java_command(JAVA21,[JOERN,"--script",str(root/"query.sc"),"--param",f"cpgFile={root/'cpg.bin'}","--param",f"outFile={root/'out.json'}","--nocolors"]),timeout)
        if status!="PASS" or not (root/"out.json").is_file(): return {"status":"unavailable","reason":"joern_query_"+status.lower() if status!="PASS" else "joern_output_missing","detail":err.strip()}
        try: raw=json.loads((root/"out.json").read_text())
        except (OSError,json.JSONDecodeError) as exc: return {"status":"unavailable","reason":"joern_output_parse_failed","detail":str(exc)}
    if not isinstance(raw,Mapping) or not isinstance(raw.get("nodes"),list) or not isinstance(raw.get("edges"),list): return {"status":"unavailable","reason":"joern_output_malformed"}
    shift=prefix.count("\n"); nodes={}
    for item in raw["nodes"]:
        if not isinstance(item,Mapping) or item.get("id") is None: return {"status":"unavailable","reason":"joern_node_malformed"}
        lines=sorted({int(x)-shift for x in item.get("astLines",[]) if isinstance(x,int) and x>shift})
        line_number=item.get("lineNumber"); column_number=item.get("columnNumber")
        line=int(line_number)-shift if isinstance(line_number,int) and line_number>shift else None
        column=int(column_number) if isinstance(column_number,int) and column_number>0 else None
        nodes[str(item["id"])]={"node_id":str(item["id"]),"node_type":item.get("label"),"code":item.get("code"),"line":line if line is not None else min(lines) if lines else None,"line_end":max(lines) if lines else None,"column":column,"ast_lines":lines,"name":item.get("name")}
    edges=[]
    for item in raw["edges"]:
        if not isinstance(item,Mapping): return {"status":"unavailable","reason":"joern_edge_malformed"}
        source,target=str(item.get("defId")),str(item.get("useId"))
        if source not in nodes or target not in nodes: return {"status":"unavailable","reason":"joern_edge_endpoint_missing"}
        edges.append((source,target))
    return {"status":"available","nodes":nodes,"edges":sorted(set(edges))}

def _is_sink(node: Mapping[str,Any]) -> bool:
    return node.get("node_type")=="RETURN" or node.get("name")=="<operator>.throw" or (node.get("name")=="<operator>.assignment" and "." in str(node.get("code","")).split("=",1)[0])

def _flow_for_test(graph: Mapping[str,Any],executed_lines: Sequence[int]) -> dict[str,Any]:
    executed={int(x) for x in executed_lines}; nodes,edges=graph["nodes"],graph["edges"]
    covered={node_id for node_id,node in nodes.items() if set(node.get("ast_lines",[])) & executed}
    sinks={node_id for node_id in covered if _is_sink(nodes[node_id])}
    if not sinks: return {"status":"unavailable","reason":"covered_sink_missing"}
    incoming={}
    for source,target in edges:
        if source in covered and target in covered: incoming.setdefault(target,set()).add(source)
    relevant,todo=set(sinks),list(sinks)
    while todo:
        target=todo.pop()
        for source in incoming.get(target,set()):
            if source not in relevant: relevant.add(source); todo.append(source)
    dependencies=[{"def":nodes[s],"use":nodes[t]} for s,t in edges if s in relevant and t in relevant]
    if not dependencies: return {"status":"unavailable","reason":"covered_sink_dependency_missing"}
    return {"status":"available","sink_node_ids":sorted(sinks),"dependencies":dependencies}

def _signature(item: Mapping[str,Any]) -> tuple[Any,...]:
    source,target=item["def"],item["use"]
    return source["node_id"],target["node_id"]

def build_frozen_baseline(bug_id: str,current_state_code: str,failing_tests: Sequence[str],passing_tests: Sequence[str],dataset: Mapping[str,Any],timeout: int=300) -> dict[str,Any]:
    """Build P_t-only evidence. Candidate Dataflow scoring and selection are not implemented."""
    coverage=collect_pt_coverage(bug_id,dataset,current_state_code,failing_tests,passing_tests,timeout)
    if coverage.get("status")!="available": return {"status":"unavailable","reason":coverage.get("reason"),"coverage":coverage}
    graph=_joern_graph(current_state_code,timeout)
    if graph.get("status")!="available": return {"status":"unavailable","reason":graph.get("reason"),"joern":graph}
    start=coverage["function_start"]; failing={}
    for test,result in coverage["failing_tests"].items():
        flow=_flow_for_test(graph,[x-start+1 for x in result["executed_lines"]])
        if flow["status"]!="available": return {"status":"unavailable","reason":flow["reason"],"test":test}
        failing[test]=flow
    stable={}
    for test,runs in coverage["passing_runs"].items():
        if len(runs)!=3 or any(run["status"]!="PASS" or run["test_status"]!="PASS" for run in runs): continue
        flows=[_flow_for_test(graph,[x-start+1 for x in run["executed_lines"]]) for run in runs]
        if any(flow["status"]!="available" for flow in flows): continue
        signatures=[sorted(_signature(x) for x in flow["dependencies"]) for flow in flows]
        if all(signatures[0]==x for x in signatures[1:]): stable[test]=flows[0]
    if not stable: return {"status":"unavailable","reason":"no_stable_passing_reference_dependencies","failing_tests":list(failing)}
    reference={_signature(x) for flow in stable.values() for x in flow["dependencies"]}
    failure_specific={test:{"sink_node_ids":flow["sink_node_ids"],"dependencies":[x for x in flow["dependencies"] if _signature(x) not in reference]} for test,flow in failing.items()}
    return {"status":"available","reason":None,"bug_id":bug_id,"current_state_sha256":_state_hash(current_state_code),"failing_tests":list(failing),"stable_passing_tests":list(stable),"failure_specific_by_test":failure_specific,"reference_by_test":{test:{"sink_node_ids":flow["sink_node_ids"],"dependencies":flow["dependencies"]} for test,flow in stable.items()}}


_GUMTREE_RANGE = re.compile(r"^(?P<type>.+?) \[(?P<start>\d+),(?P<length>\d+)\]$")

def _gumtree_node(value: Any) -> dict[str, Any] | None:
    match = _GUMTREE_RANGE.match(str(value))
    if not match: return None
    start, end = int(match["start"]), int(match["length"])
    node_type, _, label = match["type"].partition(":")
    return {"type": node_type, "label": label.strip(), "start": start, "end": end, "length": end - start}

def _gumtree_matches(pt_code: str, candidate_code: str, timeout: int = 60) -> dict[str, Any]:
    prefix, suffix = "class DataflowMappingWrapper {\n", "\n}\n"
    with tempfile.TemporaryDirectory(prefix="pacefix_dataflow_gumtree_") as path:
        root=Path(path); before=root/"Pt.java"; after=root/"Candidate.java"
        before.write_text(prefix+pt_code+suffix); after.write_text(prefix+candidate_code+suffix)
        status,out,err=_run(_java_command(JAVA21,[GUMTREE,"textdiff","-g","java-jdt","-f","JSON",str(before),str(after)]),timeout)
    if status!="PASS": return {"status":"unavailable","reason":"gumtree_"+status.lower(),"detail":err.strip()}
    try: raw=json.loads(out)
    except json.JSONDecodeError as exc: return {"status":"unavailable","reason":"gumtree_json_parse_failed","detail":str(exc)}
    if not isinstance(raw,Mapping) or not isinstance(raw.get("matches"),list): return {"status":"unavailable","reason":"gumtree_matches_missing"}
    result=[]
    for item in raw["matches"]:
        source,destination=_gumtree_node(item.get("src")),_gumtree_node(item.get("dest"))
        if source and destination:
            result.append((source,destination))
    return {"status":"available","prefix_length":len(prefix),"matches":result}

def _line_column_offset(code: str, line: Any, column: Any) -> int | None:
    if not isinstance(line,int) or not isinstance(column,int) or line < 1 or column < 1: return None
    starts=[0]
    for index,char in enumerate(code):
        if char=="\n": starts.append(index+1)
    if line > len(starts): return None
    offset=starts[line-1]+column-1
    return offset if 0 <= offset <= len(code) else None

def _node_span(code: str, node: Mapping[str, Any]) -> tuple[int,int] | None:
    exact=_line_column_offset(code,node.get("line"),node.get("column"))
    text=node.get("code")
    if exact is not None and isinstance(text,str) and text:
        return exact,exact+len(text)
    lines=[int(x) for x in node.get("ast_lines",[]) if isinstance(x,int)]
    if not lines: return None
    starts=[0]
    for i,char in enumerate(code):
        if char=="\n": starts.append(i+1)
    if min(lines)<1 or max(lines)>len(starts): return None
    start=starts[min(lines)-1]; end=starts[max(lines)] if max(lines)<len(starts) else len(code)
    return start,end

def _normalized_source(value: str) -> str:
    return re.sub(r"\s+","",value)

def _gumtree_types(endpoint: Mapping[str,Any]) -> set[str]:
    label=str(endpoint.get("node_type","")); code=str(endpoint.get("code",""))
    if label=="IDENTIFIER": return {"SimpleName"}
    if label=="RETURN": return {"ReturnStatement"}
    if label=="CALL" and code.lstrip().startswith("new "): return {"ClassInstanceCreation"}
    if label=="CALL": return {"MethodInvocation","SuperMethodInvocation"}
    return set()

def _map_endpoint(pt_code: str, candidate_code: str, endpoint: Mapping[str,Any],
                  matches: Sequence[tuple[Mapping[str,Any],Mapping[str,Any]]],
                  prefix_length: int, candidate_graph: Mapping[str,Any]) -> str | None:
    span=_node_span(pt_code,endpoint)
    if span is None: return None
    expected=str(endpoint.get("code","")); expected_types=_gumtree_types(endpoint)
    # GumTree's JSON description supplies a reliable node start, but its second
    # bracket value is not a source length.  Combine the exact start, AST kind,
    # and available node label instead of treating that value as a range.
    choices=[destination for source,destination in matches
             if source["start"]-prefix_length==span[0]
             and (not expected_types or source["type"] in expected_types)
             and (not source.get("label") or source["label"]==expected)]
    if len(choices)!=1: return None
    destination=choices[0]; candidate_start=destination["start"]-prefix_length
    candidates=[]
    for node_id,node in candidate_graph["nodes"].items():
        if node.get("node_type")!=endpoint.get("node_type") or node.get("code")!=endpoint.get("code"): continue
        candidate_span=_node_span(candidate_code,node)
        if candidate_span is not None and candidate_span[0]==candidate_start:
            candidates.append(node_id)
    return candidates[0] if len(candidates)==1 else None

def _dependency_items(baseline: Mapping[str,Any], kind: str) -> list[tuple[str,Mapping[str,Any]]]:
    groups=baseline.get("failure_specific_by_test",{}) if kind=="failure_specific" else baseline.get("reference_by_test",{})
    result=[]
    for test,record in groups.items():
        for ordinal,item in enumerate(record.get("dependencies",[])):
            result.append((f"{test}:{ordinal}",item))
    return result

def _candidate_dependency_facts(pt_code: str, candidate_code: str, baseline: Mapping[str,Any], timeout: int) -> dict[str,Any]:
    mapping=_gumtree_matches(pt_code,candidate_code,timeout)
    if mapping.get("status")!="available": return mapping
    graph=_joern_graph(candidate_code,timeout)
    if graph.get("status")!="available": return graph
    current_graph=_joern_graph(pt_code,timeout)
    if current_graph.get("status")!="available": return current_graph
    facts={}
    for kind in ("failure_specific","reference"):
        for key,item in _dependency_items(baseline,kind):
            source_endpoint=current_graph["nodes"].get(str(item.get("def",{}).get("node_id")),item.get("def",{}))
            target_endpoint=current_graph["nodes"].get(str(item.get("use",{}).get("node_id")),item.get("use",{}))
            source=_map_endpoint(pt_code,candidate_code,source_endpoint,mapping["matches"],mapping["prefix_length"],graph)
            target=_map_endpoint(pt_code,candidate_code,target_endpoint,mapping["matches"],mapping["prefix_length"],graph)
            if source is None or target is None:
                facts[(kind,key)]={"comparable":False}
            else:
                facts[(kind,key)]={"comparable":True,"present":(source,target) in set(graph["edges"])}
    return {"status":"available","facts":facts}

def score_dataflow_layer(frozen_baseline: Mapping[str,Any], current_state_code: str,
                         candidates: Sequence[Mapping[str,Any]], timeout: int=120) -> dict[str,Any]:
    """Score only an already-ambiguous Control layer; no fallback or selection beyond ties."""
    if frozen_baseline.get("status")!="available": return {"status":"unavailable","reason":"frozen_baseline_unavailable","baseline_reason":frozen_baseline.get("reason")}
    baseline_hash=frozen_baseline.get("current_state_sha256")
    if baseline_hash is not None and baseline_hash != _state_hash(current_state_code):
        return {"status":"unavailable","reason":"baseline_current_state_mismatch"}
    if len(candidates)<2: return {"status":"unavailable","reason":"candidate_layer_not_ambiguous"}
    reports=[]
    for candidate in candidates:
        index=candidate.get("candidate_index"); code=candidate.get("patch_code")
        if not isinstance(index,int) or not isinstance(code,str):
            return {"status":"unavailable","reason":"candidate_input_invalid"}
        report=_candidate_dependency_facts(current_state_code,code,frozen_baseline,timeout)
        if report.get("status")!="available": return {"status":"unavailable","reason":report.get("reason","candidate_analysis_unavailable"),"candidate_index":index}
        report["candidate_index"]=index; reports.append(report)
    common={}
    for kind in ("failure_specific","reference"):
        universe=[key for key,_ in _dependency_items(frozen_baseline,kind)]
        common[kind]=[key for key in universe if all(report["facts"].get((kind,key),{}).get("comparable") for report in reports)]
    def by_test(keys: Sequence[str]) -> dict[str,list[str]]:
        grouped={}
        for key in keys:
            test, separator, ordinal=key.rpartition(":")
            if not separator or not ordinal.isdigit():
                raise ValueError("malformed dependency evidence key")
            grouped.setdefault(test,[]).append(key)
        return grouped
    failure_by_test, reference_by_test=by_test(common["failure_specific"]),by_test(common["reference"])
    if not failure_by_test or not reference_by_test:
        return {"status":"unavailable","reason":"common_evidence_empty","common_failure_specific_count":len(common["failure_specific"]),"common_reference_count":len(common["reference"]),"common_failure_specific_test_count":len(failure_by_test),"common_reference_test_count":len(reference_by_test)}
    scored=[]
    for report in reports:
        failure_ratios=[sum(not report["facts"][("failure_specific",key)]["present"] for key in keys)/len(keys)
                        for keys in failure_by_test.values()]
        reference_ratios=[sum(report["facts"][("reference",key)]["present"] for key in keys)/len(keys)
                          for keys in reference_by_test.values()]
        s_value=sum(failure_ratios)/len(failure_ratios)
        r_value=sum(reference_ratios)/len(reference_ratios)
        score=0.0 if s_value+r_value==0 else 2*s_value*r_value/(s_value+r_value)
        scored.append({"candidate_index":report["candidate_index"],"S":s_value,"R":r_value,"score":score,
                       "comparable_failure_specific_count":len(common["failure_specific"]),
                       "comparable_reference_count":len(common["reference"]),
                       "comparable_failure_specific_test_count":len(failure_by_test),
                       "comparable_reference_test_count":len(reference_by_test)})
    maximum=max(item["score"] for item in scored)
    return {"status":"available","reason":None,"common_failure_specific_count":len(common["failure_specific"]),
            "common_reference_count":len(common["reference"]),
            "common_failure_specific_test_count":len(failure_by_test),
            "common_reference_test_count":len(reference_by_test),"candidates":scored,
            "highest_score_candidate_indices":[item["candidate_index"] for item in scored if item["score"]==maximum]}

def _load_tests(path: str) -> list[str]:
    value=json.loads(Path(path).read_text())
    if not isinstance(value,list) or not all(isinstance(x,str) for x in value): raise ValueError("test JSON must be a string array")
    return value

def main() -> None:
    parser=argparse.ArgumentParser(description="Build or score execution-guided intra-procedural Dataflow evidence.")
    parser.add_argument("--bug-id"); parser.add_argument("--current-state-code-file",required=True)
    parser.add_argument("--failing-tests-file"); parser.add_argument("--passing-tests-file"); parser.add_argument("--dataset")
    parser.add_argument("--frozen-baseline"); parser.add_argument("--candidates-file")
    parser.add_argument("--output",required=True)
    args=parser.parse_args()
    current_state_code=Path(args.current_state_code_file).read_text()
    if args.frozen_baseline or args.candidates_file:
        if not args.frozen_baseline or not args.candidates_file:
            parser.error("--frozen-baseline and --candidates-file must be used together")
        candidates=json.loads(Path(args.candidates_file).read_text())
        if not isinstance(candidates,list):
            parser.error("--candidates-file must contain a JSON array")
        result=score_dataflow_layer(json.loads(Path(args.frozen_baseline).read_text()),current_state_code,candidates)
    else:
        if not args.bug_id or not args.failing_tests_file or not args.passing_tests_file or not args.dataset:
            parser.error("baseline mode requires --bug-id --failing-tests-file --passing-tests-file --dataset")
        result=build_frozen_baseline(args.bug_id,current_state_code,_load_tests(args.failing_tests_file),_load_tests(args.passing_tests_file),json.loads(Path(args.dataset).read_text()))
    Path(args.output).write_text(json.dumps(result,indent=2)+"\n")

if __name__=="__main__":
    raise SystemExit("legacy Dataflow CLI is retired; use run_three_rounds/build_real_runner_hooks")


def _statement_support(regions: Sequence[set[int]]) -> dict[int, float]:
    if not regions:
        raise ValueError("at least one valid failure-test region is required")
    return {line: sum(line in region for region in regions) / len(regions)
            for line in set().union(*regions)}


def _score_mapped_statements(mapped_statements: set[int], support: Mapping[int, float]) -> tuple[dict[str, float], float]:
    if not mapped_statements:
        raise ValueError("reliably mapped statements must be non-empty")
    statement_supports = {str(line): float(support.get(line, 0.0))
                          for line in sorted(mapped_statements)}
    return statement_supports, sum(statement_supports.values()) / len(statement_supports)


def _action_line(tree, code, prefix):
    node=_gumtree_node(tree)
    if not node: return None
    off=node["start"]-prefix
    return code[:off].count("\n")+1 if 0 <= off <= len(code) else None

def _line_start_offset(code: str, line: int) -> int | None:
    if line < 1:
        return None
    starts = [0]
    for offset, character in enumerate(code):
        if character == chr(10):
            starts.append(offset + 1)
    return starts[line - 1] if line <= len(starts) else None


def _fault_statement_lines(bug_id: str, dataset: Mapping[str, Any],
                           current_state_code: str) -> dict[str, Any]:
    bug = dataset.get(bug_id)
    if not isinstance(bug, Mapping) or not isinstance(bug.get("buggy_fl"), str):
        return {"status": "unavailable", "reason": "p0_fault_source_missing"}
    p0_code = bug["buggy_fl"]
    start, locations = bug.get("start"), bug.get("location")
    if isinstance(start, int) and isinstance(locations, list):
        p0_lines = sorted({location - start + 1 for location in locations
                           if isinstance(location, int) and location >= start})
    else:
        marker = "/* bug is here */"
        p0_lines = [line for line, text in enumerate(p0_code.splitlines(), 1)
                    if marker in text and text.replace(marker, "").strip() not in {"", "{", "}", "};"}]
    if not p0_lines:
        return {"status": "unavailable", "reason": "p0_fault_location_missing"}
    if current_state_code == p0_code:
        return {"status": "available", "source": "p0_identity", "lines": p0_lines}
    mapping = _gumtree_matches(p0_code, current_state_code)
    if mapping.get("status") != "available":
        return {"status": "unavailable", "reason": "fault_gumtree_" + str(mapping.get("reason"))}
    mapped_lines = []
    for p0_line in p0_lines:
        offset = _line_start_offset(p0_code, p0_line)
        if offset is None:
            return {"status": "unavailable", "reason": "p0_fault_offset_invalid"}
        wrapped_offset = mapping["prefix_length"] + offset
        choices = [(source, destination) for source, destination in mapping["matches"]
                   if source["start"] <= wrapped_offset < source["end"]]
        statements = [(source, destination) for source, destination in choices
                      if "Statement" in source["type"] or source["type"] in {"ReturnStatement", "ThrowStatement"}]
        choices = statements or choices
        if not choices:
            return {"status": "unavailable", "reason": "fault_statement_unmapped", "p0_line": p0_line}
        smallest = min(source["length"] for source, _ in choices)
        destinations = {destination["start"] for source, destination in choices
                        if source["length"] == smallest}
        if len(destinations) != 1:
            return {"status": "unavailable", "reason": "fault_statement_mapping_not_unique", "p0_line": p0_line}
        current_offset = next(iter(destinations)) - mapping["prefix_length"]
        if current_offset < 0 or current_offset > len(current_state_code):
            return {"status": "unavailable", "reason": "fault_statement_mapping_outside_current", "p0_line": p0_line}
        mapped_lines.append(current_state_code[:current_offset].count("\n") + 1)
    return {"status": "available", "source": "gumtree_p0_to_current", "lines": sorted(set(mapped_lines))}


def _def_use_region(graph: Mapping[str, Any], fault_lines: Sequence[int]) -> dict[str, Any]:
    nodes, edges = graph["nodes"], graph["edges"]
    seeds = {node_id for node_id, node in nodes.items()
             if set(node.get("ast_lines", [])) & set(fault_lines)}
    if not seeds:
        return {"status": "unavailable", "reason": "fault_statement_not_in_current_graph"}
    incoming, outgoing = {}, {}
    for source, target in edges:
        incoming.setdefault(target, set()).add(source)
        outgoing.setdefault(source, set()).add(target)
    selected, todo = set(seeds), list(seeds)
    while todo:
        node_id = todo.pop()
        for related in incoming.get(node_id, set()) | outgoing.get(node_id, set()):
            if related not in selected:
                selected.add(related)
                todo.append(related)
    statements = set(fault_lines)
    for node_id in selected:
        statements.update(int(line) for line in nodes[node_id].get("ast_lines", [])
                          if isinstance(line, int))
    return {"status": "available", "node_count": len(selected), "statements": statements}


def _baseline_statement_lines(graph: Mapping[str, Any]) -> set[int]:
    # CFG nodes provide the complete function-level executable Java-statement
    # anchors; this set is independent of test support.
    return {int(node["line"]) for node in graph["nodes"].values()
            if isinstance(node.get("line"), int) and int(node["line"]) >= 1}


def _nearest_baseline_statement(anchor_line: int, statement_lines: set[int]) -> int | None:
    before = [line for line in statement_lines if line <= anchor_line]
    if before:
        return max(before)
    after = [line for line in statement_lines if line > anchor_line]
    return min(after) if after else None


def run_dataflow_layer(bug_id, current_state_code, failing_tests, candidates, dataset, timeout=300):
    coverage = collect_pt_coverage(bug_id, dataset, current_state_code, failing_tests, [], timeout)
    if coverage.get("status") != "available":
        return {"status": "unavailable", "reason": coverage.get("reason"), "candidates": []}
    graph = _joern_graph(current_state_code, timeout)
    if graph.get("status") != "available":
        return {"status": "unavailable", "reason": graph.get("reason"), "candidates": []}
    fault = _fault_statement_lines(bug_id, dataset, current_state_code)
    if fault.get("status") != "available":
        return {"status": "unavailable", "reason": fault.get("reason"), "fault_mapping": fault, "candidates": []}
    def_use = _def_use_region(graph, fault["lines"])
    if def_use.get("status") != "available":
        return {"status": "unavailable", "reason": def_use.get("reason"), "fault_mapping": fault, "candidates": []}
    baseline_statements = _baseline_statement_lines(graph)
    if not baseline_statements:
        return {"status": "unavailable", "reason": "baseline_java_statements_empty", "fault_mapping": fault, "candidates": []}
    start = coverage["function_start"]
    regions, test_evidence = [], []
    coverage_errors = coverage.get("failing_test_coverage_errors", {})
    for test in failing_tests:
        measurement = coverage.get("failing_tests", {}).get(str(test))
        if not isinstance(measurement, Mapping):
            reason = coverage_errors.get(str(test), {}).get("reason", "coverage_missing_or_no_function_execution")
            test_evidence.append({"test_id": str(test), "status": "unavailable", "reason": reason})
            continue
        executed = {line - start + 1 for line in measurement.get("executed_lines", []) if isinstance(line, int)}
        region = def_use["statements"] & executed
        region.update(set(fault["lines"]) & executed)
        test_evidence.append({"test_id": str(test), "status": "available",
                              "executed_statement_count": len(executed),
                              "def_use_region_statement_count": len(def_use["statements"]),
                              "s_i_statement_count": len(region)})
        if region:
            regions.append(region)
    if not regions:
        return {"status": "unavailable", "reason": "failure_regions_empty", "fault_mapping": fault,
                "failed_test_evidence": test_evidence, "candidates": []}
    support = _statement_support(regions)
    from src.experiment.control_risk import gumtree_json
    prefix = "class DataflowWrapper {\n"; reports = []
    for c in candidates:
        try:
            raw = gumtree_json(prefix + current_state_code + "\n}", prefix + c["patch_code"] + "\n}")
            lines = set()
            for a in raw.get("actions", []):
                action = a.get("action", ""); tree = a.get("tree", "")
                line = _action_line(tree, current_state_code, len(prefix)) if action in {"update-node", "update-tree", "delete-node", "delete-tree", "move-tree", "move-node"} else None
                if line is None and action.startswith("insert"):
                    parent = _gumtree_node(a.get("parent", "")); mapped = []; best = []
                    if parent:
                        for m in raw.get("matches", []):
                            src, dst = _gumtree_node(m.get("src", "")), _gumtree_node(m.get("dest", ""))
                            if src and dst and dst["start"] <= parent["start"] < dst["end"]:
                                mapped.append((src, dst))
                    if mapped:
                        minimum_span = min(destination["length"] for _, destination in mapped)
                        best = [source for source, destination in mapped if destination["length"] == minimum_span]
                    if len(best) == 1:
                        line = _action_line(f'{best[0]["type"]} [{best[0]["start"]},{best[0]["end"]}]', current_state_code, len(prefix))
                    if line is None:
                        anchor = (best[0]["start"] - len(prefix)) if len(best) == 1 else None
                        if anchor is not None:
                            base_line = current_state_code[:anchor].count("\n") + 1
                            line = _nearest_baseline_statement(base_line, baseline_statements)
                if line is None:
                    raise RuntimeError("statement_mapping_failed")
                lines.add(line)
            statement_supports, score = _score_mapped_statements(lines, support)
            reports.append({"candidate_index": c["candidate_index"], "status": "scored", "score": score,
                            "modified_lines": sorted(lines), "statement_supports": statement_supports})
        except Exception as exc:
            reports.append({"candidate_index": c["candidate_index"], "status": "unknown", "reason": str(exc)})
    scored = [x for x in reports if x["status"] == "scored"]
    top = max([x["score"] for x in scored], default=None)
    keep = [x["candidate_index"] for x in reports if x["status"] == "unknown" or x.get("score") == top]
    return {"status": "available", "fault_mapping": fault, "successful_failure_tests": len(regions),
            "failed_test_evidence": test_evidence, "statement_support": support, "candidates": reports,
            "highest_score_candidate_indices": keep}
